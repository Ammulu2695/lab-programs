﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Employee Id:175089
    /// Employee Name:Korrapolu Kalpana
    /// Date Of Creation:12-March-2019
    /// Description:Entity class for an employee
    /// </summary>
    [Serializable]
    public class Employee
    {
        //Get or set Employee ID
        public int EmployeeID { get; set; }

        //Get or set Employee Name
        public string EmployeeName { get; set; }

        //get or set salary
        public double Salary { get; set; }

        //get or set HRA
        public double HRA { get; set; }

        //get or set TA
        public double TA { get; set; }

        //get or set DA
        public double DA { get; set; }

        //get or set PF
        public double PF { get; set; }

        //get or set TDS
        public double TDS { get; set; }

        //get or set net salary
        public double NetSalary { get; set; }

        //get or set gross salary
        public double GrossSalary { get; set; }
        public object EmployeeSalary { get; set; }
    }
}
