﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleDetaits
{
    /// <summary>
    /// Employee Id:175089
    /// Employee Name:Korrapolu Kalpana
    /// Date of Creation:12-March-2019
    /// Description:Inheritance the class of vehicle to motor vehicle
    /// </summary>

    
     class MotorVehicle:Vehicle
    {
        public double FuelCapacity { get; set; }
        public MotorVehicle(int speed,string color,double fuelcap):base(speed,color)
        {
            FuelCapacity = fuelcap;
        }
    }
}
