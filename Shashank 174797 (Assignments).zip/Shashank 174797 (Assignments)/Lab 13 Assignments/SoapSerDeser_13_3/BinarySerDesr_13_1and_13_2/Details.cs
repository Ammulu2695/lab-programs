﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BinarySerDesr_13_1and_13_2

{
    [Serializable]
    class Details
    {
        public Details()
        {
        }

        public Details(int personID, string personName, string personPhoneNo, string personAddress)
        {
            PersonID = personID;
            PersonName = personName;
            PersonPhoneNo = personPhoneNo;
            PersonAddress = personAddress;
        }

        public int PersonID { get; set; }
        public string PersonName { get; set; }
        public string PersonPhoneNo { get; set; }
        public string PersonAddress { get; set; }

    }
}
