﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
namespace SoapSerDeser_13_3


{
    [Serializable]
    class Details
    {
        public Details()
        {
        }

        public Details(int personID, string personName, string personPhoneNo, string personAddress)
        {
            PersonID = personID;
            PersonName = personName;
            PersonPhoneNo = personPhoneNo;
            PersonAddress = personAddress;
        }

        public int PersonID { get; set; }
        public string PersonName { get; set; }
        public string PersonPhoneNo { get; set; }
        public string PersonAddress { get; set; }

    }
}
