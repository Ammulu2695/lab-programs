﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Runtime.Serialization.Formatters.Soap;
using System.IO;
namespace SoapSerDeser_13_3

{
    class Program
    {
        public static void n()
        {
            Details newclass = new Details();
            Console.WriteLine("enter the personID");
            newclass.PersonID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Personname");
            newclass.PersonName = Console.ReadLine();
            Console.WriteLine("Enter the Person Phonenumber");
            newclass.PersonPhoneNo = Console.ReadLine();
            Console.WriteLine("Enter the PersonAddress");
            newclass.PersonAddress = Console.ReadLine();

        }
        static List<Details> detailList = new List<Details>();
        static void Main(string[] args)
        {
            for (int i = 0; i < 10; i++)
            {
                n();
            }
            FileStream fs = new FileStream("Lab-13.txt", FileMode.Create, FileAccess.Write);

            SoapFormatter bin = new SoapFormatter();
            bin.Serialize(fs, detailList.ToArray());
            fs.Close();

            fs = new FileStream("Lab-13", FileMode.Open, FileAccess.Read);
            Details[] newd = (Details[])bin.Deserialize(fs);
            foreach (var item in newd)
            {
                Console.WriteLine($"Person id { item.PersonID}");
                Console.WriteLine($"Person Name { item.PersonName}");
                Console.WriteLine($"Person PhonenUmber { item.PersonPhoneNo}");
            }
            Console.ReadKey();
        }
    }
}
