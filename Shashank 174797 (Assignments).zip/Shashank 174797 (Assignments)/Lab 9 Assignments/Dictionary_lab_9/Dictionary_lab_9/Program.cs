﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dictionary_lab_9
{
    class Program
    {
        static Dictionary<string, string> dict = new Dictionary<string, string>();

        static void Main(string[] args)
        {
            Add();
            Display();
            Edit();
            Remove();
            Console.ReadLine();
        }
        static void Add()
        {
            try
            {
                dict.Add("David", "Richerdson");
                dict.Add("Kohli", "Virat");
                dict.Add("Gaily", "Marsh");
                dict.Add("polard", "kiran");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void Display()
        {
            foreach (var item in dict)
            {
                Console.WriteLine(item);
            }
        }
        static void Edit()
        {
            dict["David"] = "Charly";
            foreach (var item in dict)
            {
                Console.WriteLine(item);

            }
        }
        static void Remove()
        {
            dict.Remove("Gaily");
            foreach (var item in dict)
            {
                Console.WriteLine(item);

            }
        }
    }
}
