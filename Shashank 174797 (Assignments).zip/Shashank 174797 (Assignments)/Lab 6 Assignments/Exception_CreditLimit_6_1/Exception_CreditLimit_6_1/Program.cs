﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_CreditLimit_6_1
{
    class Program
    {
        static void Main(string[] args)
        {
            try

            {

                Customer cust = new Customer();

                Console.WriteLine("custommerID:");

                cust.CustId = int.Parse(Console.ReadLine());

                Console.WriteLine("customer name: ");

                cust.CustName = Console.ReadLine();

                Console.WriteLine("address : ");

                cust.Address = Console.ReadLine();

                Console.WriteLine("city: ");

                cust.City = Console.ReadLine();

                Console.WriteLine("phone : ");

                cust.Phone = int.Parse(Console.ReadLine());

                Console.WriteLine("credit limit : ");

                cust.CreditLimit = double.Parse(Console.ReadLine());

                if (cust.CreditLimit > 50000)

                {

                    throw new CreditLimitException("limit is exceeded");

                }

                else

                {

                    Console.WriteLine("OK");

                }

            }

            catch (CreditLimitException ce)

            {

                Console.WriteLine(ce.Message);

            }

            Console.ReadLine();

        }
    }
}
