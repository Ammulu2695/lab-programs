﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_CreditLimit_6_1
{
    class Customer
    {

        int customerId;

        string customerName;

        string address;

        string city;

        int phone;

        double creditLimit;

        public int CustId
        {
            get { return customerId; }

            set { customerId = value; }

        }

        public string CustName

        {

            get { return customerName; }

            set { customerName = value; }

        }

        public string Address

        {

            get { return address; }

            set { address = value; }

        }

        public string City

        {

            get { return city; }

            set { city = value; }

        }

        public int Phone

        {

            get { return phone; }

            set { phone = value; }

        }

        public double CreditLimit

        {

            get { return creditLimit; }

            set { creditLimit = value; }

        }

        public Customer()

        {

        }

        public Customer(int id, string name, string address, string city, int phn, double crelimit)

        {

            this.customerId = id;

            this.customerName = name;

            this.address = address;

            this.city = city;

            this.phone = phn;

            this.creditLimit = crelimit;

        }

    }




    public class CreditLimitException : ApplicationException

    {

        public CreditLimitException() : base() { }




        public CreditLimitException(string message) : base(message) { }




        public CreditLimitException(string message, Exception innerException) : base(message, innerException) { }




    }

}
