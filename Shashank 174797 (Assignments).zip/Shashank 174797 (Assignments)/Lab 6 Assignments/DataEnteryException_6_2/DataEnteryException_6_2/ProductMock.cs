﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataEnteryException_6_2
{
    public class ProductMock
    {
        private int productId;

        private string productName;

        private double price;

        public int ProID { get { return productId; } set { productId = value; } }

        public string ProName { get { return productName; } set { productName = value; } }

        public double Price { get { return price; } set { price = value; } }

        public ProductMock() { }

        public ProductMock(int pID, string pName, double Pri)

        {

            productId = pID;

            productName = pName;

            price = Pri;

        }

    }

    public class DataEntryException : ApplicationException

    {

        public DataEntryException() : base() { }




        public DataEntryException(string message) : base(message) { }




        public DataEntryException(string message, Exception innerException) : base(message, innerException) { }

    }
}
