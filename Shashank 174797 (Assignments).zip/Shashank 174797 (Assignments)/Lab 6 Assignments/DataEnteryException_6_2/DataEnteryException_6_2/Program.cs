﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataEnteryException_6_2
{
    class Program
    {
        static void Main(string[] args)
        {
            AcceptDetails();
            Console.ReadLine();
        }
        public static void AcceptDetails()
        {
            ProductMock product = new ProductMock();
            try
            {
                Console.WriteLine("product ID:");
                product.ProID = int.Parse(Console.ReadLine());
                Console.WriteLine("product name: ");
                product.ProName = Console.ReadLine();
                Console.WriteLine("price: ");
                product.Price = double.Parse(Console.ReadLine());
                Console.WriteLine("productid: " + product.ProID);
                Console.WriteLine("product name: " + product.ProName);
                Console.WriteLine("proce: " + product.Price);
                if (product.ProID <= 0)
                {
                    throw new DataEntryException("Product ID must be greater than zero");
                }

                if (product.ProName == string.Empty)

                {
                    throw new DataEntryException("Product Name cannot be left blank");
                }

                if (product.Price <= 0)

                {
                    throw new DataEntryException("price must be greater than zero");
                }

            }

            catch (DataEntryException de)
            {
                Console.WriteLine(de.Message);
            }
        }
    }
}
