﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace twodimentionalarray22
{
    class array
    {
        static void Main(string[] args)
        {
            
            int[,] a = new int[5,6];
            //int i, j;
                Console.WriteLine("Enter the values" );
            
            
            for (int i  = 0; i <a.GetLength(0); i++)
            {
                
                for (int  j = 0; j <a.GetLength(1); j++)
                {
                    a[i, j] = Convert.ToInt32(Console.ReadLine());
                    //Console.WriteLine("The two dimentinal array is a[{0},{1}] = {2}", i,j,a[i,j]);
                }

            }
            Console.ReadKey();
            Console.WriteLine("The Matrix is : ");

            for (int i = 0; i <a.GetLength(0); i++)
            {

                for (int j = 0; j < a.GetLength(1); j++)
                {
                    //a[i, j] = Convert.ToInt32(Console.ReadLine());
                    Console.Write("{0} \t",a[i, j]);
                }
                Console.Write("\n");
            }
                Console.ReadLine();
            
        }

    }
}
