﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace productdemo24
{
    class productdemo
    {
        //object product_id;
        object product_name;
        object price;
        object quantity;
        double amountpayable ;
        public double calculate(double quantity, double price)
        {
            return price * quantity;
        }
        static void Main(string[] args)
        {
            productdemo pro = new productdemo();
            Console.WriteLine("Enter the details of the product: ");
            Console.WriteLine("Enter the Product_ID : ");
            object product_id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the product_name : ");
            pro.product_name = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter the price : ");
            pro.price = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the quantity : ");
            pro.quantity = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the amount_payable : ");
            int p_id = (int)product_id;
            string p_name = (string)pro.product_name;
            double p_price = (double)pro.price;
            double p_quantity = (double)pro.quantity;
            Console.WriteLine();
            Console.WriteLine($"The Prodcut ID id : {p_id}");
            Console.WriteLine($"The product Name is :{p_name}");
            Console.WriteLine($"The Price of the prodcut is :{p_price} ");
            Console.WriteLine($"The quantity is : {p_quantity}");
            Console.WriteLine("-----------------");


            pro.amountpayable =pro.calculate(p_quantity,  p_price);
            Console.WriteLine($"Total amount for {p_name } " +
                $".: {pro.amountpayable}");
            Console.ReadLine();
           // 
        }


    }
}
