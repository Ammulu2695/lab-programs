﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace structure21
{
    class Program
    { struct Number
        {
            public int n;
            public void get()
            {
                Console.WriteLine("Enter the number: ");
                n = Convert.ToInt32(Console.ReadLine());
            }
                public void square()

                {
                Console.WriteLine($"Square of the given number : {n*n} ");
              
            }
            public void cube()

            {
                Console.WriteLine($"Cube of the given number : {n * n*n} ");

            }
        }    
        static void Main(string[] args)
        {
            Number o = new Number();
            o.get();
            Console.WriteLine("Please select 1 for square and 2 for cube");
            int choice = Convert.ToInt32(Console.ReadLine());
            if (choice == 1)
            {
                o.square();
            }
            
            else if (choice == 2)
            {
                o.cube();
            }
            else
            {
                Console.WriteLine("You have entered wrong choice");
            }
            Console.ReadLine();
        }
    }
}
