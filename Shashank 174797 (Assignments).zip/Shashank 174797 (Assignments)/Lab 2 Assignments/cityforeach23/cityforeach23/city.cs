﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cityforeach23
{
    class city
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the size of array : ");
            int size = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("enter the city name: ");
            string [] arr = new string [size];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = Console.ReadLine();

            }
            foreach (string place in arr)
            {
                //Console.WriteLine();
                Console.WriteLine("\n" +place);
            }
            Console.ReadLine();
            
        }
    }
}
