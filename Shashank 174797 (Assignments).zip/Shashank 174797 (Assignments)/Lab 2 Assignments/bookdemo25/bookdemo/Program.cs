﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bookdemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] sa = new string[4]{"Book_title", "author", "Publish", "Price"};
            string[,] ma = new string[2,4];
            Console.WriteLine("Enter the details: ");
            for (int i = 0; i < ma.GetLength(0); i++)
            {
                //sa[i] = Convert.ToString(Console.ReadLine());
                for (int j = 0; j < ma.GetLength(1); j++)
                { 

                    
                ma[i, j] = Console.ReadLine();
                }
                //Console.ReadLine();
            }
        
            for (int i = 0; i < ma.GetLength(0); i++)
            {
                for (int j = 0; j < ma.GetLength(1); j++)
                {
                   Console.Write(sa[j]+ ":"+"\t");
                    Console.Write( ma[i, j]+ ":"+"\t");
                }
                Console.WriteLine();

            }
            //Console.Write("\n");
            Console.ReadKey();
        }
    }
}
