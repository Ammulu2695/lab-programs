﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using mathlib;
using doublelib;
namespace mathapp
{
    class Arithmetic
    {
        static void Main(string[] args)
        {
            //int n1 = 20;
            //int n2 = 4;
            Console.WriteLine("enter values of two numbers of 'integer' type");
            int n1= Convert.ToInt32( Console.ReadLine());
            int n2= Convert.ToInt32( Console.ReadLine());
            Console.WriteLine("math operations on two numbers of 'integer' type");
            cal c = new cal();
            cal.add(n1, n2);
            c.sub(n1, n2);
            c.mult(n1, n2);
            c.div(n1, n2);
            c.mod(n1, n2);

            //double n11 = 17.88;
            //double n22 = -56.78;
            Console.WriteLine("enter values of two numbers of 'double' type");
            double n11 = Convert.ToDouble(Console.ReadLine());
            double n22 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("\n math operations on two numbers of 'double' type");

            call cc = new call();
                call.addd(n11, n22);
                cc.subb(n11, n22);
                cc.multt(n11, n22);
                cc.divv(n11, n22);
                cc.modd(n11, n22);
                Console.ReadKey();
            }
        }
    }

