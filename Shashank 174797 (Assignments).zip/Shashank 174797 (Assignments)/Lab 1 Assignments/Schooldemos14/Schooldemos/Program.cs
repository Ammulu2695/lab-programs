﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Schooldemos;


namespace studentdetails
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student();
            Console.WriteLine("Enter all the details of student");
            Console.WriteLine("Enter the student's  rollnumber :");
            s.rollnum = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Enter the student's  name :");
            s.sname = Console.ReadLine();
            Console.WriteLine("Enter the student's  age :");
            s.sage = byte.Parse(Console.ReadLine());
            Console.WriteLine("Enter the student's  gender :");
            s.sgender = (Console.ReadLine()).ToCharArray()[0];
            Console.WriteLine("Enter the student's  DOB :");
            s.sdob = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Enter the student's  address :");
            s.saddress = Console.ReadLine();
            Console.WriteLine("Enter the student's  percentage :");
            s.spercentage = Int32.Parse(Console.ReadLine());

            Console.WriteLine("All the details as per student inputs");
            Console.WriteLine($"\nStudent rollnum: {s.rollnum} \nStudent name : {s.sname}  \nStudent age : {s.sage} \nStudent gender : {s.sgender}  \nStudent dob : {s.sdob}  \nStudent address : {s.saddress}  \nStudent percentage : {s.spercentage}");
            Console.ReadKey();
        }
    }
}
