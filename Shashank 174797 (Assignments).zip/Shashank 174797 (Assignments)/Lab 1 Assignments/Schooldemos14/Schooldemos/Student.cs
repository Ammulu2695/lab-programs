﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Schooldemos
{
    class Student
    {

        int rollnumber;
        public int rollnum
        {
            get { return rollnumber; }
            set { rollnumber = value; }
        }
        string studentname;
        public string sname
        {
            set { studentname = value; }
            get { return studentname; }
            
        }
        byte age;
        public byte sage
        {
            get { return age; }
            set { age = value; }
        }
        char gender;
        public char sgender
        {
            get { return gender; }
            set { gender = value; }
        }
        DateTime dateofbirth;
        public DateTime sdob
        {
            get { return dateofbirth; }
            set { dateofbirth = value; }
        }
        string address;
        public string saddress
        {
            get { return address; }
            set { address = value; }
        }
        float percentage ;
        public float spercentage
        {
            get { return percentage; }
            set { percentage = value; }
        }


    }
}

