﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC
{
    public class Details
    {
        int Employee_ID;
        string Employee_Name;
        string Employee_Address;
        String City;
        string Department;
        double Salary;
        public int employee_ID
        {
            get { return Employee_ID; }
            set { Employee_ID = value; }

        }
        public string employee_name
        {
            get { return Employee_Name; }
            set { Employee_Name = value; }

        }
        public string employee_address
        {
            get { return Employee_Address; }
            set { Employee_Address = value; }

        }
        public string city
        {
            get { return City; }
            set { City = value; }

        }
        public string department
        {
            get { return Department; }
            set { Department = value; }

        }
        public double salary
        {
            get { return Salary; }
            set { Salary = value; }

        }


    }
}

