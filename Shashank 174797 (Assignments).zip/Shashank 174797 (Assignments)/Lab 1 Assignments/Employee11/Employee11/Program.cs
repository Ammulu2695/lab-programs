﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABC;

namespace Employee11
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = new Details [10];
            for (int i = 0; i < 2; i++)
            {
                a[i] = new Details();
                Console.WriteLine("Enter The details of the employee");
                Console.WriteLine("Enter  Employee_Id ");
                a[i].employee_ID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter  Employee_Name ");
                a[i].employee_name = Console.ReadLine();
                Console.WriteLine("Enter  Employee_Address ");
                a[i].employee_address = Console.ReadLine();
                Console.WriteLine("Enter  City ");
                a[i].city = Console.ReadLine();
                Console.WriteLine("Enter  department ");
                a[i].department = Console.ReadLine();
               
                Console.WriteLine("Enter salary :");
                a[i].salary= Convert.ToDouble(Console.ReadLine());

                Console.WriteLine($"\n\n Emplyoee details are : \n" +
                   $"Employee_ID : {a[i].employee_ID} \n Employee_name : {a[i].employee_name}\n Employee_Address : {a[i].employee_address}\n city : {a[i].city}" +
                   $"\n Department : {a[i].department}\n Salary : {a[i].salary}\n\n");

            }
           

            Console.ReadLine();
        }
    }
}
