﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mathlib
{
    public class cal
    {
        public static void add(int n1, int n2)
        {
            Console.WriteLine($"{n1} + {n2} is {n1 + n2}");
        }
        public void sub(int n1, int n2)
        {
            Console.WriteLine($"{n1} - {n2} is {n1 - n2}");
        }
        public void mult(int n1, int n2)
        {
            Console.WriteLine($"{n1} * {n2} is {n1 * n2}");
        }
        public void div(int n1, int n2)
        {
            Console.WriteLine($"{n1} / {n2} is {n1 / n2}");
        }
        public void mod(int n1, int n2)
        {
            Console.WriteLine($"{n1} % {n2} is {n1 % n2}");
        }

        
        }
    }
}
