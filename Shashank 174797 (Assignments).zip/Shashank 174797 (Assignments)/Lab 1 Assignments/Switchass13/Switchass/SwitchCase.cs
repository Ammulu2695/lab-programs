﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switchass
{
    class SwitchCase
    {
        static void Main(string[] args)
        {
            char statement;
            Console.WriteLine("enter a number between 1-5");
            statement = Convert.ToChar(Console.ReadLine());
            switch( statement)
            {
                case '1':
                    Console.WriteLine("You have selected 1");
                    break;
                case '2':
                    Console.WriteLine("You have selected 2");
                    break;
                case '3':
                    Console.WriteLine("You have selected 3");
                    break;
                case '4':
                    Console.WriteLine("You have selected 4");
                    break;
                case '5':
                    Console.WriteLine("You have selected 5");
                    break;
                default:
                    Console.WriteLine("You have selected out of range");
                    break;

            }
            Console.ReadKey();
   
        }
    }
}
