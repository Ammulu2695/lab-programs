﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;
namespace Polymorphism_4_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee.ContractEmployee cemp = new ContractEmployee();
            cemp.AcceptData();
            cemp.GetSalary();

            PermanentEmployee pemp = new PermanentEmployee();
            pemp.AcceptData();
            cemp.GetSalary();

            cemp.DisplayData();
            pemp.DisplayData();
            Console.ReadLine();
        }
    }
}
