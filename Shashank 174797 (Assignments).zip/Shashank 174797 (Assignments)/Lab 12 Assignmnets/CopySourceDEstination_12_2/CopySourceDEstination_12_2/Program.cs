﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace CopySourceDEstination_12_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string path;
            
            path = Console.ReadLine();
            File.Copy(path, @"C: \Users\akushash\source\repos\sample.txt");
            Console.WriteLine(File.ReadAllText(path));
            Console.WriteLine(File.ReadAllText(@"C: \Users\akushash\source\repos\sample.txt"));
            Console.Read();
        }
    }
}
