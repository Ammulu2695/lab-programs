﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Academy_12_3
{
    class Program
    {
        string path = @"Desktop\Academy";
        private static void createIFMissing(string path)
        {
            bool folderExists = Directory.Exists(path);
        }
        static void Main(string[] args)
        {
            var dir = @"Desktop|Academy";
            File.WriteAllText(Path.Combine(dir, "Pune.txt"), "This file contains Pune employee details");
            File.WriteAllText(Path.Combine(dir, "Chenni.txt"), "This file contains  Chenni details");
            File.WriteAllText(Path.Combine(dir, "Bangalor.txt"), "This file contains Bangalor employee details");
            File.WriteAllText(Path.Combine(dir, "Hyderabad.txt"), "This file contains Huderabad employee details");
            createIFMissing(dir);
        }
    }
}
