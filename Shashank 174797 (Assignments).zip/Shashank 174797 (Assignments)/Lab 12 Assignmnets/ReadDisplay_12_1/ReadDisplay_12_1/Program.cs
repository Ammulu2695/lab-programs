﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


namespace ReadDisplay_12_1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

                StringBuilder sb = new StringBuilder();
                string path;
                path = Console.ReadLine();
                StreamReader st = new StreamReader(path);
                foreach (var item in st.ReadToEnd())
                {
                    sb.Append(item);
                }
                string newpath;
                 newpath = @"C:\Users\akushash\source\repos\sample.txt";
                StreamWriter sw = new StreamWriter(newpath);
                sw.Flush();
                sw.WriteLine(sb);
                sw.Close();
                Console.WriteLine(sb);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex);
            }
            Console.ReadKey();
        }


    }
}
