﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
//using System.Threading.Tasks;
namespace HashTableRTO_lab_8_1
{
    class Program
    {
        public static Hashtable RTODistrict = new Hashtable();

        static void Main(string[] args)
        {
            string choice1;
            do
            {
                Console.WriteLine("1) Add record into RTO");
                Console.WriteLine("2) Delete record");
                Console.WriteLine("3) Get all Employess details");
                Console.WriteLine("4)  Search Employee");
                Console.WriteLine("5) Number of  record into RTO");
                Console.WriteLine("5) Exit");
                int choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddHashtable();
                        break;
                    case 2:
                        DeleteRecord();
                        break;
                    case 3:
                        DisplayRecords();
                        break;
                    case 4:
                        SearchEmployee();
                        break;
                    case 5:
                        Count();
                        break;
                    case 6:
                        Exit();
                        break;
                }

                Console.WriteLine("Do you  wanna continue press y if no press n");
                choice1 = Console.ReadLine();
            }while ((choice1 == "y"));
            Console.Read();

        }
        public static void AddHashtable()
        {
            Console.WriteLine("enter RTO code :");
            string code = Console.ReadLine();
            Console.WriteLine("enter District :");
            string district = Console.ReadLine();
            RTODistrict.Add(code, district);
        }
        static void DeleteRecord()
        {
            Console.WriteLine("Enter RTo code to be deleted");
            string code_del = Console.ReadLine();
            RTODistrict.Remove(code_del);
            Console.WriteLine("recode has been removed succesfully");

        }
        static void DisplayRecords()
        {
            ICollection keys = RTODistrict.Keys;
            foreach (object item in keys)
            {
                string code = (string)item;
                string Name = (string)RTODistrict[code];
                Console.WriteLine($"RTO code {code} Name : {Name}");

            }
        }

        static void Count()
        {
            int c = RTODistrict.Count;
            Console.WriteLine($"Total nunmber od counts are {c}");
        }
        static void Exit()
        {
            Environment.Exit(0);
        }
        static void SearchEmployee()
        {
            Console.WriteLine("enter RTO code to search");
            string code = Console.ReadLine();
            ICollection collection = RTODistrict.Keys;
            foreach (object item in collection)
            {
                string code_ser = (string)item;
                if (code_ser == code)
                {
                    string Name = (string)RTODistrict[code];
                    Console.WriteLine($"RTO code = {code} Name {Name}");
                }
                else
                {
                    Console.WriteLine("No record found");
                }
            }
        }
    }
}
 


            



     