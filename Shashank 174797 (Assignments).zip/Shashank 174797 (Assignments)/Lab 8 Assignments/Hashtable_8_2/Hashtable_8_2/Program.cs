﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
//using System.Threading.Tasks;
namespace Hashtable_8_2
{
    class Program
    { static Hashtable GetHashtable()
        {
            Hashtable hashtable = new Hashtable();
            hashtable.Add("Area", 1000);
            hashtable.Add("Perimeter", 55);
            hashtable.Add("Mortgage", 540);
            return hashtable;
        }
        static void Main(string[] args)
        {
            Hashtable hashtable1 = GetHashtable();
            bool key = GetHashtable().ContainsKey("Perimeter");
            if(key)
            {
                Console.WriteLine("perimeter key is present");
            }
            else
            {
                Console.WriteLine("perimeter key not found");
            }
            Console.WriteLine($" value of area key is {hashtable1["Area"]}");
            hashtable1.Remove("Mortgage");
            Console.WriteLine("Mortigae was remooved");
            Console.WriteLine($"Value of Perimeter {hashtable1["Perimeter"]}");
            Console.ReadKey();
        }
    }
}
