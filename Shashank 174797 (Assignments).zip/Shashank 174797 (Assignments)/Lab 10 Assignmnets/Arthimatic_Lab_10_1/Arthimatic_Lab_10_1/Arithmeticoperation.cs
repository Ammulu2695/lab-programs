﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Arthimatic_Lab_10_1
{
    class Arithmeticoperation
    {
        public static void Add(int n1, int n2)
        {
            Console.WriteLine($"Addition :{n1 + n2}");
        }
        public static void Sub(int n1, int n2)
        {
            Console.WriteLine($"Substraction :{n1 - n2}");
        }
        public static void Mult(int n1, int n2)
        {
            Console.WriteLine($"Multiplication :{n1 + n2}");
        }
        public static void Division (int n1, int n2)
        {
            Console.WriteLine($"Division :{n1 / n2}");
        }
        public static void Max(int n1, int n2)
        {
            Console.WriteLine($"Max:{Math.Max(n1,n2)}");
        }
       
    }
}
