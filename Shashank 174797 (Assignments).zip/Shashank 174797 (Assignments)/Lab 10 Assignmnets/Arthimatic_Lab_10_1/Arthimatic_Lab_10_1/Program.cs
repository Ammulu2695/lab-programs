﻿ using System;
using System.Collections.Generic;
using System.Text;

namespace Arthimatic_Lab_10_1
{
    class Program
    {
        public delegate void ArithmeticOperation(int n1, int n2);

    
    
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first number ");
            int n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter second number ");
            int n2 = int.Parse(Console.ReadLine());
            ArithmeticOperation aop = new Arithmeticoperation.Add;
            int choice = 0;
            do
            {
                Console.WriteLine("1) ADD\n2)Sub \n3) Mul\n 4) Div\n 5) max\n 6) Exit");
                Console.WriteLine("Enter the choice");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        aop = Arithmeticoperation.Add;
                        aop.Invoke(n1, n2);
                        break;
                    case 2:
                        aop = Arithmeticoperation.Sub;
                        aop.Invoke(n1, n2);
                        break;
                    case 3:
                        aop = Arithmeticoperation.Mult;
                        aop.Invoke(n1, n2);
                        break;
                    case 6:

                        Environment.Exit(0);
                        break;
                    case 5:
                        aop = Arithmeticoperation.Division;
                        aop.Invoke(n1, n2);
                        break;


                }
            }
            while (choice != 0);

        }
    }
}
