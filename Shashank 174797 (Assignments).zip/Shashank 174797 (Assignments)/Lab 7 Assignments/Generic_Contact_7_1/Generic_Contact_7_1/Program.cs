﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Contact_7_1
{
    class Program
    {
        static List<Contact> contact = new List<Contact>();
        static void Main(string[] args)
        {
            Menu();
            Console.ReadLine();
        }
        static void Menu()
        {
            string choice1;
            do
            {
                Console.WriteLine("Select from the coice:");
                Console.WriteLine("1. Add Contact\n2. Display Contact\n3. Edit Contact\n4. Show all contacts");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddContact();
                        break;
                    case 2:
                        DisplayContact();
                        break;
                    case 3:
                        EditContact();
                        break;
                    case 4:
                        ListAllContacts();
                        break;
                }
                Console.WriteLine("Press Y to continue");
                choice1 = Console.ReadLine();
            } while (choice1 == "y");
            Console.ReadLine();
        }
        static void AddContact()
        {
            Contact con = new Contact();
            Console.WriteLine("enter contact id:");
            con.ContactNo = int.Parse(Console.ReadLine());
            Console.WriteLine("enter contact name: ");
            con.ContactName = Console.ReadLine();
            Console.WriteLine("enter cell no: ");
            con.CellNo = Console.ReadLine();
            contact.Add(con);
        }
        static void DisplayContact()
        {
            List<Contact> cont = contact;
            Console.WriteLine("nnumber   name   cell");
            foreach (Contact c in cont)
            {
                Console.WriteLine(c.ContactNo + " " + c.ContactName + " " + c.CellNo);
            }
        }
        static void EditContact()
        {
            List<Contact> contt = contact;
            int updateID;
            Console.WriteLine("enter contact id:");
            updateID = int.Parse(Console.ReadLine());
            for (int i = 0; i < contt.Count; i++)
            {
                Contact cont = contact[i];
                if (updateID == cont.ContactNo)
                {
                    Console.WriteLine("enter name:");
                    cont.ContactName = Console.ReadLine();
                    Console.WriteLine("enter cell no:");
                    cont.CellNo = Console.ReadLine();
                }
            }
        }
        static void ListAllContacts()
        {
            List<Contact> cont = contact;
            Console.WriteLine("number   name   cell");
            foreach (Contact c in cont)
            {
                Console.WriteLine(c.ContactNo + " " + c.ContactName + " " + c.CellNo);
            }
        }
    }
}
