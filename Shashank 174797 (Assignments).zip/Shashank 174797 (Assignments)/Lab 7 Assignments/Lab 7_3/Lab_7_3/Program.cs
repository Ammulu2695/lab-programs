﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XYZ;
namespace Lab_7_3
{
    class Program
    {
        static List<Employee> emplist = new List<Employee>();
        public static void AddEmployee()
        {
            Employee emp = new Employee();
            Console.WriteLine("enetr emp id");
            emp.EmployeeNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enetr emp name");
            emp.EmployeeName = Console.ReadLine();
            Console.WriteLine("enetr emp Basic Salry");
            emp.BasicSalary = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enetr emp PF");
            emp.PF = Convert.ToDouble(Console.ReadLine());
            emplist.Add(emp);

         

        }
        public static void SearchEmployee(int empID)
        {
            for (int i = 0; i < emplist.Count; i++)
            {
                if (emplist[i].EmployeeNumber==empID)
                {
                    Console.WriteLine($"{emplist[i].EmployeeNumber}  {emplist[i].EmployeeName}  {emplist[i].BasicSalary}  {emplist[i].PF}");
                }
            }
           
        }
        public static void ShowAllEmployee()
        {
            Console.WriteLine("EmployeeId   EmployeeName  Basic Salary    PF");
            foreach (var item in emplist)
            {
                Console.WriteLine($"{item.EmployeeNumber}  {item.EmployeeName}  {item.BasicSalary}  {item.PF}");

            }

        }
        public static void DeleteEmployee(int empID)
        {
            for (int i = 0; i < emplist.Count; i++)
            {
                if (emplist[i].EmployeeNumber == empID)
                {
                    emplist.Remove(emplist[i]);
                }
            }

        }
        public static void PrintMenu()
        {
            Console.WriteLine("1) Addemployee\n  2)Search Employee\n 3)Delete Employee\n 4)ShowAll Employee ");
        }

        public static void Main(string[] args)
        {
            int choice = 0;
            do
            {
                PrintMenu();
                Console.WriteLine("Enetr your choice");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddEmployee();
                        break;
                    case 2:
                        Console.WriteLine("Enter employee Id to be search ");
                        SearchEmployee(Convert.ToInt32(Console.ReadLine()));
                        break;
                    case 3:
                        Console.WriteLine("Enter employee Id to be Deleted ");
                        DeleteEmployee(Convert.ToInt32(Console.ReadLine()));
                        break;
                    case 4:
                        ShowAllEmployee();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice");
                        break;


                }

            }
            while (choice != 0);

            Console.ReadLine();
        }
    }
}
