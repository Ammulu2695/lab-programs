﻿using System;
using System.Collections.Generic;
using System.Text;
using GuestPhoneBook.DAL; 
using GuestPhoneBook.Exception; 
using GuestPhoneBook.Entities;
using System.Text.RegularExpressions;
namespace guestPhoneBook.BL

{
    public class GuestValidation
    { //to validate guest details
        public static bool ValidateGuest(Guest newGuest)
        {
            bool guestValidatrion = true;
            StringBuilder message = new StringBuilder();
            try
            {
                if (newGuest.GuestID< 100000 || newGuest.GuestID> 999999)
                {
                    guestValidatrion = false;
                    message.Append("employee ID should be 6 digit long \n");
                }
                //Checking - employeenname
                if (newGuest.GuestName == String.Empty)
                {
                    guestValidatrion = false;
                    message.Append("guest Name should be provided \n");
                }
                else if (!Regex.IsMatch(newGuest.GuestName, "[A-Z][a-z]{2,}"))
                {
                    guestValidatrion = false;
                    message.Append("guest name must be atleast 3 and starts with capital letter");
                }//check for ohone
                if (newGuest.GuestConstactNumber== string.Empty)
                {
                    guestValidatrion= false;
                    message.Append("Phone number should be provided");
                }
                else if (!Regex.IsMatch(newGuest.GuestConstactNumber, "[6-9][0-9]{9}"))
                {
                    guestValidatrion= false;
                    message.Append("Pone no starts with 6/7/8/9 and it should have exactly 10 didgits");
                }
                
                if (guestValidatrion == false)
                {
                    throw new GuestPhoneBookException(message.ToString());
                }
            }

            catch (GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestValidatrion;
        }
        public static bool AddGuest(Guest newGuest)
        {
            bool guestAdded = false;
            try
            {
                if (ValidateGuest(newGuest))
                {
                    guestAdded = GuestOperation.AddGuest(newGuest);
                }
                else
                {
                    throw new GuestPhoneBookException("Please provide valid Guest");
                }

            }

            catch (GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestAdded;

        }
        public static bool UpdateGuest(Guest newGuest)
        {
            bool guestUpdated = false;
            try
            {
                if (ValidateGuest(newGuest))
                {
                    guestUpdated = GuestOperation.UpdateGuest(newGuest);
                }
                else
                {
                    throw new GuestPhoneBookException("Please provide valid data to update Guest");
                }
            }
            catch (GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestUpdated;

        }
        public static bool DeleteGuest(int guestID)
        {
            bool guestDeleted = false;
            try
            {
                guestDeleted = GuestOperation.DeleteGuest(guestID);
            }
            catch (GuestPhoneBookException ex)
            { throw ex; }
            catch (SystemException ex) { throw ex; }
            return guestDeleted;
        }
        public static Guest SearchGuest(int guestID)
        {
            Guest newGuest = null;
            try
            {
                newGuest = GuestOperation.SearchGuest(guestID);
            }
            catch (GuestPhoneBookException ex)
            { throw ex; }
            catch (SystemException ex)
            { throw ex; }
            return newGuest;
        }
        public static Guest SearchRelation(Relation relation)
        {
            Guest newGuest = null;
            try
            {
                newGuest = GuestOperation.SearchRelation(relation);
            }
            catch (GuestPhoneBookException ex)
            { throw ex; }
            catch (SystemException ex)
            { throw ex; }
            return newGuest;
        }
        //Retrieve employee
        public static List<Guest> RetrieveGuest()
        {
            List<Guest> guestlist = GuestOperation.RetrieveGuest();
            return guestlist;
        }
        //public static bool SerializeEmployee()
        //{
        //    bool empSerialized = false;
        //    try
        //    {
        //        empSerialized = EmployeeOperation.SerializeEmployee();

        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Employee_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return empSerialized;
        //}//Deserialized
        //public static List<Employee> DeSerializeEmployee()
        //{
        //    List<Employee> empDesList = null;
        //    try
        //    {
        //        empDesList = EmployeeOperation.DeSearializeEmployee();

        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Employee_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return empDesList;
        //}
    }
}

