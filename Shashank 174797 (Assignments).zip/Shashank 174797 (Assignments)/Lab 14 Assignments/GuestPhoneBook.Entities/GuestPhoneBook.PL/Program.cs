﻿using System;
using System.Collections.Generic;
using System.Text;
using GuestPhoneBook.DAL;
using GuestPhoneBook.Entities;
using GuestPhoneBook.Exception;
using guestPhoneBook.BL;
namespace GuestPhoneBook.PL
{
    class Program
    {
        public static void AddGuest()
        {
            try
            {
                Guest newGuest = new Guest();
                Console.Write("Enter GUest ID :");
                newGuest.GuestID= Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter GuestName:");
                newGuest.GuestName = Console.ReadLine();
                Console.Write("Enter Guest contact number :");
                newGuest.GuestConstactNumber= Console.ReadLine();
                Console.WriteLine("Enter relation");
                string relation = Console.ReadLine();
                switch(relation)
                {
                    case "father":
                        newGuest.relationship = Relation.Father;
                        break;
                    case "mother":
                        newGuest.relationship = Relation.Mother;
                        break;
                    case "brother":
                        newGuest.relationship = Relation.Brother;
                        break;
                    case "sister":
                        newGuest.relationship = Relation.Sister;
                        break;
                    case "cousin":
                        newGuest.relationship = Relation.Cousin;
                        break;

                    case "uncle":
                        newGuest.relationship = Relation.Uncle;
                        break;
                    case "aunt":
                        newGuest.relationship = Relation.Aunt;
                        break;
                    case "son":
                        newGuest.relationship = Relation.Son;
                        break;
                    case "daughter":
                        newGuest.relationship = Relation.Daughter;
                        break;
                    case "friend":
                        newGuest.relationship = Relation.Friend;
                        break;


                }

                
                bool guestAdded= GuestValidation.AddGuest(newGuest);
                if (guestAdded)
                {
                    Console.WriteLine("Guest added successfully");
                }
                else
                {
                    throw new GuestPhoneBookException("Guest not added");
                }
            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void UpdateGuest()
        {
            try
            {
                Guest newGuest = new Guest();
                Console.Write("Enter guestID to be updated :");
                newGuest.GuestID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter updated GuestName :");
                newGuest.GuestName= Console.ReadLine();
                Console.Write("Enter updated guest contact number :");
                newGuest.GuestConstactNumber= Console.ReadLine();
                Console.WriteLine("Enter relation");
                string relation = Console.ReadLine();
                switch (relation)
                {
                    case "father":
                        newGuest.relationship = Relation.Father;
                        break;
                    case "mother":
                        newGuest.relationship = Relation.Mother;
                        break;
                    case "brother":
                        newGuest.relationship = Relation.Brother;
                        break;
                    case "sister":
                        newGuest.relationship = Relation.Sister;
                        break;
                    case "cousin":
                        newGuest.relationship = Relation.Cousin;
                        break;

                    case "uncle":
                        newGuest.relationship = Relation.Uncle;
                        break;
                    case "aunt":
                        newGuest.relationship = Relation.Aunt;
                        break;
                    case "son":
                        newGuest.relationship = Relation.Son;
                        break;
                    case "daughter":
                        newGuest.relationship = Relation.Daughter;
                        break;
                    case "friend":
                        newGuest.relationship = Relation.Friend;
                        break;


                }
                bool guestUpdated = GuestValidation.UpdateGuest(newGuest);
                if (guestUpdated)
                {
                    Console.WriteLine("guest updated successfully");
                }
                else
                {
                    throw new GuestPhoneBookException("guest not updated");
                }
            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeleteGuest()
        {
            try
            {
                int guestID;
                Console.Write("Enter Guest Id to be deleted");
                guestID = Convert.ToInt32(Console.ReadLine());
                bool guestDeleted = GuestValidation.DeleteGuest(guestID);

            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SearchGuest()
        {
            try
            {
                int guestID;
                Console.Write("guest employee Id to be search");
                guestID = Convert.ToInt32(Console.ReadLine());
                Guest newGuest = GuestValidation.SearchGuest(guestID);
                if (newGuest != null)
                {
                    Console.WriteLine($"guest Id: {newGuest.GuestID}");
                    Console.WriteLine($"Employee name : {newGuest.GuestName}");
                    Console.WriteLine($"Guest contact num : {newGuest.GuestConstactNumber}");
                    Console.WriteLine($"relation : {newGuest.relationship}");

                }
                else
                {
                    throw new GuestPhoneBookException("guest not found");
                }
            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SearchRelation()
        {
            try
            {
                Relation relation;
                Console.WriteLine("Enter guest relation to be search");
                string relationship = Console.ReadLine();
                switch (relationship)
                {
                    case "father":
                        relation = Relation.Father;
                        break;
                    case "mother":
                        relation = Relation.Mother;
                        break;
                    case "brother":
                        relation = Relation.Brother;
                        break;
                    case "sister":
                        relation = Relation.Sister;
                        break;
                    case "cousin":
                        relation = Relation.Cousin;
                        break;

                    case "uncle":
                        relation = Relation.Uncle;
                        break;
                    case "aunt":
                        relation = Relation.Aunt;
                        break;
                    case "son":
                        relation = Relation.Son;
                        break;
                    case "daughter":
                        relation = Relation.Daughter;
                        break;
                    case "friend":
                        relation = Relation.Friend;
                        break;


                }
                Guest newGuest = GuestValidation.SearchRelation(relation);
                if (newGuest != null)
                {
                    Console.WriteLine($"guest Id: {newGuest.GuestID}");
                    Console.WriteLine($"Employee name : {newGuest.GuestName}");
                    Console.WriteLine($"Guest contact num : {newGuest.GuestConstactNumber}");
                    Console.WriteLine($"relation : {newGuest.relationship}");

                }
                else
                {
                    throw new GuestPhoneBookException("guest not found");
                }
            }


            }
        public static void RetrieveGuest()
        {
            try
            {
                List<Guest> guestlist = GuestValidation.RetrieveGuest();
                if (guestlist != null || guestlist.Count > 0)
                {
                    Console.WriteLine("______________________________________________________");
                    Console.WriteLine("GuestId   Guest name  contact No");
                    Console.WriteLine("______________________________________________________");
                    Console.WriteLine("______________________________________________________");
                    foreach (var newGuest in guestlist)
                    {
                        Console.WriteLine($"{newGuest.GuestID}\t\t{newGuest.GuestName}\t\t{newGuest.GuestConstactNumber}");
                    }
                }
                else
                {
                    throw new GuestPhoneBookException("GUest date not retrived");
                }
            }
            catch (GuestPhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //public static void SerializeEmployee()
        //{
        //    try
        //    {
        //        bool empSerialized = EmployeeValidation.SerializeEmployee();


        //        if (empSerialized)
        //        {
        //            Console.WriteLine("Employee data Serialized");
        //        }
        //        else
        //        {
        //            throw new Employee_Exception("data is not serialized");
        //        }
        //    }
        //    catch (Employee_Exception ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //    catch (SystemException ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //}
        //public static void DeSerializeEmployee()
        //{
        //    try
        //    {
        //        List<Employee> empList = EmployeeValidation.RetrieveEmployees();
        //        if (empList != null || empList.Count > 0)
        //        {
        //            Console.WriteLine("______________________________________________________");
        //            Console.WriteLine("Employee Id   Employee name  Phone No    DOB DOJ City");
        //            Console.WriteLine("______________________________________________________");
        //            Console.WriteLine("______________________________________________________");
        //            foreach (var emp in empList)
        //            {
        //                Console.WriteLine($"{emp.EMployeeID}\t\t{emp.EmployeeName}\t\t{emp.Phoneno}\t\t{emp.DOB}\t\t{emp.DOJ}\t\t{emp.City}");
        //            }
        //        }
        //        else
        //        {
        //            throw new Employee_Exception("Employee date not retrived");
        //        }
        //    }
        //    catch (Employee_Exception ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //    catch (SystemException ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //}

        public static void PrintMenu()
        {
            Console.WriteLine("****************");
            Console.WriteLine("1.Add Guest");
            Console.WriteLine("2.Update Guest");
            Console.WriteLine("3.delete Guest");
            Console.WriteLine("4.search Guest");
            Console.WriteLine("5. Display Guest");
            Console.WriteLine("6. Search By Relation ");
        }
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddGuest();
                        break;
                    case 2:
                        UpdateGuest();
                        break;
                    case 3:
                        DeleteGuest();
                        break;
                    case 4:
                        SearchGuest();
                        break;
                    case 5:
                        RetrieveGuest();
                        break;
                    case 6:
                        SearchRelation();
                        break;

                }
            }
            while (choice != 0);



        }
    }
}

