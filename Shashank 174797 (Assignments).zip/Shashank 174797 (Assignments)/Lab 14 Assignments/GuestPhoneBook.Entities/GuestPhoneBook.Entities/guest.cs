﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GuestPhoneBook.Entities
{
    /// <summary>
    /// Employee ID : 174797
    /// Employee Name : Shashank Akula
    /// Date of creation : 8_mar_2019
    /// Description :Entity class for Employee
    /// </summary>
    //   [Serializable]
    public enum Relation
    {
        Father = 1, Mother = 2, Brother = 3, Sister = 4, Cousin = 5, Uncle = 6, Aunt = 7, Son = 8,
        Daughter = 9, Friend = 10
    }

        public class Guest
        {//Give the comments for each and every property
         // Get or set guestID
            public int GuestID { get; set; }
            // Get or set GuestName
            public string GuestName{ get; set; }
            // Get or set PhoneNO
            public string GuestConstactNumber { get; set; }
       
        public Relation relationship
        { get; set; }
            public Guest()
        {

        }

        }
    }

