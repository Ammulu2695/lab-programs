﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GuestPhoneBook.Exception
{
    public class GuestPhoneBookException : ApplicationException
    {
        //Default constructor
        public GuestPhoneBookException() : base()
        { }
        //parameterized constructor to initalize message proterty
        public GuestPhoneBookException (string message) : base(message)
        { }
    
    
    }
}
