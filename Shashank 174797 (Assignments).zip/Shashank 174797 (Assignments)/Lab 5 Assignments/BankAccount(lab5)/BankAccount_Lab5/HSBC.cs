﻿using System;
using System.Collections.Generic;
using System.Text;
using BankAccount;
namespace BankAccount_Lab5
{
    class HSBC : BankAccounts
    {
        public object BankAccountTypeEnum { get; internal set; }
        double total;
        public override double GetBalance()
        {
            return balance;

        }
        public override bool Withdraw(double amount)
        {
            if ((balance - amount) >= 0)
            {
                base.Withdraw(amount);
                return true;
            }
            else
            {
                Console.WriteLine("No Balance");
                return false;

            }
        }
        public override double CalculateIntrest()
        {
            balance = GetBalance();
            total = balance + ((balance * 7 * 1) / 100);
            return total;

        }
        public override bool Transfer(IBankAccount toAccount, double amount)
        {
            if ((balance - amount) >= 1000)
            {
                toAccount.Deposit(amount);
                Withdraw(amount);
                return true;
            }
            else
            {
                Console.WriteLine("No balance");
                return false;
            }
        }

    }
}
