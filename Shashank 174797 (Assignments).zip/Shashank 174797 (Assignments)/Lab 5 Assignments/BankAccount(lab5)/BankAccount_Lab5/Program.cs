﻿using System;
using System.Collections.Generic;
using System.Text;
using BankAccount;
namespace BankAccount_Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n");
            Console.WriteLine("ICICI Welcomes You");
            ICICI icic = new ICICI();
            icic.BankAccountTypeEnum = BankAccountTypeEnum.Saving;
            Console.WriteLine("Deposit the amount 5k into savings Account\n");
            icic.Deposit(5000);
            ICICI ici = new ICICI();
            icic.BankAccountTypeEnum = BankAccountTypeEnum.Current;
            Console.WriteLine("Deposit 2K to savings account\n");
            ici.Deposit(2000);
            Console.WriteLine("Balance of ICICI bank savings account :" + icic.GetBalance() + "\n");
            Console.WriteLine("Balance of ICICI bank savings account :" + ici.GetBalance() + "\n");
            Console.WriteLine("5000 is transferred to saving to current account\n");
            icic.Transfer(ici,5000);
            Console.WriteLine("Balance of ICICI bank savings account :" + icic.GetBalance() + "\n");
            Console.WriteLine("Balance of ICICI bank savings account :" + ici.GetBalance() + "\n");

            Console.WriteLine("balance with clculated tax");
            Console.WriteLine("Balance of ICICI bank savings account :" + icic.CalculateIntrest() + "\n");
            Console.WriteLine("Balance of ICICI bank savings account :" + ici.CalculateIntrest() + "\n");



            Console.WriteLine("\n");
            Console.WriteLine("HSBC Welcomes You");
            HSBC hsbc = new HSBC();
            hsbc.BankAccountTypeEnum = BankAccountTypeEnum.Saving;
            Console.WriteLine("Deposit the amount 5k into savings Account\n");
            hsbc.Deposit(5000);
            HSBC hsb = new HSBC();
            hsbc.BankAccountTypeEnum = BankAccountTypeEnum.Current;
            Console.WriteLine("Deposit 2K to savings account\n");
            hsb.Deposit(2000);
            Console.WriteLine("Balance of HSBC bank savings account :" + hsbc.GetBalance() + "\n");
            Console.WriteLine("Balance of HSBC bank savings account :" + hsbc.GetBalance() + "\n");
            Console.WriteLine("5000 is transferred to saving to current account\n");
            hsbc.Transfer(hsb,5000);
            Console.WriteLine("Balance of HSBC bank savings account :" + hsbc.GetBalance() + "\n");
            Console.WriteLine("Balance of HSBC bank savings account :" + hsb.GetBalance() + "\n");

            Console.WriteLine("balance with clculated tax");
            Console.WriteLine("Balance of HSBC bank savings account :" + hsbc.CalculateIntrest() + "\n");
            Console.WriteLine("Balance of HSBC bank savings account :" + hsb.CalculateIntrest() + "\n");
            Console.ReadKey();
        }
    }
}
