﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccount
{
    public abstract class BankAccounts : IBankAccount
    {

        protected double balance;
        public BankAccountTypeEnum AccountType
        {
            get => throw new NotImplementedException();
            set => throw new NotImplementedException();
        }
        public void Deposit(double amount)
        {
            balance = balance + amount;
        }
        abstract public double GetBalance();
        abstract public double CalculateIntrest();
        abstract public bool Transfer(IBankAccount toAccount, double amount);

        public virtual bool Withdraw(double amount)
        {
            balance = balance - amount;
            return true;
        }
    }

}
