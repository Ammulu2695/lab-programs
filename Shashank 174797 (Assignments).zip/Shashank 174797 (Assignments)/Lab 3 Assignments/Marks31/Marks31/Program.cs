﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marks31
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Participant p = new Participant();
            Console.WriteLine("Enter the Employee Id :");
            p.empID = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("Enter the Employee_Name  :");
            p.name = Console.ReadLine();

            //Console.WriteLine("Enter the Employee's Company_name :");
            //p.company_name= Console.ReadLine();

            Console.WriteLine("Enter the FoundationMarks :");
            p.foundationmarks = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the WebBasedMarks :");
            p.wbmarks = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the DotnetMarks :");
            p.dnmarks = Convert.ToInt32(Console.ReadLine());
            p.obtainedmarkes(p.foundationmarks, p.wbmarks, p.dnmarks);
            //p.TotalMarks = Convert.tos(Console.ReadLine());
            Console.WriteLine($"Company_Name : {Participant.company_name}");
            Console.WriteLine($"obtained_marks : {p.ObtainedMarks }");
            p.percentage();
            Console.WriteLine($"Percentage : {p.Percentage}");
            Console.ReadKey();
        }

    }
}
