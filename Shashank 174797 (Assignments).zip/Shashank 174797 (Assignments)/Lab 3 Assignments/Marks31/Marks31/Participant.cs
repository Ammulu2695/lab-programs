﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marks31
{
    public class Participant
    {
        //int EmpID;
        //string Name;
        //string Company_Name;
        int FoundationMarks;
        int WebBasicMarks;
        int DotNetMarks;
        public int ObtainedMarks;
        public float Percentage;
        static float TotalMarks = 300;
        public int empID { get; set; }
        public string name { get; set; }
        public static string company_name { get; set; }
        public int foundationmarks
        {
             set
            {
                if (value >= 0 && value <= 100)
                    FoundationMarks = value;
                else
                    FoundationMarks = 0;
               
            } get { return FoundationMarks; }

            
        }
        public int wbmarks
        {
            set
            {
                if (value >= 0 && value <= 100)
                    WebBasicMarks = value;
                else
                    WebBasicMarks = 0;

            }
            get { return WebBasicMarks; }
        }

        public int dnmarks
        {
            set
            {
                if (value >= 0 && value <= 100)
                     DotNetMarks = value;
                else
                    DotNetMarks = 0;

            }
            get { return DotNetMarks; }
        }

        static Participant()
        {
            company_name = "corporate Univercity";
            
        }
        public Participant()
        {
        }

        public Participant(int empI, string names, string company_Name, int foundationMarks, int webBasicMarks, int dotNetMarks, int empID, string name, int foundationmarks, int wbmarks, int dnmarks)
        {
            this.empID = empI;
            this.name = name;
            this.foundationmarks = foundationMarks;
            wbmarks = webBasicMarks;
            dnmarks = dotNetMarks;
            
         }

        
        public int obtainedmarkes (int fmarks, int wmarks, int dmarks )
        {
            ObtainedMarks = fmarks + wmarks + dmarks;
            return ObtainedMarks;

        }
        public float percentage()
        {
            Percentage = (ObtainedMarks / TotalMarks)*100;
            return Percentage;
        }


    }
}
