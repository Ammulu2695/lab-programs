﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab3Q4
{
    class supplier
    {
        public int supplierID { get; set; }
        public string supplierName { get; set; }
        public string city { get; set; }
        public string email { get; set; }
        public string phoneno { get; set; }
          public void AcceptDetails(int supplierID, string supplierName, string city, string phoneno, string email)
        {
            this.supplierID = supplierID;
            this.supplierName = supplierName;
            this.city = city;
            this.phoneno = phoneno;
            this.email = email;
        }
        public object DisplayDetails()
        {
            object Details = ($"{supplierID},{supplierName},{city}, {phoneno},{email}");
            return Details;
        }
    }
}
