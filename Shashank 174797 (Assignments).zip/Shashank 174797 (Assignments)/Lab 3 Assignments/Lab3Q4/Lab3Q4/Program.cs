﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab3Q4
{
    class Program
    {
        static void Main(string[] args)
        {
            supplier sup = new supplier();
            Console.WriteLine("Enter supplier ID : ");
            sup.supplierID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter supplier name :");
            sup.supplierName = Console.ReadLine();
            Console.WriteLine("enter supplier city :");
            sup.city = Console.ReadLine();
            Console.WriteLine("enter supplier phoneno:");
            sup.phoneno= Console.ReadLine();
            Console.WriteLine("enter supplier email :");
            sup.email= Console.ReadLine();

            sup.AcceptDetails(sup.supplierID, sup.supplierName, sup.city, sup.phoneno, sup.email);
            Console.WriteLine(sup.DisplayDetails());
            Console.ReadKey();
        }
    }
}
