﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_catalog
{
    public class car
    {
        public car()
        {
        }

        public car(int car_model, int car_year, int car_sale_price)
        {
            this.car_model = car_model;
            this.car_year = car_year;
            this.car_sale_price = car_sale_price;
        }

        public int car_model { get; set; }
        public int car_year { get; set; }
        public double car_sale_price { get; set; }


    }
}
