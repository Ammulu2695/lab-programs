﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_catalog
{ 
    class Program
    {
        int count = 0;
        car[] c_arr = new car [10];
        public void menu()
        {
            Console.WriteLine("Please select one option from the above \n 1) Adding a car \n2) Modify car details \n3) Search for a car \n4)List the car details" +
                "\n5) Delete car details\n6) Quit\n");
            int a = Convert.ToInt32(Console.ReadLine());
            if (a == 1)
            {
                car ca = new car();
                Console.WriteLine("Enter the car details you want to add: ");
                
                Console.WriteLine("Enter the car model : ");
                ca.car_model = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the car year : ");
                ca.car_year = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the car sale_price : ");
                ca.car_sale_price = Convert.ToDouble (Console.ReadLine());
                Console.WriteLine($"\n Successfully updated car details ads follows : \n1)Car model : {ca.car_model}\n 2)Car year :{ca.car_year}\n3)Car sale Price :{ca.car_sale_price}\n");
                c_arr[count] = ca;
                count+=1;
                menu();

            }
            else if (a==4)
            {
                
                    Console.WriteLine("\nThe list of car details :");
                    Console.WriteLine(" Car Model \t Car Year \t Car sale_Price");
                    for (int i = 0; i < c_arr.Length; i++)

                    {
                        if (i < count)
                        {
                        Console.WriteLine($"{c_arr[i].car_model}\t{c_arr[i].car_year}\t{c_arr[i].car_sale_price}\n");
                        
                        }
                    }
                
                
                menu();
            }
            else if(a==6)
            {
                quit();
                
            }
            else
            {
                Console.WriteLine("Wrong input : \n");
                menu();
            }
        }
        public void quit()
        {
            Environment.Exit(0);
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            p.menu();
                  Console.ReadKey();


        }
    }
}
