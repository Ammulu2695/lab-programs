﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Training_20Feb_MumbaiEntities te = new Training_20Feb_MumbaiEntities();
            var emp = te.Emp_Managers_174780;
            foreach (Emp_Managers_174780 a in emp)

            {

            }
        }
    }
}
