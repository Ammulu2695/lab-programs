﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoProjectionOpertor
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Bouquet> bouquets = new List<Bouquet>()
            {
                new Bouquet{Flowers =new List<string>{"Sunflower","Daisy","Daffodil","Larkspur"} },
               new Bouquet{Flowers =new List<string>{"Gladiolis","Lily","Snapdragon","Aster","protea"}},
               new Bouquet{Flowers =new List<string>{"Lasrkspur","RedRose","Louts","Rose"}}
            };
            IEnumerable<List<string>> query1 = bouquets.Select(bq => bq.Flowers);
            //*********************SelectMany************
            IEnumerable<string> query2 = bouquets.SelectMany(bq => bq.Flowers);
            Console.WriteLine("Results by using Select():");

            // Note the extra foreach loop here.
            foreach (IEnumerable<string> collection in query1)
                foreach (string item in collection)
                    Console.WriteLine(item);
            Console.ReadLine();
            Console.WriteLine("\n Resutls by using SelectMany():");

            foreach (string item in query2)
                Console.WriteLine(item);
            Console.ReadLine();

        }


        class Bouquet
        {
            public List<String> Flowers { get; set; }
        }
    }
}
 
