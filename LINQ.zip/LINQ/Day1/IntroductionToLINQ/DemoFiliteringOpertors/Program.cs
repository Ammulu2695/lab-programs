﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoFiliteringOpertors
{
    class Program
    {
        static void Main(string[] args)
        {
            Developer[] developers = new Developer[]
            {
                new Developer{Name ="Harshitha",Language ="C#"},
                new Developer{Name ="Vaddineni",Language ="F#"},
                new Developer{Name ="xyz",Language ="VB.NET"} };

            var developersUsingCSharp =
            from d in developers

            where d.Language == "C#"

            where d.Language == " C#" ||
             d.Language == "VB.NET"

            //where  d.Name == "C#" &&
            //    d.Language == "VB.NET"

             //order by
             //oderby d.Name
             //descending
            select d;
            foreach (var item in developersUsingCSharp)
            {
                Console.WriteLine(item.Name);
                Console.ReadLine();
            }
            Console.ReadKey();
        }

        public class Developer
        {
            public string Name;
            public string Language;
            public int Age;
        }
    }
}
