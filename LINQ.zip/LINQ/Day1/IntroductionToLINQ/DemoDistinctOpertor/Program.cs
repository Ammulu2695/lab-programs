﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoDistinctOpertor
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4 };
            int[] numbers2 = { 1, 1, 3, 3 };

            var number3 = numbers.Except(numbers2);

            //var number3 = numbers.Intersect(numbers2);
            //var number3 = numbers.Union(numbers2);
            //var number3 =numbers.Distinct(number2);
            foreach (var item in number3)
                Console.WriteLine(item);
            {
                Console.ReadKey();
            }
        }
    }
}
