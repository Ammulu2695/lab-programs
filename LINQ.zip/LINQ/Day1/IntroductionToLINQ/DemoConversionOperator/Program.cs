﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoConversionOperator
{
    class Program
    {
        static void Main(string[] args)
        {
            object[] sequence = { 1, "Hello", 2.0 };

            var query = sequence.OfType<string>();

            foreach (var item in query)
                Console.WriteLine(item);
            Console.ReadLine();
            //ToArray
            List<string> BrandList = new List<string>()

            {
                "Apple","Microsoft","Google","Samsung","Sony"
            };
            // retrieve items from the list in ascending oder and convert them to array
            string[] brandArray = (from brand in BrandList
                                   orderby brand ascending
                                   select brand).ToArray();
            foreach (string item in brandArray)
            {
                Console.WriteLine(item);
                Console.ReadLine();
            }
            Console.ReadKey();

        }
    }
}
