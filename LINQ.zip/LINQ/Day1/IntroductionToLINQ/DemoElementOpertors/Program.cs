﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoElementOpertors
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            var query = numbers.First();
            Console.WriteLine("The fisrt element in the Sequence");
            Console.WriteLine(query);

            query = numbers.Last();
            Console.WriteLine("The Last element in the Sequence ");
            Console.WriteLine(query);

            Console.WriteLine("The fisrt even element in the Sequence");
            query = numbers.First(n => n % 2 == 0);
            Console.WriteLine(query);

            Console.WriteLine("The last even element in the Sequence");
            query = numbers.Last(n => n % 2 == 0);
            Console.WriteLine(query);
            //Console.ReadKey();




            int[] numbers1 = { 1, 3, 5, 7, 9 };
            var query1 = numbers1.FirstOrDefault(n => n % 2 == 0);
            Console.WriteLine("The fisrt even element in the Sequence");
            Console.WriteLine(query1);

            Console.WriteLine("The last odd element in the Sequence");
            query1 = numbers1.LastOrDefault(n => n % 2 == 1);
            Console.WriteLine(query1);
            // Console.ReadKey();




            int[] numbers2 = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            var query2 = numbers2.Single(n => n > 8);
            Console.WriteLine(query2);
            //Console.ReadKey();


            int[] numbers3 = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            var query3 = numbers3.ElementAt(4);
            Console.WriteLine(query3);
            

            int[] numbers4 = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            var query4 = numbers4.ElementAtOrDefault(9);
            Console.WriteLine(query4);
            Console.ReadKey();

        }

    }
}
 

