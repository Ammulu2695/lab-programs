﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using EMS.Entity;       //Reference to Employee Entity
using EMS.Exception;    //Reference to Employee Exception
using EMS.DAL;          //Reference to DAL

namespace EMS.BL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name : 
    /// Date of Creation : 8-Mar-2019
    /// Description : Business logic class for employee
    /// </summary>
    public class EmployeeValidations
    {
        //To validate employee details
        public static bool ValidateEmployee(Employee emp)
        {
            bool empValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - employee id should be 6 digit
                if (emp.EmployeeID < 100000 || emp.EmployeeID > 999999)
                {
                    empValidated = false;
                    message.Append("Employee ID should be exactly 6 digits long\n");
                }

                //Checking - employee name
                if (emp.EmployeeName == String.Empty)
                {
                    empValidated = false;
                    message.Append("Employee Name should be provided\n");
                }
                else if (!Regex.IsMatch(emp.EmployeeName, "[A-Z][a-z]{2,}"))
                {
                    empValidated = false;
                    message.Append("Employee Name should start with capital alphabet and it should have minimum 3 alphabets\n");
                }

                //Checking Phone number
                if (emp.PhoneNo == string.Empty)
                {
                    empValidated = false;
                    message.Append("Phone number should be provided\n");
                }
                else if (!Regex.IsMatch(emp.PhoneNo, "[6-9][0-9]{9}"))
                {
                    empValidated = false;
                    message.Append("Phone number should start with 6/7/8/9 and it should have exactly 10 digits\n");
                }

                //Checking Date of Birth
                int age = DateTime.Today.Year - emp.DOB.Year;
                if (age < 18 || age > 60)
                {
                    empValidated = false;
                    message.Append("As per the Date of Birth Employee age should be within 18 to 60\n");
                }

                //Checking Date of Joining
                if (emp.DOJ > DateTime.Now)
                {
                    empValidated = false;
                    message.Append("Date of Joining should be less than or equal to today's date");
                }

                //Checking City
                if (emp.City == string.Empty)
                {
                    empValidated = false;
                    message.Append("City should be provided");
                }
                else if (emp.City.ToLower() != "pune" &&
                        emp.City.ToLower() != "mumbai" &&
                        emp.City.ToLower() != "hyderabad" &&
                        emp.City.ToLower() != "bangalore")
                {
                    empValidated = false;
                    message.Append("City should be either Pune or Mumbai or Hyderabad or Bangalore\n");
                }

                if (empValidated == false)
                {
                    throw new EmployeeException(message.ToString());
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empValidated;
        }

        public static bool AddEmployee(Employee emp)
        {
            bool empAdded = false;

            try
            {
                if (ValidateEmployee(emp))
                {
                    empAdded = EmployeeOperations.AddEmployee(emp);
                }
                else
                {
                    throw new EmployeeException("Please provide valid data for employee");
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empAdded;
        }

        public static bool UpdateEmployee(Employee emp)
        {
            bool empUpdated = false;

            try
            {
                if (ValidateEmployee(emp))
                {
                    empUpdated = EmployeeOperations.UpdateEmployee(emp);
                }
                else
                {
                    throw new EmployeeException("Please provide valid data to update employee");
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empUpdated;
        }

        public static bool DeleteEmployee(int empID)
        {
            bool empDeleted = false;

            try
            {
                empDeleted = EmployeeOperations.DeleteEmployee(empID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empDeleted;
        }

        public static Employee SearchEmployee(int empID)
        {
            Employee emp = null;

            try
            {
                emp = EmployeeOperations.SearchEmployee(empID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }

        public static List<Employee> RetrieveEmployees()
        {
            List<Employee> empList = EmployeeOperations.RetrieveEmployees();

            return empList;
        }

        public static bool SerializeEmployee()
        {
            bool empSerialized = false;

            try
            {
                empSerialized = EmployeeOperations.SerializeEmployee();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empSerialized;
        }

        public static List<Employee> DeserializeEmployee()
        {
            List<Employee> empDesList = null;

            try
            {
                empDesList = EmployeeOperations.DeserializeEmployee();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empDesList;
        }
    }
}
