﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestPhoneBook.Entities
{
    public class Guest
    {
        private int guestId;
        public int GuestId
        {
            get { return guestId; }
            set { guestId = value;}
        }
        private string guestName;
        public string GuestName
        {
            get { return guestName; }
            set { guestName = value; }
        }
        private string guestContactNumber;
        public string GuestContactNumber
        {
            get { return guestContactNumber; }
            set
            {
                guestContactNumber = value;
            }
        }
        public Guest()
        {
            guestId = 0;
            guestName = string.Empty;
            guestContactNumber = string.Empty;
        }

    }
}
