﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArithmeticOperations
{
    public class AO
    {
      //Addition
        public double Add(int x,double y)
        {
            return x + y;
        }
        //Subtraction
        public double Sub(int a, double b)
        {
            return a - b;
        }
        //Multiplication
        public double Mul(int c,double d)
        {
            return c * d;
        }
        //Division
        public double Div(int e,double f)
        {
            return e / f;
        }
        //Modulus
        public double Mod(int u, double v)
        {
            return u % v;
        }
            
    }
}
