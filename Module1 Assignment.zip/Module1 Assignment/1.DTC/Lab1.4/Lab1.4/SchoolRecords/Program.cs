﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentDetails;

namespace SchoolRecords
{
    class Program
    {

        static void Main(string[] args)
        {
            int length;
            Console.WriteLine("Enter the Number of Students: ");
            length = Convert.ToInt32(Console.ReadLine());
            StudentDetails.StudentDetails[] st = new StudentDetails.StudentDetails[length];
             for (int i = 0; i < length; i++)
             {
                st[i] = new StudentDetails.StudentDetails();     

                Console.WriteLine("----------Enter the Student Details-------");
                Console.WriteLine("Enter the rollNo :");
                st[i].rollNo = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Student name :");
                st[i].sName =Console.ReadLine();
                Console.WriteLine("ENter the age:");
                st[i].age = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("ENter the gender:");
                st[i].gender = Convert.ToChar(Console.ReadLine());
                Console.WriteLine("ENter the DateOfBirth:");
                st[i].DateOfBirth = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("ENter the Address:");
                st[i].Add = Console.ReadLine();
                Console.WriteLine("ENter the Percentage:");
                st[i].Percentage = Convert.ToDouble(Console.ReadLine());
                
            }


             
            for (int i = 0; i < length; i++)
            {
                Console.WriteLine("sname:{0},age{1},gender{2},DateOfBirth {3},Add {4},Percentage{5}",
                                  st[i].sName, st[i].age, st[i].gender, st[i].DateOfBirth, st[i].Add, st[i].Percentage);
            }
            Console.ReadKey();

        }


    }
}
