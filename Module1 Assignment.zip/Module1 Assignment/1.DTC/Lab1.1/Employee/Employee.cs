﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    public class Employee
    {
        public int Empid;
        public string EmpName;
        public string Empadd;
        public string city;
        public string Dept;
        public double Sal;

        public int GetID()
        {
            return Empid;
        }
        public void SetID(int Eid)
        {
            this.Empid = Eid;
        }

        public string GetName()
        {
            return EmpName;
        }
        public void SetName(string EName)
        {
            this.EmpName = EName;
        }
        public string GetAddress()
        {
            return Empadd;
        }
        public void SetAddress(string Eadd)
        {
            this.Empadd = Eadd;
        }
        public string GetCity()
        {
            return city;
        }
        public void SetCity(string city)
        {
            this.city = city;
        }
        public string GetDepartment()
        {
            return Dept;
        }
        public void SetDepartment(string Dept)
        {
            this.Dept = Dept;
        }
        public double GetSalary()
        {
            return Sal;
        }
        public void SetSalary(double Sal)
        {
            this.Sal = Sal;
        }


    }
}
