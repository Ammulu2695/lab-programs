﻿using System;                         //using sysytem as ref
using System.Collections.Generic;     //using Collections.Generic as ref
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9._1_Console
{
    class Program
    {
        static Dictionary<string, string> dictionary = new Dictionary<string, string>();
        static void Main(string[] args)
        {
            AddMethod();
            Display();
            Edit();
            Remove();
            Console.ReadLine();
        }

        static void AddMethod()
        {
            try
            {
                dictionary.Add("nani", "vinni");

                dictionary.Add("irfan", "shanu");

                dictionary.Add("bablu", "giri");

                dictionary.Add("divya", "kapil");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


        static void Display()
        {
            foreach (var obj in dictionary)
            {
                Console.WriteLine(obj);
            }
        }

        static void Edit()
        {
            dictionary["sai"] = "manikanta";
            foreach (var obj in dictionary)
            {
                Console.WriteLine(obj);
            }
        }

        static void Remove()
        {
            dictionary.Remove("kone");
            foreach (var obj in dictionary)
            {
                Console.WriteLine(obj);
            }
        }

    }
}
