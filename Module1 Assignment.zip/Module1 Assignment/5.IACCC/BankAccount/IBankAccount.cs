﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{
   
    
    public abstract class BankAccount : IBankAccount
    {
        protected double balance;

        public BankAccountTypeEnum AccountType
        {
            get => throw new NotImplementedException();
            set => throw new NotImplementedException();
        }

        abstract public double CalculateInterest();

        public void Deposit(double amount)
        {
            balance = balance + amount;
        }

        abstract public double GetBalance();

        abstract public bool Transfer(IBankAccount toAccount, double amount);

        public virtual bool Withdraw(double amount)
        {
            balance = balance - amount;
            return true;
        }
    }

    

   
}
