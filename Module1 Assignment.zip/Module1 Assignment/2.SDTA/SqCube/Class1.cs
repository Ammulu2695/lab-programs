﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqCube
{
    public struct Class1
    {
        int Number;
        public static int Square(int Number)
        {
            int sqr = Number * Number;
            return sqr;
        }
        public static int Cube(int Number)
        {
            int Cube = Number * Number * Number;
            return Cube;
        }
    }
}
