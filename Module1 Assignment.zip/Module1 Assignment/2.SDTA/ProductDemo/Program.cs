﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDemo
{
    class Program
    {
        private int productId;
        private string productName;
        private double price;
        private int quantity;
        private int amountPayable;

        private object prodId;
        private object prodName;
        private object pricE;
        private object quantitY;
        private object amountPayablE;

        public void ProductDetails()
        {
            Console.WriteLine("Enter the productId:");
            productId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the productNmae");
            productName = Console.ReadLine();
            Console.WriteLine("Enter the product price");
            price = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the quantity");
            quantity = Convert.ToInt32(Console.ReadLine());
            prodId = productId;
            prodName = productName;
            pricE = price;
            quantitY = quantity;
        }
        public void Display()
        {
            Console.WriteLine("productId :" + prodId);
            Console.WriteLine("productName :" + prodName);
            Console.WriteLine("productPrice :" + pricE);
            Console.WriteLine("Quantity :" + quantitY);
            amountPayablE = quantity * price;
            Console.WriteLine("AmountPayble :" + amountPayablE );
        }

        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.ProductDetails();
            obj.Display();
            Console.ReadLine();
        }
    }
}
