﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Class1;

namespace _10._2_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.WriteLine("enter two numbers:");
            num1 = int.Parse(Console.ReadLine());
            num2 = int.Parse(Console.ReadLine());
            MyDelegate md = new MyDelegate(Class1.ArithmeticOperations.Add);
            md -= Class1.ArithmeticOperations.Add;
            PerformArithmeticOperation(num1, num2, md);
        }

        static void PerformArithmeticOperation(int num1, int num2, MyDelegate md)
        {
            int choice;
            do
            {
                Console.WriteLine("1.Add\n2.Sub\n3.Mul\n4.Max");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        {
                            md = Class1.ArithmeticOperations.Add;
                            Console.WriteLine((md(num1, num2)));
                            break;
                        }
                    case 2:
                        {
                            md = Class1.ArithmeticOperations.Sub;
                            Console.WriteLine((md(num1, num2)));
                            break;
                        }
                    case 3:
                        {
                            md = Class1.ArithmeticOperations.Mul;
                            Console.WriteLine((md(num1, num2)));
                            break;
                        }
                    case 4:
                        {
                            md = Class1.ArithmeticOperations.Max;
                            Console.WriteLine((md(num1, num2)));
                            break;
                        }
                }
            }
            while (choice != 0);
            Console.ReadLine();
        }
    }
}
