﻿using System;                                 //using system ref
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car
{
    public class Car
    {
        string model;
        string owner;
        double salePrice;
        int year;
        public int id = -1;
        public int carid =- 1;
        public Car()
        {
            model= "abc";
            owner = "xyz";
            year = 0;
            salePrice = 0;
        }

        public void AddCar()
        {
            carid = carid + 1;
            id = carid;
            Console.WriteLine("Enter Car's owner name: ");
            owner = Console.ReadLine();
            Console.WriteLine("Enter Car model : ");
            model = Console.ReadLine();
            Console.WriteLine("enter car Price: ");
            salePrice = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the year: ");
            year = Convert.ToInt16(Console.ReadLine());
        }

        public void Delete()
        {
            owner = null;
            model = null;
            salePrice = 0;
            year = 0;
        }
        public void Display()
        {
            Console.WriteLine("-----Car Details-------");
            Console.WriteLine("id: " + id);
            Console.WriteLine("model: " + model);
            Console.WriteLine("Price :" + salePrice);
            Console.WriteLine("Year :" + year);
        }
        public void Update()
        {
            Console.WriteLine("Enter Car's owner name: ");
            owner = Console.ReadLine();
            Console.WriteLine("Enter CAr model : ");
            model = Console.ReadLine();
            Console.WriteLine("enter car Price: ");
            salePrice = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the year: ");
            year = Convert.ToInt16(Console.ReadLine());
        }

    }
}

