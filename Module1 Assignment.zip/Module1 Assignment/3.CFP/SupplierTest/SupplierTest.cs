﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplierTest
{
    public class SupplierTest
    {
        int supplierId;
        string supplierName;
        string city;
        string phNo;
        string email;
        public void AcceptDetails()
        {
            Console.WriteLine("Enter Supplier ID");
            supplierId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter supplier Name");
            supplierName = Console.ReadLine();
            Console.WriteLine("Enter supplier City");
            city = Console.ReadLine();
            Console.WriteLine("Enter supplier Phno");
            phNo = Console.ReadLine();
            Console.WriteLine("Enter supplier email");
            email= Console.ReadLine();
        }
        public void Display()
        {
            Console.WriteLine("supplierId:" + supplierId);
            Console.WriteLine("supplierName:" + supplierName);
            Console.WriteLine("suppliercity:" + city);
            Console.WriteLine("supplierPhno:" + phNo);
            Console.WriteLine("supplierEmail:" + email);
        }
    }
}
