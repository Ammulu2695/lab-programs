﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductDetails;

namespace Console7._2
{
    class Program
    {
        static ArrayList product = new ArrayList();
        static void Main(string[] args)
        {
            PrintMenu();
            Console.ReadLine();
        }

        static void PrintMenu()
        {
            Product pro = new Product();
            string choice1;
            do
            {
                Console.WriteLine("select ur choice:");
                Console.WriteLine("1. Add Product\n2. Display Product\n3. Delete Product\n4. Search Product");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddProduct();
                        break;
                    case 2:
                        DisplayProduct();
                        break;
                    case 3:
                        DeleteProduct();
                        break;
                    case 4:
                        SearchProduct();
                        break;
                }
                Console.WriteLine("Do you want to continue(y/n)?");
                choice1 = Console.ReadLine();
            } while (choice1 == "y");
            Console.ReadLine();
        }

        static void AddProduct()
        {
            Product pro = new Product();
            Console.WriteLine("Enter Product id:");
            pro.ProductNo = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Product name: ");
            pro.ProductName = Console.ReadLine();
            Console.WriteLine("Enter Rate: ");
            pro.Rate = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Stock: ");
            pro.Stock = Convert.ToDouble(Console.ReadLine());
            product.Add(pro);
        }

        static void DisplayProduct()
        {
            ArrayList prod = product;
            Console.WriteLine("no   name   cell");
            foreach (Product c in prod)
            {
                Console.WriteLine(c.ProductNo + " " + c.ProductName + " " + c.Rate+" "+c.Stock);
            }
        }

        static void DeleteProduct()
        {
            try
            {
                Console.WriteLine("Enter Product number to delete that Product");
                int ProdNo = int.Parse(Console.ReadLine());
                int index = 0;
                for (index = 0; index < product.Count; index++)
                {
                    Product pro = product[index] as Product; if (ProdNo == pro.ProductNo)
                    {
                        product.Remove(pro);
                        Console.WriteLine("Product Removed");
                    }
                    else
                    {
                        Console.WriteLine("Product is Not Available");
                    }
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        static void SearchProduct()
        {
            Console.WriteLine("ProductNo");
            int ProductNo = int.Parse(Console.ReadLine());
            for(int i = 0; i < product.Count; i++)
            {
                Product pro = product[i] as Product;
                if(ProductNo == pro.ProductNo)
                {
                    Console.WriteLine(pro.ProductNo + " " + pro.ProductName + " " + pro.Rate + " " + pro.Stock);
                }
                else
                {
                    Console.WriteLine("Product not found");
                }
            }
        }
    }
}
