﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class OnlineShopping
    {
        public int CustomerID { get; set; }
        public List<string> Cart { get; set; }
    }
}
