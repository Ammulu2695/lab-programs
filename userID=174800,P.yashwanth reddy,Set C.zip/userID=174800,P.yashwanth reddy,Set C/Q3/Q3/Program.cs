﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        //created an delegate for class to call method
        public delegate void MyDelegate(int id);
        static void Main(string[] args)
        {
            //created List for onlineshopping to store items
            OnlineShopping os = new OnlineShopping();
            List<OnlineShopping> shopping = new List<OnlineShopping>();
            //Adding items to online shopping List
            shopping.Add(new OnlineShopping { CustomerID = 1001, Cart = new List<string> { "Dress", "Mobile" } });
            shopping.Add(new OnlineShopping { CustomerID = 1080, Cart = new List<string> { "Shirt", "Laptop", "Watch", "Cap" } });
            shopping.Add(new OnlineShopping { CustomerID = 1072, Cart = new List<string> { "Watch", "Sunglass", "shoes" } });
            shopping.Add(new OnlineShopping { CustomerID = 1045, Cart = new List<string> { "Table" } });
            MyDelegate del=delegate 

        }
    }
}
