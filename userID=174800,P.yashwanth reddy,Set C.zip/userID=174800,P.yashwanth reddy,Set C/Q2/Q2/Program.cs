﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            double Amount;

            //creating an object for a classs
            Account cd = new Account();
            Console.WriteLine("Enter Credit Card No");
            cd.CreditCardNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Credit Card Name");
            cd.CardHolderName = Console.ReadLine();


            string choice1;
            do
            {
                Console.WriteLine("Enter your Choice \n1.GetBalance" +
                    "\n2.WithDrawnAmount \n3.Exit");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Balance in your account is:" +cd.BalanceAmount);
                        break;


                    case 2:
                        Console.WriteLine("Enter amount to Withdraw");
                        double amount = Convert.ToDouble(Console.ReadLine());
                        cd.PaymentSuccessful += new MakePaymentHandler(CatchEvent);
                        cd.Withdraw(amount, "Payment Successfully Done");
                        break;

                    case 3:
                        Environment.Exit(0);
                        break;
                   

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("Do you want to contiue(y/n)?");
                choice1 = Console.ReadLine();
            } while ((choice1 == "y"));
            Console.Read();
        }
        //created event for delegate
        public static void CatchEvent(string s)
        {
            Console.WriteLine("your BAlance Amount is less than 1000 ");
        }
    }
}
