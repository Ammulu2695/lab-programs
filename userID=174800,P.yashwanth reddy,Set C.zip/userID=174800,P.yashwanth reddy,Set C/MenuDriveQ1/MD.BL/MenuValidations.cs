﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using MD.DAL; //Referance to Menuopertion Class library
using MD.Entity; //Referance to Entity Class library
using MD.Exception; //Referance to Exeception Class library

namespace MD.BL
{
    /// <summary>
    /// Employee ID:174800
    /// Employee Name;yashwanth
    /// Date of Creation:12-mar-2019
    /// Description:Database Operation on menu Class
    /// </summary>
    public class MenuValidations
    {
        //to validate manu details
        public static bool ValidateMenu(Menu m)
        {
            bool mValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {

                if (m.MovieTitle == String.Empty)
                {
                    mValidated = false;
                    message.Append("Movie  name should be provided\n");
                }
                else if (!Regex.IsMatch(m.MovieTitle, "[A-Z][a-z]{2,}"))
                {
                    mValidated = false;
                    message.Append("Movie name should start with capital and minimum 3 charaters");
                }
                //checking Publisher
                if (m.Publisher == string.Empty)
                {
                    mValidated = false;
                    message.Append("publisher name should be provided");

                }
                else if (!Regex.IsMatch(m.MovieTitle, "[A-Z][a-z]{2,}"))
                {
                    mValidated = false;
                    message.Append("Movie name should start with capital and minimum 3 charaters");
                }

                //checking rating

                if (m.Acting < 0 || m.Acting > 5)
                {
                    mValidated = false;
                    message.Append("movie rate should be <0 and >5");
                }
                if (m.Length < 0 || m.Length > 4)
                {
                    mValidated = false;
                    message.Append("movie Length should be <0 and >4");
                }
                //checking rating

                if (m.Music < 0 || m.Music > 5)
                {
                    mValidated = false;
                    message.Append("music rate should be <0 and >5");
                }
                if (m.Cinematography < 0 || m.Cinematography > 5)
                {
                    mValidated = false;
                    message.Append("cinematography rate should be <0 and >5");
                }
                if (m.Duration < 0 || m.Duration > 5)
                {
                    mValidated = false;
                    message.Append("Duration rate should be <0 and >5");
                }
                //cheching date of joining

                if (mValidated == false)
                {
                    throw new MenuException(message.ToString());
                }
            }
            catch (MenuException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return mValidated;
        }
        public static bool AddMenu(Menu m)
        {
            bool mAdded = false;
            try
            {
                if (ValidateMenu(m))
                {
                    mAdded = MenuOpertion.AddMenu(m);
                }
                else
                {
                    throw new MenuException("please provide valid data for employee");
                }
            }
            catch (MenuException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return mAdded;
        }
        public static bool UpdateMenu(Menu m)
        {
            bool mupdated = false;
            try
            {
                if (ValidateMenu(m))
                {
                    mupdated = MenuOpertion.UpdateEmployee(m);
                }
                else
                {
                    throw new MenuException("please provid ");
                }
            }
            catch (MenuException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return mupdated;
        }
        public static bool DeleteMenu(string mTitle)
        {
            bool mDeleted = false;
            try
            {
                mDeleted = MenuOpertion.DeleteMenu(mTitle);
            }
            catch (MenuException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return mDeleted;
        }
        public static Menu SearchMenu(string mTilte)
        {
            Menu m = null;
            try
            {
                m = MenuOpertion.SearchMenu(mTilte);
            }
            catch (MenuException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return m;
        }
        public static List<Menu> RetrieveMenu()
        {
            List<Menu> mList = MenuOpertion.RetrieveMenu();
            return mList;
        }
        public static bool SeralizeMenu()
        {
            bool mSerailzed = false;
            try
            {

            }
            catch (MenuException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return mSerailzed;
        }
        public static List<Menu> DeserializeMenu()
        {
            List<Menu> mDeList = null;
            try
            {
                mDeList = MenuOpertion.DeseralizeMenu();
            }
            catch (MenuException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return mDeList;
        }
    }
}
