﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MD.Entity;//Referance to Entity Class library
using MD.Exception;//Referance to Exception Class library
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
namespace MD.DAL
{
    /// <summary>
    /// Employee ID:174800
    /// Employee Name;yashwanth
    /// Date of Creation:12-mar-2019
    /// Description:Database Operation on Employee Class
    /// </summary>
    public class MenuOpertion
    {
        static List<Menu> mList = new List<Menu>();
        //TO insert the menu record in menu list
        public static bool AddMenu(Menu m)
        {
            bool mAdded = false;

            try
            {
                mList.Add(m);
                mAdded = true;
            }
            catch (MenuException ex)
            {
                throw ex;

            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return mAdded;
        }
        public static bool UpdateEmployee(Menu m)
        {
            bool mUdated = false;
            try
            {
                for (int i = 0; i < mList.Count; i++)
                {
                    //Searching menu to update
                    if (mList[i].MovieTitle == m.MovieTitle)
                    {
                        mList[i].MovieReleased = m.MovieReleased;
                        mList[i].Publisher = m.Publisher;
                        mList[i].Length = m.Length;
                        mList[i].Acting = m.Acting;
                        mList[i].Music = m.Music;
                        mList[i].Cinematography = m.Cinematography;
                        mList[i].Duration = m.Duration;
                        mUdated = true;

                    }
                }
            }
            catch (MenuException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return mUdated;
        }
        public static bool DeleteMenu(string mTitle)
        {
            bool mDeleted = false;
            try
            {
                Menu m = mList.Find(e => e.MovieTitle == mTitle);
                if (m != null)
                {

                    mList.Remove(m);
                    mDeleted = true;
                }
                else
                {
                    throw new MenuException("Movie TItle" + mTitle + "does not exist");
                }
            }
            catch (MenuException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return mDeleted;
        }
        //searching for movie details
        public static Menu SearchMenu(string mTitle)
        {
            Menu m = null;
            try
            {
                m = mList.Find(e => e.MovieTitle == mTitle);
            }
            catch (MenuException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return m;
        }
        //To retrieve all menu
        public static List<Menu> RetrieveMenu()
        {
            return mList;
        }
        //To Serialize Menu list
        public static bool SeralizeMenu()
        {
            bool mSerialized = false;
            try
            {
                FileStream fs = new FileStream("Menu.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, mList);
                fs.Close();
                mSerialized = true;
            }
            catch (MenuException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return mSerialized;
        }
        public static List<Menu> DeseralizeMenu()
        {
            List<Menu> mDeList = null;
            try
            {
                FileStream fs = new FileStream("Menu.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                mDeList = (List<Menu>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (MenuException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return mDeList;
        }
    }
}
