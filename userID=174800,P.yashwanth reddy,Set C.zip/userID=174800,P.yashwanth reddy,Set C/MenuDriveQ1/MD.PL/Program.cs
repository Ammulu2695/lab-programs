﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MD.DAL; //Referance to Menuopertion Class library
using MD.Entity; //Referance to Entity Class library
using MD.Exception; //Referance to Exeception Class library
using MD.BL;
namespace MD.PL
{
    class Program
    {

        /// <summary>
        /// Employee ID:174800
        /// Employee Name;yashwanth
        /// Date of Creation:12-mar-2019
        /// Description:Database Operation on menu Class
        /// </summary>
        static void Main(string[] args)
        {
            try
            {
                Menu m = new Menu();
                Console.Write("Enter Movie title :");
                m.MovieTitle =Console.ReadLine();

                Console.Write("Enter Movie Reeased :");
                m.MovieReleased=Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter publiser :");
                m.Publisher = Console.ReadLine();
                Console.Write("Enter movie length :");
                m.Length= Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter movie Acting :");
                m.Acting = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter movie Music :");
                m.Music = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter movie Cinematography :");
                m.Cinematography = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter movie Duration :");
                m.Duration = Convert.ToInt32(Console.ReadLine());

                bool empAdded = MenuValidations.AddMenu(m);
                if (empAdded)
                {
                    Console.WriteLine("Employee Added sucessfully");
                }
                else
                {
                    throw new MenuException("Employee not added");
                }
            }
            catch (MenuException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        public static void UpdatedEmployee()
        {
            try
            {
                Menu m = new Menu();
                Console.Write("Enter Movie title :");
                m.MovieTitle = Console.ReadLine();

                Console.Write("Enter Movie Reeased :");
                m.MovieReleased = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter publiser :");
                m.Publisher = Console.ReadLine();
                Console.Write("Enter movie length :");
                m.Length = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter movie Acting :");
                m.Acting = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter movie Music :");
                m.Music = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter movie Cinematography :");
                m.Cinematography = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter movie Duration :");
                m.Duration = Convert.ToInt32(Console.ReadLine());
                bool empUpdated = MenuValidations.AddMenu(m);
                if (empUpdated)
                {
                    Console.WriteLine("Menu updated sucessfully");
                }
                else
                {
                    throw new MenuException("Menu not updated");
                }
            }
            catch (MenuException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void Deleteemployee()
        {
            try
            {
                string mTitle;
                Console.Write("enter Movie to be delete");
                mTitle = Console.ReadLine();
                bool empDeleted = MenuValidations.DeleteMenu(mTitle);
                if (empDeleted)
                {
                    Console.WriteLine("Movie deleted successfully");
                }
                else
                {
                    throw new MenuException("Menu not deleted");
                }
            }
            catch (MenuException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void Searchemployee()
        {
            try
            {
                string mTitle;
                Console.Write("enter Title to be search");
                mTitle = Console.ReadLine();
                Menu emp = MenuValidations.SearchMenu(mTitle);
                if (mTitle != null)
                {
                    Console.WriteLine($"{emp.MovieTitle}");
                    Console.WriteLine($"{emp.MovieReleased}");
                    Console.WriteLine($"{emp.Publisher}");
                    Console.WriteLine($"{emp.Length}");
                    Console.WriteLine($"{emp.Acting}");
                    Console.WriteLine($"{emp.Music}");
                    Console.WriteLine($"{emp.Cinematography}");
                    Console.WriteLine($"{emp.Duration}");
                }
                else
                {
                    throw new MenuException("menu not found");
                }
            }
            catch (MenuException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void RetrievMenu()
        {
            try
            {
                List<Menu> empList = MenuValidations.RetrieveMenu();
                if (empList != null || empList.Count > 0)
                {
                    
                    foreach (var emp in empList)
                    {
                        Console.WriteLine($"{emp.MovieTitle},{emp.MovieReleased},{emp.Publisher},{emp.Length},{emp.Acting},{emp.Cinematography},{emp.Music},{emp.Duration}");
                    }
                    Console.WriteLine("----------------------------------------------");
                }
                else
                {
                    throw new MenuException("MEnu data");
                }
            }
            catch (MenuException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SerializeMenu()
        {
            try
            {
                bool empSerialized = MenuValidations.SeralizeMenu();
                if (empSerialized)
                {
                    Console.WriteLine("Menu data serialized ");
                }
                else
                {
                    throw new MenuException("Menu data");
                }
            }
            catch (MenuException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        public static void Deserializeemployee()
        {
            try
            {
                List<Menu> empList = MenuValidations.DeserializeEmployee();
                if (empList != null || empList.Count > 0)
                {
                    
                    foreach (var emp in empList)
                    {
                        Console.WriteLine($"{emp.MovieTitle},{emp.MovieReleased},{emp.Publisher},{emp.Length},{emp.Acting},{emp.Cinematography},{emp.Music},{emp.Duration}");
                    }
                    Console.WriteLine("----------------------------------------------");
                }
                else
                {
                    throw new EmployeeExeception("employee data");
                }
            }
            catch (EmployeeExeception ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
    
}
