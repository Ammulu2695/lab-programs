﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MD.Exception
{
    /// <summary>
    /// Employee ID:174800
    /// Employee Name:yashwanth
    /// Date of Creation:12-mar-2019
    /// Description:user Defined Execption class to handle exeception
    /// </summary>
    public class MenuException:ApplicationException
    {
        //Default Constructor
        public MenuException() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public MenuException(String message) : base(message)
        { }
    }
}
