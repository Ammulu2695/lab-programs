﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MD.Entity
{
    /// <summary>
    /// Employee ID :174800
    /// Employee Name:yashwanth
    /// Date of Creation:12-mar-2019
    /// Description:Entity Class for Employee
    /// </summary>
    [Serializable]
    public class Menu
    {
        //Get or set MovieTitle
        public string MovieTitle { get; set; }
        //Get or set MovieReleased
        public DateTime MovieReleased { get; set; }
        //Get or set Publisher
        public string Publisher { get; set; }
        //Get or set Length
        public int Length { get; set; }
        //Get or set Acting
        public int Acting { get; set; }
        //Get or set Music
        public int Music { get; set; }
        //Get or set Cinematography
        public int Cinematography { get; set; }
        //Get or set Duration
        public int Duration { get; set; }
    }
}
