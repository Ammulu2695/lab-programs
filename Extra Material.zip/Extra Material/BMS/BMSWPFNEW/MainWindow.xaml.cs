﻿using BMS.BL;
using BMS.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BMSWPFNEW
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void GetAllBooks()
        {
            try
            {
                List<Book> booklist = BMSBL.GetAllBookBL();

                dgBooks.ItemsSource = booklist.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Book newbook = new Book();
                newbook.BookName = txtBookName.Text;
                newbook.Author = txtAuthorName.Text;
                newbook.Price = Convert.ToDouble(txtPrice.Text);

                bool status = BMSBL.AddBookBL(newbook);

                if (status)
                {
                    MessageBox.Show("Book Added");
                    GetAllBooks();

                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Unable to add book");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); ;
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
             try
            {
                Book updatebook = new Book();
                updatebook.BookName = txtBookName.Text;
                updatebook.Author = txtAuthorName.Text;
                updatebook.Price = Convert.ToDouble(txtPrice.Text);
                updatebook.BookId = Convert.ToInt32(txtID.Text);

                bool status = BMSBL.UpdateBookBL(updatebook);

                if (status)
                {
                    MessageBox.Show("Book Updated");
                    ClearFields();
                    GetAllBooks();
                }
                else
                {
                    MessageBox.Show("Unable to Update Book");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtID.Text);
                bool status = BMSBL.DeleteBookBL(id);

                if (status)
                {
                    MessageBox.Show("Book Deleted");
                    ClearFields();
                    GetAllBooks();
                }
                else
                {
                    MessageBox.Show("Unable to delete book");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetAllBooks();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Book book = null;
                int id = Convert.ToInt32(txtID.Text);
                book = BMSBL.GetBookBL(id);

                if (book != null)
                {
                    MessageBox.Show("Book Found...");
                    txtBookName.Text = book.BookName;
                    txtAuthorName.Text = book.Author;
                    txtPrice.Text = book.Price.ToString();
                }
                else
                {
                    MessageBox.Show("Unable to Find Book....");
                    txtID.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ClearFields()
        {
            txtBookName.Text = "";
            txtAuthorName.Text = "";
            txtPrice.Text = "";
        }

    }
}
