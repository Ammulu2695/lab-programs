select * from Book

Create table Books
(
	bookid int identity primary key,
	bookname varchar(25),
	author varchar(20),
	price float
)

go
create proc udp_getbooks
as
begin
select * from Books
end
go

go
create proc udp_getbookbyid(@id int)
as
begin
select * from books where bookid=@id
end
go

go
create proc udp_insertbook(@name varchar(50),
@author varchar(50),@price float)
as
begin
insert into books(bookname,author,price) 
values(@name,@author,@price)
end 
go

go
create proc udp_updatebook(@name varchar(50)
,@author varchar(50),@price float,@id int)
as
begin
update Books set bookname= @name, author=@author, 
price = @price where bookid=@id
end 
go

go
create proc udp_deletebook(@id int)
as
begin
delete from books where bookid=@id
end 
go

exec udp_getbooks

insert into Books(bookname,author,price)
values ('Asp.Net MVC','Scott Hansleman',1234.88)