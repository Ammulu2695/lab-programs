﻿using System;

using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BMS.Entities;
using BMS.Exceptions;
using System.Data;

namespace BMS.DAL
{
    public class BMSDAL
    {
        SqlConnection conn = 
            new SqlConnection(ConfigurationManager.ConnectionStrings["bookconn"].ConnectionString);
        SqlCommand cmd;

        public bool AddBookDAL(Book book)
        {
            bool bookadded = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_insertbook";
                cmd.Parameters.AddWithValue("@name", book.BookName);
                cmd.Parameters.AddWithValue("@author", book.Author);
                cmd.Parameters.AddWithValue("@price", book.Price);
                cmd.Connection = conn;

                conn.Open();

                int result = cmd.ExecuteNonQuery();

                conn.Close();

                if (result > 0)
                    bookadded = true;
            }
            catch (Exception ex)
            {
                throw new BookException(ex.Message);
            }

            return bookadded;
        }        

        public List<Book> GetAllBooksDAL()
        {
            List<Book> booklist= null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_getbooks";
                cmd.Connection = conn;
                conn.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                booklist = new List<Book>();
                while (dr.Read())
                {
                    Book book = new Book();
                    book.BookId = dr.GetInt32(0);
                    book.BookName = dr.GetString(1);
                    book.Author = dr.GetString(2);
                    book.Price = dr.GetDouble(3);

                    booklist.Add(book);
                }
            }
            catch (Exception ex)
            {
                throw new BookException(ex.Message);
            }
            return booklist;
        }

        public Book GetBookDAL(int id)
        {
            Book book = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_getbookbyid";
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Connection = conn;
                
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    book = new Book();
                    book.BookId = dr.GetInt32(0);
                    book.BookName = dr.GetString(1);
                    book.Author = dr.GetString(2);
                    book.Price = dr.GetDouble(3);
                }
            }
            catch (Exception ex)
            {
                throw new BookException(ex.Message);
            }
            return book;
        }

        public bool UpdateBookDAL(Book book)
        {
            bool bookupdate = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_updatebook";
                cmd.Parameters.AddWithValue("@name", book.BookName);
                cmd.Parameters.AddWithValue("@author", book.Author);
                cmd.Parameters.AddWithValue("@price", book.Price);
                cmd.Parameters.AddWithValue("@id", book.BookId);
                cmd.Connection = conn;

                conn.Open();

                int result = cmd.ExecuteNonQuery();

                conn.Close();

                if (result > 0)
                    bookupdate = true;
            }
            catch (Exception)
            {
                
                throw;
            }
            return bookupdate;
        }

        public bool DeleteBookDAL(int id)
        {
            bool bookdelete = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_deletebook";
                cmd.Parameters.AddWithValue("@id", id);
              
                cmd.Connection = conn;

                conn.Open();

                int result = cmd.ExecuteNonQuery();

                conn.Close();

                if (result > 0)
                    bookdelete = true;
            }
            catch (Exception ex)
            {
                throw new BookException(ex.Message);
            }
            return bookdelete;
        }
    }
}
