﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankEntity
{
    public class Bank
    {
        public enum AccountTypeEnum { Saving=1, Current };
        public string CustomerName { get; set; }
        public int CurrentAccountNumber { get; set; }
        public int SavingAccountNumber { get; set; }
        public double AccountBal { get; set; }
        public AccountTypeEnum AccountType;
    }
}
