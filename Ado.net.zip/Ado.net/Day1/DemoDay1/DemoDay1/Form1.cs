﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Namespace for sql server
using System.Data.SqlClient;
namespace DemoDay1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data source =NDAMSSQL\sqlilearn;initial catalog=Training_20Feb_Mumbai;user id =sqluser;password=sqluser");

               SqlDataAdapter da = new SqlDataAdapter("Select * from Customer" ,con);
     
            DataSet ds = new DataSet();
            da.Fill(ds);
            //dataGridView1.DataSource = ds.Tables[0].DefaultView;
            DataView dv = new DataView(ds.Tables[0]);
            dv.RowFilter = "City='Mumbai'";
            dataGridView1.DataSource = dv;
        }

       
    }
}
