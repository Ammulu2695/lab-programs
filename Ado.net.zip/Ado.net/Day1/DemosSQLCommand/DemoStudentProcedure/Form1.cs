﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace DemoStudentProcedure
{
    public partial class Form1 : Form
    {
        string SqlConnectionString = @"Data source =NDAMSSQL\sqlilearn;initial catalog=Training_20Feb_Mumbai;user id =sqluser;password=sqluser";
        SqlConnection cncon;
        SqlCommand cmdQuery;
        public Form1()
        {
            InitializeComponent();
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            cncon = new SqlConnection(SqlConnectionString);
            cncon.Open();
            SqlCommand cmdInsert = new SqlCommand();
            cmdInsert.Connection = cncon;
            cmdInsert.CommandType = CommandType.StoredProcedure;
            cmdInsert.CommandText = "usp_InsertCustomer";
            cmdInsert.Parameters.AddWithValue("@CID",txtId.Text);
            cmdInsert.Parameters.AddWithValue("@FName", txtFN.Text);
            cmdInsert.Parameters.AddWithValue("@LName", txtLN.Text);
            cmdInsert.Parameters.AddWithValue("@Address", txtADD.Text);
            cmdInsert.Parameters.AddWithValue("@City", txtCity.Text);
            cmdInsert.Parameters.AddWithValue("@Country", txtCountry.Text);
            cmdInsert.Parameters.AddWithValue("@Phone", txtPhone.Text);
            int iRowAffected;
            iRowAffected = cmdInsert.ExecuteNonQuery();
            if (iRowAffected>=1)
            {
                MessageBox.Show("Data inserted");

            }

            else
            {
                MessageBox.Show("Error");

            }
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}
