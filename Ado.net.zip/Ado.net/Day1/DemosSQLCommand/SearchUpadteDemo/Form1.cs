﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace SearchUpadteDemo
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }
        //search
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(@"Data source = NDAMSSQL\sqlilearn; initial catalog = Training_20Feb_Mumbai; user id = sqluser; password = sqluser");
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "usp_Select_StudentDetails";
            SqlParameter param1 = new SqlParameter("@RollNo", SqlDbType.Int);
            command.Parameters.Add(param1);
            command.Parameters["@Rollno"].Value = txtrolno.Text;
            connection.Open();
            SqlDataReader dr;
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                txtFN.Text = dr.GetString(0);
                txtLN.Text = dr.GetString(1);
               txtGn.Text = dr.GetString(2);
                txtAge.Text = dr.GetInt32(3).ToString();
              
                txtADD.Text = dr.GetString(4);
            }

        }
        //upadte
        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(@"Data source = NDAMSSQL\sqlilearn; initial catalog = Training_20Feb_Mumbai; user id = sqluser; password = sqluser");
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "UPDATE DNSTUDENT SET FirstName =@FirstName," +
                "LastName =@LastName,  Gender=@Gender, Age=@Age, Address=@Address " + "where RollNo=@RollNo";
            command.Parameters.Clear();
            command.Parameters.AddWithValue("@FirstName", txtFN.Text);
            command.Parameters.AddWithValue("@LastName", txtLN.Text);
            command.Parameters.AddWithValue("@Gender", txtGn.Text);
            command.Parameters.AddWithValue("@Age", Convert.ToInt32(txtAge.Text));
            command.Parameters.AddWithValue("@Address", txtADD.Text);
            command.Parameters.AddWithValue("@RollNo", Convert.ToInt32(txtrolno.Text));

            try
            {
                connection.Open();
                int result = command.ExecuteNonQuery();
                if (result > 0)
                    MessageBox.Show("update succesfull");
                else
                    MessageBox.Show("update failed!!!");
             
            }
            catch (SqlException ex)
            {

                MessageBox.Show("An error occured." + ex.Message);
            }
            finally
            {
                connection.Close();
            }
            
        }
    }
}
