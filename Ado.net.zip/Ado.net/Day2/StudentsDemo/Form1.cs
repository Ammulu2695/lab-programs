﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace StudentsDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string SqlConnectionString = @"Data source =NDAMSSQL\sqlilearn;initial catalog=Training_20Feb_Mumbai;user id =sqluser;password=sqluser";
        SqlConnection cncon;
        SqlCommand cmdQuery;

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            cncon = new SqlConnection(SqlConnectionString);
            cncon.Open();
            SqlCommand cmdInsert = new SqlCommand();
            cmdInsert.Connection = cncon;
            cmdInsert.CommandType = CommandType.StoredProcedure;
            cmdInsert.CommandText = "insertVSTUDENT_174780";
            cmdInsert.Parameters.AddWithValue("@StudentId", txtID.Text);
            cmdInsert.Parameters.AddWithValue("@StudentName", txtName.Text);
            cmdInsert.Parameters.AddWithValue("@Qualifaction", txtQua.Text);
            cmdInsert.Parameters.AddWithValue("@City", txtcity.Text);

            
           int   iRowAffected = cmdInsert.ExecuteNonQuery();
            if (iRowAffected >0)
            {
                MessageBox.Show("Data inserted");

            }

            else
            {
                MessageBox.Show("Error");

            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(@"Data source = NDAMSSQL\sqlilearn; initial catalog = Training_20Feb_Mumbai; user id = sqluser; password = sqluser");
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "SearchVSTUDENT1_174780";
            SqlParameter param1 = new SqlParameter("@StudentID", SqlDbType.Int);
            command.Parameters.Add(param1);
            command.Parameters["@StudentID"].Value =Convert.ToInt32(txtSt.Text);
            connection.Open();
            SqlDataReader dr;
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                txtID.Text = dr.GetInt32(0).ToString();
                txtName.Text = dr.GetString(1);
                txtQua.Text = dr.GetString(2);
                txtcity.Text = dr.GetString(3);

              
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(@"Data source = NDAMSSQL\sqlilearn; initial catalog = Training_20Feb_Mumbai; user id = sqluser; password = sqluser");
            SqlCommand command = new SqlCommand();
            
            command.Connection = connection;
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "DeleteVSTUDENT_174780";
            command.Parameters.Clear();
            //SqlParameter param1 = new SqlParameter("@StudentID", SqlDbType.Int);
            //command.Parameters.Add(param1);
            //command.Parameters["@StudentID"].Value = txtI.Text;
            connection.Open();
            command.Parameters.AddWithValue("@StudentID", txtSt.Text);
            if (command.ExecuteNonQuery() >= 1)
                MessageBox.Show("deleted");
            else
            {
                MessageBox.Show("Not Deleted");
            }
            connection.Close();
           

        }
    }
}
