﻿using System;
using System.Data;
using System.Windows.Forms;
namespace DataSetTableDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        DataTable dt;
        private void Form1_Load(object sender, EventArgs e)
        {
            //Adding Columns
            dt = new DataTable();
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Department", System.Type.GetType("System.String"));
            dt.Columns.Add("City", typeof(string));
            //Adding Rows
            dt.Rows.Add(111, "Harshitha", "IT", "Mumabi");
            dt.Rows.Add(222, "Naveen", "IT", "Pune");
            dt.Rows.Add(333, "Bharath", "IT", "Hyderbad");
            DataSet ds = new DataSet();
            ds.Tables.Add(dt);
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dt.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dt.GetChanges();
            dataGridView1.DataSource = dt;
        }
    }
}
