﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace DataRelationDemos1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string categorySQL = "SELECT * from Categories";
        string productSQL = "SELECT * from Products";
        DataSet ds = new DataSet();
        DataRelation relation;
        private void LstCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            LstProduct.Items.Clear();
            DataRow[] rows = ds.Tables["Categories"].Select("categoryName = '" + LstCategories.Text + "'");
            DataRow parent = rows[0];
            foreach (DataRow child in parent.GetChildRows(relation))
            {
                LstProduct.Items.Add(child["ProductName"]);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data source =NDAMSSQL\sqlilearn;initial catalog=Northwind;user id =sqluser;password=sqluser");
            SqlCommand com = new SqlCommand(categorySQL, con);
            SqlDataAdapter adapter = new SqlDataAdapter(com);
            con.Open();
            adapter.Fill(ds, "Categories");
            adapter.SelectCommand.CommandText = productSQL;
            adapter.Fill(ds, "Products");
            con.Close();
            DataColumn parentCol = ds.Tables["Categories"].Columns["categoryID"];
            DataColumn childCol = ds.Tables["Products"].Columns["categoryID"];
            relation = new DataRelation("Cat_Prod", parentCol, childCol);
            ds.Relations.Add(relation);

            foreach (DataRow row in ds.Tables["Categories"].Rows)
            {
                LstCategories.Items.Add(row["CategoriesName"]);

            }
        }
    }
}
