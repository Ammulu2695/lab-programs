﻿namespace DataRelationDemos1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LstCategories = new System.Windows.Forms.ListBox();
            this.LstProduct = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // LstCategories
            // 
            this.LstCategories.FormattingEnabled = true;
            this.LstCategories.Location = new System.Drawing.Point(214, 85);
            this.LstCategories.Name = "LstCategories";
            this.LstCategories.Size = new System.Drawing.Size(120, 95);
            this.LstCategories.TabIndex = 0;
            this.LstCategories.SelectedIndexChanged += new System.EventHandler(this.LstCategories_SelectedIndexChanged);
            // 
            // LstProduct
            // 
            this.LstProduct.FormattingEnabled = true;
            this.LstProduct.Location = new System.Drawing.Point(482, 85);
            this.LstProduct.Name = "LstProduct";
            this.LstProduct.Size = new System.Drawing.Size(120, 95);
            this.LstProduct.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LstProduct);
            this.Controls.Add(this.LstCategories);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox LstCategories;
        private System.Windows.Forms.ListBox LstProduct;
    }
}

