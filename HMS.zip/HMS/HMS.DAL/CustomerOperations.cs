﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using HMS;
using HMS.Exception;

namespace HMS.DAL
{
    public class CustomerOperations
    {
       static List<Customer> cusList = new List<Customer>();

        //To insert the Customer record in Customer list
        public static bool AddCustomer(Customer cus)
        {
            bool cusAdded = false;

            try
            {
                //Adding employee object into employee list
                cusList.Add(cus);
                cusAdded = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusAdded;
        }

        //To modify the Customer data from the list
        public static bool UpdateCustomer(Customer cus)
        {
            bool cusUpdated = false;

            try
            {
                for (int i = 0; i < cusList.Count; i++)
                {
                    //Searching Customer to update
                    if (cusList[i].CustomerID == cus.CustomerID)
                    {
                        //Modifying employee details
                        cusList[i].CustomerName = cus.CustomerName;
                        cusList[i].PhoneNo = cus.PhoneNo;
                        cusList[i].Address = cus.Address;
                        cusList[i].DOJ = cus.DOJ;
                        cusList[i].City = cus.City;
                        cusList[i].Vocate = cus.Vocate;


                        cusUpdated = true;
                    }
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusUpdated;
        }

        //To delete Customer from Customer list
        public static bool DeleteCustomer(int CustomerID)
        {
            bool cusDeleted = false;

            try
            {
                //Searching Customer
                Customer cus = cusList.Find(e => e.CustomerID == CustomerID);

                if (cus != null)
                {
                    //Deleting Customer from Customer list
                    cusList.Remove(cus);
                    cusDeleted = true;
                }
                else
                {
                    throw new CustomerException("Customer with ID " + CustomerID + " does not exist for Delete");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusDeleted;
        }

        //To search Customer based on Customer ID
        public static Customer SearchCustomer(int CustomerID)
        {
            Customer cus = null;

            try
            {
                //Searching Customer
                cus = cusList.Find(e => e.CustomerID == CustomerID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cus;
        }

        //To retrieve all Customer
        public static List<Customer> RetrieveCustomer()
        {
            return cusList;
        }

        //To Serialize Customer list
        public static bool SerializeCustomer()
        {
            bool cusSerialized = false;

            try
            {
                FileStream fs = new FileStream("Employee.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, cusList);
                fs.Close();
                cusSerialized = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusSerialized;
        }

        //To deserialize Customer List
        public static List<Customer> DeserializeCustomer()
        {
            List<Customer> cusDesList = null;

            try
            {
                FileStream fs = new FileStream("Employee.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                cusDesList = (List<Customer>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusDesList;
        }
    }
}

