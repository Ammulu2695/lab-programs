﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS;
using HMS.Exception;
using HMS.BL;

namespace HMS.PL
{
    class Program
    {
        public static void AddCustomer()
        {
            try
            {
                Customer cus = new Customer();
                Console.Write("Enter Customer ID : ");
                cus.CustomerID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Employee Name : ");
                cus.CustomerName = Console.ReadLine();
                Console.Write("Enter Phone Number : ");
                cus.PhoneNo = Console.ReadLine();
                //Console.Write("Enter Date of Birth : ");
                //emp.DOB = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter Date of Joining : ");
                cus.DOJ = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter Date of Vocate : ");
                cus.Vocate = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter City : ");
                cus.City = Console.ReadLine();

                bool cusAdded = CustomerValidation.AddCustomer(cus);

                if (cusAdded)
                {
                    Console.WriteLine("Customer added successfully");
                }
                else
                {
                    throw new CustomerException("Customer not added");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateCustomer()
        {
            try
            {
                Customer cus = new Customer();
                Console.Write("Enter Employee ID to be updated : ");
                cus.CustomerID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter updated Employee Name : ");
                cus.CustomerName = Console.ReadLine();
                Console.Write("Enter updated Phone Number : ");
                cus.PhoneNo = Console.ReadLine();
                Console.Write("Enter Date of Vocate : ");
                cus.Vocate = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter updated Date of Joining : ");
                cus.DOJ = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter updated City : ");
                cus.City = Console.ReadLine();

                bool cusUpdated = CustomerValidation.UpdateCustomer(cus);

                if (cusUpdated)
                {
                    Console.WriteLine("Customer updated successfully");
                }
                else
                {
                    throw new CustomerException("Customer not updated");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteCustomer()
        {
            try
            {
                int CustomerID;
                Console.Write("Enter Customer ID to be Deleted : ");
                CustomerID = Convert.ToInt32(Console.ReadLine());

                bool cusDeleted = CustomerValidation.DeleteCustomer(CustomerID);

                if (cusDeleted)
                {
                    Console.WriteLine("Customer deleted successfully");
                }
                else
                {
                    throw new CustomerException("Customer not deleted");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchCustomer()
        {
            try
            {
                int CustomerID;
                Console.Write("Enter Customer ID to be Searched : ");
                CustomerID = Convert.ToInt32(Console.ReadLine());

                Customer cus = CustomerValidation.SearchCustomer(CustomerID);

                if (cus != null)
                {
                    Console.WriteLine($"Customer ID : {cus.CustomerID}");
                    Console.WriteLine($"Customer Name : {cus.CustomerName}");
                    Console.WriteLine($"Phone Number : {cus.PhoneNo}");
                    Console.WriteLine($"Date of Vocate : {cus.Vocate}");
                    Console.WriteLine($"Date of Joining : {cus.DOJ}");
                    Console.WriteLine($"City : {cus.City}");
                }
                else
                {
                    throw new CustomerException("Customer not found");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void RetrieveCustomer()
        {
            try
            {
                List<Customer> cusList = CustomerValidation.RetrieveCustomer();

                if (cusList != null || cusList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("Customer ID    Customer Name   Phone Number   Date of Vocate   Date of Joining   City");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var cus in cusList)
                    {
                        Console.WriteLine($"{cus.CustomerID}\t\t{cus.CustomerName}\t{cus.PhoneNo}\t{cus.Vocate}\t{cus.DOJ}\t{cus.City}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomerException("Customer data not available");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeCustomer()
        {
            try
            {
                bool cusSerialized = CustomerValidation.SerializeCustomer();

                if (cusSerialized)
                {
                    Console.WriteLine("Customer data serialized");
                }
                else
                {
                    throw new CustomerException("Customer data not serialized");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeCustomer()
        {
            try
            {
                List<Customer> cusDesList = CustomerValidation.DeserializeCustomer();

                if (cusDesList != null || cusDesList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("Customer ID    Customer Name   Phone Number   Date of Birth   Date of Joining   City");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var cus in cusDesList)
                    {
                        Console.WriteLine($"{cus.CustomerID}\t\t{cus.CustomerName}\t{cus.PhoneNo}\t{cus.Vocate}\t{cus.DOJ}\t{cus.City}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomerException("Customer data not available after deserialization");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1. Add Customer");
            Console.WriteLine("2. Update Customer");
            Console.WriteLine("3. Delete Customer");
            Console.WriteLine("4. Search Customer");
            Console.WriteLine("5. Display Customer");
            Console.WriteLine("6. Serialize Customer");
            Console.WriteLine("7. Deserialize Customer");
            Console.WriteLine("8. Exit");
            Console.WriteLine("***********************");
        }

        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());


                switch (choice)
                {
                    case 1:
                        AddCustomer();
                        break;
                    case 2:
                        UpdateCustomer();
                        break;
                    case 3:
                        DeleteCustomer();
                        break;
                    case 4:
                        SearchCustomer();
                        break;
                    case 5:
                        RetrieveCustomer();
                        break;
                    case 6:
                        SerializeCustomer();
                        break;
                    case 7:
                        DeserializeCustomer();
                        break;
                    case 8:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valida choice");
                        break;
                }
            } while (choice != 8);

            Console.ReadKey();
        }
    }
}
