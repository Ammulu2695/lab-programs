﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS
{
    public class Customer
    {

        //Get or set Customer ID
        public int CustomerID { get; set; }

        //Get or set customer Name
        public string CustomerName { get; set; }

        //Get or set Phone Number
        public string PhoneNo { get; set; }

        //Get or set Address proof
        public string Address { get; set; }

        //Get or set Date of Joining
        public DateTime DOJ { get; set; }

        //Get or set City
        public string City { get; set; }

        //Get or set Date of vocate
        public DateTime Vocate { get; set; }

    }
}
