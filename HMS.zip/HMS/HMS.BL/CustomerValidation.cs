﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS;
using HMS.Exception;
using HMS.DAL;
using System.Text.RegularExpressions;

namespace HMS.BL
{
    public class CustomerValidation

    {
        //To validate  Customer details
        public static bool ValidateCustomer(Customer cus)
        {
            bool cusValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - Customer id should be 6 digit
                if (cus.CustomerID < 100000 || cus.CustomerID > 999999)
                {
                    cusValidated = false;
                    message.Append("Customer ID should be exactly 6 digits long\n");
                }

                //Checking - Customer name
                if (cus.CustomerName == String.Empty)
                {
                    cusValidated = false;
                    message.Append("Customer Name should be provided\n");
                }
                else if (!Regex.IsMatch(cus.CustomerName, "[A-Z][a-z]{2,}"))
                {
                    cusValidated = false;
                    message.Append("Customer Name should start with capital alphabet and it should have minimum 3 alphabets\n");
                }

                //Checking Phone number
                if (cus.PhoneNo == string.Empty)
                {
                    cusValidated = false;
                    message.Append("Phone number should be provided\n");
                }
                else if (!Regex.IsMatch(cus.PhoneNo, "[6-9][0-9]{9}"))
                {
                    cusValidated = false;
                    message.Append("Phone number should start with 6/7/8/9 and it should have exactly 10 digits\n");
                }
                DateTime Vocate = default(DateTime);
                //Checking Date of Vocate
                //int Vocate = DateTime.Now;
                  if (Vocate >= DateTime.Now)
                {
                    cusValidated = false;
                    message.Append("Date of Vocate  should be more than or equal to today's date");
                }

                //Checking Date of Joining
                DateTime DOJ = default(DateTime);
                if (DOJ > DateTime.Now)
                {
                    cusValidated = false;
                    message.Append("Date of Joining should be less than or equal to today's date");
                }

                //Checking City
                if (cus.City == string.Empty)
                {
                    cusValidated = false;
                    message.Append("City should be provided");
                }
                else if (cus.City.ToLower() != "pune" &&
                        cus.City.ToLower() != "mumbai" &&
                        cus.City.ToLower() != "hyderabad" &&
                        cus.City.ToLower() != "bangalore")
                {
                    cusValidated = false;
                    message.Append("City should be either Pune or Mumbai or Hyderabad or Bangalore\n");
                }

                if (cusValidated == false)
                {
                    throw new CustomerException(message.ToString());
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusValidated;
        }

        public static bool AddCustomer(Customer cus)
        {
            bool cusAdded = false;

            try
            {
                if (ValidateCustomer(cus))
                {
                    cusAdded = CustomerOperations.AddCustomer(cus);
                }
                else
                {
                    throw new CustomerException("Please provide valid data for Customer");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusAdded;
        }

        public static bool UpdateCustomer(Customer cus)
        {
            bool cusUpdated = false;

            try
            {
                if (ValidateCustomer(cus))
                {
                    cusUpdated = CustomerOperations.UpdateCustomer(cus);
                }
                else
                {
                    throw new CustomerException("Please provide valid data to update Customer");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusUpdated;
        }

        public static bool DeleteCustomer(int CustomerID)
        {
            bool cusDeleted = false;

            try
            {
                cusDeleted = CustomerOperations.DeleteCustomer(CustomerID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusDeleted;
        }

        public static Customer SearchCustomer(int CustomerID)
        {
            Customer cus = null;

            try
            {
                cus = CustomerOperations.SearchCustomer(CustomerID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cus;
        }

        public static List<Customer> RetrieveCustomer()
        {
            List<Customer> cusList = CustomerOperations.RetrieveCustomer();

            return cusList;
        }

        public static bool SerializeCustomer()
        {
            bool cusSerialized = false;

            try
            {
                cusSerialized = CustomerOperations.SerializeCustomer();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusSerialized;
        }

        public static List<Customer> DeserializeCustomer()
        {
            List<Customer> cusDesList = null;

            try
            {
                cusDesList = CustomerOperations.DeserializeCustomer();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusDesList;
        }
    }
}

