﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Exception
{
    public class CustomerException : ApplicationException
    {
        //Default Constructor
        public CustomerException() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public CustomerException(string message) : base(message)
        { }
    }
}
