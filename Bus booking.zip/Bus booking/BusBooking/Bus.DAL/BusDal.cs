﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using BusBooking;
using BusBooking.Exception;
using System.Data;
using System.Configuration;


namespace Bus.DAL
{
    public class BusDal
    {
        SqlConnection conn =
            new SqlConnection(@"Data source=NDAMSSQL\sqlilearn;initial catalog=Training_20Feb_Mumbai;user id=sqluser;password=sqluser");

        SqlCommand cmd;

        public bool AddBusDetails(Busb bb)
        {
            bool TAdded = false;

            try
            {
              cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_insertbus";
                cmd.Parameters.AddWithValue("@BusNo", bb.BusNo);
                cmd.Parameters.AddWithValue("@Busname", bb.BusName);
                cmd.Parameters.AddWithValue("@Boarding date", bb.BoardingDate);
                cmd.Parameters.AddWithValue("@Destination", bb.DesinationDate);
                cmd.Parameters.AddWithValue("@price", bb.Price);
                cmd.Connection = conn;

                conn.Open();

                int result = cmd.ExecuteNonQuery();

                conn.Close();

                if (result > 0)
                    TAdded = true;
            }
            catch (Exception ex)
            {
                throw new BusBookingException(ex.Message);
            }

            return TAdded;
      
  }
        public List<Busb> GetAllBusDetails()
        {
            List<Busb> Buslist = null;

            try
            {
                cmd= new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_getbooks";
                cmd.Connection = conn;
                conn.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                Buslist = new List<Busb>();
                while (dr.Read())
                {
                    Busb bus = new Busb();
                    bus.BusNo = dr.GetInt32(0);
                    bus.BusName = dr.GetString(1);
                    bus.BoardingDate = dr.GetDateTime(2);
                    bus.DesinationDate = dr.GetDateTime(3);
                    bus.price = dr.GetInt32(4);

                    Buslist.Add(bus);
                }
            }
            catch (Exception ex)
            {
                throw new BusBookingException(ex.Message);
            }
            return Buslist;
        }
        public Busb GetBuskDAL(int BusNo)
        {
            Busb bus = null;

            try
            {
                 cmd=new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_getbookbyid";
                cmd.Parameters.AddWithValue("@BusNo", BusNo);
                cmd.Connection = conn;

                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    Busb bus1= new Busb();
                    //bus1.BusNo= dr.GetInt32(0);
                    bus1.BusName = dr.GetString(1);
                    bus1.BoardingDate = dr.GetDateTime(2);
                    bus1.DesinationDate = dr.GetDateTime(3);
                    bus1.price = dr.GetInt32(3);
                }
            }
            catch (Exception ex)
            {
                throw new BusBookingException(ex.Message);
            }
            return bus;
        }

        //public bool UpdateBuskDAL(Busb bb)
        //{
        //    bool busupdate = false;

        //    try
        //    {
        //         cmd=new SqlCommand();
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.CommandText = "udp_updatebook";
        //        cmd.Parameters.AddWithValue("@name", bb.BusName);
        //        cmd.Parameters.AddWithValue("@boarding", bb.BoardingDate);
        //        cmd.Parameters.AddWithValue("@Destination", bb.DesinationDate);
        //        cmd.Parameters.AddWithValue("@Price", bb.price);
        //        cmd.Connection = conn;

        //        conn.Open();

        //        int result = cmd.ExecuteNonQuery();

        //        conn.Close();

        //        if (result > 0)
        //            busupdate = true;
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //    return busupdate;
        //}

        public bool DeleteBusDAL(int id)
        {
            bool busdeatilsdelete = false;
            try
            {
                 cmd=new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_deletebook";
                cmd.Parameters.AddWithValue("@id", id);

                cmd.Connection = conn;

                conn.Open();

                int result = cmd.ExecuteNonQuery();

                conn.Close();

                if (result > 0)
                    busdeatilsdelete = true;
            }
            catch (Exception ex)
            {
                throw new BusBookingException(ex.Message);
            }
            return busdeatilsdelete;
        }
    }
}


