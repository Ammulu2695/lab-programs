﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusBooking;
using BusBooking.Exception;
using Bus.DAL;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace busBooking.BL
{
    public class Class1
    {
    }
}
