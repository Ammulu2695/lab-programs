﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABCBank;//Reference to Entity Class Library
using ABCBank.Exception; //Reference to Exception Class Library

using ABCBank.BL;//referance to BL


namespace ABCBank.PL
{
    /// <summary>
    /// Employee ID :174867
    /// Employee Name : Revati Chaudhari
    /// Date of Creation : 12-Mar-2019
    /// Description:Entity class for Account
    /// </summary>
    class Program
    {
        public static void AddAccount()
        {
            try
            {
                Account acc = new Account();
                Console.Write("Enter Account No : ");
                acc.AccountNo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Employee Name : ");
                acc.CustomerName = Console.ReadLine();
                Console.Write("Enter Account type : ");
               // acc.AccountType = (Account)Enum.Parse();
               // ABCBank.Account.BankAccountTypeEnum abc = Account.BankAccountTypeEnum.Saving;
                //ABCBank.Account.BankAccountTypeEnum abcd = Account.BankAccountTypeEnum.Current;
                string bankAccountTypeEnum = Console.ReadLine();

                switch (bankAccountTypeEnum)
                {
                    case "Current":
                        acc.AccountType =BankAccountTypeEnum.Current;
                        break;
                    case "Saving" :
                        acc.AccountType =BankAccountTypeEnum.Saving;
                        break;
                }


                bool accAdded = Customervalidation.AddAccount(acc);

                if (accAdded)
                {
                    Console.WriteLine("Account added successfully");
                }
                else
                {
                    throw new CustomerException("Account not added");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateAccount()
        {
            try
            {
                Account acc=new Account();
                Console.Write("Enter Account No : ");
                acc.AccountNo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Customer Name : ");
                acc.CustomerName = Console.ReadLine();
                Console.Write("Enter Account type : ");
                // acc.AccountType = (Account)Enum.Parse(typeof(Account));
                // ABCBank.Account.BankAccountTypeEnum abc = Account.BankAccountTypeEnum.Saving;
                // ABCBank.Account.BankAccountTypeEnum abcd = Account.BankAccountTypeEnum.Current;
                string bankAccountTypeEnum = Console.ReadLine();

                switch (bankAccountTypeEnum)
                {
                    case "Current":
                        acc.AccountType = BankAccountTypeEnum.Current;
                        break;
                    case "Saving":
                        acc.AccountType = BankAccountTypeEnum.Saving;
                        break;
                }
                bool accUpdated = Customervalidation.UpdateAccount(acc);

                if (accUpdated)
                {
                    Console.WriteLine("Account updated successfully");
                }
                else
                {
                    throw new CustomerException("Account not updated");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

        }


        public static void DeleteAccount()
        {
            try
            {
                int AccountNo;
                Console.Write("Enter  Account No to be Deleted : ");
                AccountNo = Convert.ToInt32(Console.ReadLine());

                bool empDeleted = Customervalidation.DeleteAccount(AccountNo);

                if (empDeleted)
                {
                    Console.WriteLine("Account deleted successfully");
                }
                else
                {
                    throw new CustomerException("Account not deleted");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void RetrieveAccount()
        {
            try
            {
                List<Account> accList = Customervalidation.RetrieveAccount();

                if (accList != null || accList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("Account No      Account Type     CustomerName");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var acc in accList)
                    {
                        Console.WriteLine($"{acc.AccountNo}\t\t{acc.AccountType}\t{acc.CustomerName}\t");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomerException("Employee data not available");
                }

            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeAccount()
        {
            try
            {
                bool empSerialized = Customervalidation.SerializeAccount();

                if (empSerialized)
                {
                    Console.WriteLine("Account data serialized");
                }
                else
                {
                    throw new CustomerException("Account data not serialized");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeAccount()
        {
            try
            {
                List<Account> accList = Customervalidation.DeserializeAccount();

                if (accList != null || accList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("Account No      Account Type     CustomerName");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var acc in accList)
                    {
                        Console.WriteLine($"{acc.AccountNo}\t\t{acc.AccountType}\t{acc.CustomerName}\t");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomerException("Account data not available after deserialization");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1. Add Account");
            Console.WriteLine("2. Update Account");
            Console.WriteLine("3. Delete Account");
            Console.WriteLine("4. Display Employee");
            Console.WriteLine("5. Serialize Account");
            Console.WriteLine("6. Deserialize Account");
            Console.WriteLine("7. Exit");
            Console.WriteLine("***********************");
        }

        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddAccount();
                        break;
                    case 2:
                        UpdateAccount();
                        break;
                    case 3:
                        DeleteAccount();
                        break;

                    case 4:
                        RetrieveAccount();
                        break;
                    case 5:
                        SerializeAccount();
                        break;
                    case 6:
                        DeserializeAccount();
                        break;
                    case 7:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valid choice");
                        break;
                }
            } while (choice != 8);

            Console.ReadKey();
        }
    }
}
    

