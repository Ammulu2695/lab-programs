﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCBank.Exception
{
    /// <summary>
    /// Employee ID :174867
    /// Employee Name : Revati Chaudhari
    /// Date of Creation : 12-Mar-2019
    /// Description:User defined exception class to handle exception of customer
    /// </summary>
    public class CustomerException:ApplicationException
    {
        //Default Constructor
        public CustomerException() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public CustomerException(string message) : base(message)
        { }
    }
}
