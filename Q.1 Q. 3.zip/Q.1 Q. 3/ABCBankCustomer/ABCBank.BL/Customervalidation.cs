﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABCBank;////Reference to Entity Class Library
using ABCBank.Exception; ////Reference to Exception Class Library
using ABCBank.DAL; //referance to dal
using System.Text.RegularExpressions;

namespace ABCBank.BL
{
    /// <summary>
    /// Employee ID :174867
    /// Employee Name : Revati Chaudhari
    /// Date of Creation : 12-Mar-2019
    /// Description: Business logic class for Account
    /// </summary>
    public class Customervalidation
    {
        //To validate accpuntno details
        public static bool ValidateAccount(Account acc)
        {
            bool accValidated = true;
            StringBuilder message = new StringBuilder();

            //try
            //{
            //    //Checking -current Account No 
            //    if (acc.AccountNo < 100000 || acc.AccountNo > 499999)
            //    {
            //        accValidated = false;
            //        message.Append("Account no range from 100000 to 499999\n");
            //    }
            //    //Checking -saving Account No 
            //    if (acc.AccountNo < 500000 || acc.AccountNo > 999999)
            //    {
            //        accValidated = false;
            //        message.Append("Account no range from 500000 to 999999\n");
            //    }
            //    //Checking - customer name
            //    if (acc.CustomerName == String.Empty)
            //    {
            //        accValidated = false;
            //        message.Append("Customer Name should have alphabets only\n");
            //    }
            //    else if (!Regex.IsMatch(acc.CustomerName, "[A-Z][a-z]{2,}"))
            //    {
            //        accValidated = false;
            //        message.Append("Customer Name should start with capital alphabet and it should have minimum 3 alphabets\n");
            //    }
            //}
            //catch (CustomerException ex)
            //{
            //    throw ex;
            //}
            //catch (SystemException ex)
            //{
            //    throw ex;
            //}

            return accValidated;
        }






        public static bool AddAccount(Account acc)
        {
            bool accAdded = false;

            try
            {
                if (ValidateAccount(acc))
                {
                    accAdded = Customeroperation.AddAccount(acc);
                }
                else
                {
                    throw new CustomerException("Please provide valid data for account");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return accAdded;
        }

        public static bool UpdateAccount(Account acc)
        {
            bool accUpdated = false;

            try
            {
                if (ValidateAccount(acc))
                {
                    accUpdated = Customeroperation.UpdateAccount(acc);
                }
                else
                {
                    throw new CustomerException("Please provide valid data to update account");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return accUpdated;
        }

        public static bool DeleteAccount(int accountNo)
        {
            throw new NotImplementedException();
        }

        public static bool DeleteEmployee(int AccountNo)
        {
            bool accDeleted = false;

            try
            {
                accDeleted = Customeroperation.DeleteAccount(AccountNo);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return accDeleted;
        }

        public static List<Account> RetrieveAccount()
        {
            List<Account> accList = Customeroperation.RetrieveAccount();

            return accList;
        }

        public static bool SerializeAccount()
        {
            bool accSerialized = false;

            try
            {
                accSerialized = Customeroperation.SerializeAccount();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return accSerialized;
        }

        public static List<Account> DeserializeAccount()
        {
            List<Account> accDesList = null;

            try
            {
                accDesList = Customeroperation.DeserializeAccount();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return accDesList;
        }

    }
}
    


                
    

