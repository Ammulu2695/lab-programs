﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OShoping;



namespace OnlineShoping
{
    //using delegate
   // public delegate void LmbDel();
    //public delegate void LamDelwithParam( int CustomerID ,String Cart);
    class Program 
    {
        static void Main(string[] args)
        {
            List<OS> s = new List<OS>(); //adding cart into list
            //for (int i = 0; i < 4; i++)
            //{


                s.Add(new OS { CustomerID = 1001, Cart = new List<string> { "Dress", "Mobile" } });


                s.Add(new OS { CustomerID = 1080, Cart = new List<string> { "shirts", "Laptop", "Watch", "Cap" } });
                s.Add(new OS { CustomerID = 1072, Cart = new List<string> { "Watch", "Sunglass", "Shoes" } });
                s.Add(new OS { CustomerID = 1045, Cart = new List<string> { "Tablet" } });
            OS obj;

            obj  = s.Find(shop =>shop.Cart.Contains("Laptop"));
            Console.Write("Customer ID contains laptop in Cart : ");
            Console.WriteLine(obj.CustomerID);
            Console.Write("Customer ID HAving Maximum Cart items : ");
            OS p = s.First(m => m.Cart.Count == (s.Max(e => e.Cart.Count)));
            Console.WriteLine(p.CustomerID);
            //obj = s.Max(shop => shop.Cart.Count);
            //Console.WriteLine(obj.CustomerID);
            //Console.WriteLine( s.Max(Count => s[i]));
        
            //}
            //int Max = Convert.ToInt32(s.Max());

            //var max = s.Max();
            //Console.WriteLine(max);
            //using lambda expression for printing 
            //LmbDel CustomerID = () => Console.WriteLine($"Cart having maximum Items:" );
            //LmbDel Cart = () => Console.WriteLine($"Cart having laptops:");

            Console.ReadKey();

        }
    }
}
