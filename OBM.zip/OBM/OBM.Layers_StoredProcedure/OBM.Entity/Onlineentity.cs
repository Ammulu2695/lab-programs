﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OBM.Entity
{
    public class Onlineentity
    {
      public double  Account_no  {get; set;}
        public string Customer_Name { get; set; }
        public double Deposit { get; set; }
        public double Withdraw { get; set; }
        public double Balance { get; set; } 
        public int Mobile { get; set; } 

    }
}
