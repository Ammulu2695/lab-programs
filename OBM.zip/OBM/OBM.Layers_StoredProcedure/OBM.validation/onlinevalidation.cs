﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OBM.Entity;
using OBM.Exception;
using OBM.DAL;

namespace OBM.validation
{
    public class Onlinevalidation
    {
        public static bool ValidateAcc(Onlineentity on)
        {
            bool result = true;
            StringBuilder sb = new StringBuilder();

            if (on.Account_no == double.NaN)
            {
                result = false;
                sb.Append("Account number cannot be blank");
            }
            else if (Convert.ToString(on.Account_no).Length< 16)
            {
                result = false;
                sb.Append("Account number must be 16 characters");
            }

            if (on.Customer_Name == string.Empty)
            {
                result = false;
                sb.Append("Customer Name Cannot be blank");
            }
            if (on.Mobile <= 600000000 && on.Mobile>=999999999)
            {
                result = false;
                sb.Append("Mobile no is not valid");
            }

            if (result == false)
            {
                throw new Onlineexception(sb.ToString());
            }
            return result;
        }

        public static bool AddAccBL(Onlineentity on)
        {
            bool accaddded = false;
            try
            {
                if (ValidateAcc(on))
                {
                    Onlineoperation obj = new Onlineoperation();
                    accaddded = obj.AddAccountNoDAL(on);
                }
            }
            catch (Onlineexception ex)
            {
                throw new Onlineexception(ex.Message);
            }

            return accaddded;
        }

        public static List<Onlineentity> GetAccDetailsBL()
        {
            List<Onlineentity> acclist = null;

            try
            {
                Onlineoperation ondal = new Onlineoperation();
                acclist = ondal.GetAccDetailssDAL();
            }
            catch (Onlineexception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return acclist;
        }

        //public static Onlineentity GetBookBL(int bookid)
        //{
        //    Book book = null;
        //    try
        //    {
        //        BMSDAL bmsdal = new BMSDAL();
        //        book = bmsdal.GetBookDAL(bookid);
        //    }
        //    catch (BookException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return book;
        //}

        public static bool UpdateAccBL(Onlineentity acc)
        {
            bool accupdate = false;
            try
            {
                if (ValidateAcc(acc))
                {
                    Onlineoperation ondal = new Onlineoperation();
                    accupdate = ondal.UpdateAccDAL(acc);
                }
            }
            catch (Onlineexception  ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return accupdate;
        }

        //public static bool DeleteBookBL(int id)
        //{
        //    bool bookdelete = false;

        //    try
        //    {
        //        if (id > 0)
        //        {
        //            BMSDAL bmsdal = new BMSDAL();
        //            bookdelete = bmsdal.DeleteBookDAL(id);
        //        }
        //        else
        //        {
        //            throw new BookException("Invalid Book ID");
        //        }
        //    }
        //    catch (BookException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return bookdelete;
        //}
    }
}
