﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OBM.Entity;
using OBM.Exception;
using System.Data.SqlClient;
using System.Data;
namespace OBM.DAL
{
    public class Onlineoperation
    {

        SqlConnection con = new SqlConnection(@"data source = NDAMSSQL\sqlilearn;initial catalog=Training_20Feb_Mumbai; user id=sqluser; password=sqluser");
        SqlCommand cmd;

        public bool AddAccountNoDAL(Onlineentity on)
        {
            bool accountnoadded = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType .StoredProcedure;
                cmd.CommandText = "addAccDetails_174797";
                cmd.Parameters.AddWithValue("@accno", on.Account_no);
                cmd.Parameters.AddWithValue("@customername", on.Customer_Name);
                cmd.Parameters.AddWithValue("@balance", on.Balance);
                cmd.Parameters.AddWithValue("@mobile", on.Mobile);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    accountnoadded = true;
            }
            catch (Onlineexception ex)
            {
                throw new Onlineexception(ex.Message);
            }

            return accountnoadded;
        }

        public List<Onlineentity> GetAccDetailssDAL()
        {
            List<Onlineentity> getacc = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "getAccDetails_174797";
                cmd.Connection = con;
                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                getacc = new List<Onlineentity>();
                while (dr.Read())
                {
                    Onlineentity acc = new Onlineentity();
                    acc.Account_no = dr.GetInt32(0);
                    acc.Customer_Name = dr.GetString(1);
                    acc.Balance = Convert.ToDouble(dr.GetString(2));
                    acc.Mobile = Convert.ToInt32(dr.GetString(3));
                    getacc.Add(acc);
                }
            }
            catch (Onlineexception ex)
            {
                throw new Onlineexception(ex.Message);
            }
            return getacc;
        }

        public bool UpdateAccDAL(Onlineentity on)
        {
            bool onupdate = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "updatedetails_174797";
                cmd.Parameters.AddWithValue("@accno", on.Account_no);
                cmd.Parameters.AddWithValue("@custname", on.Customer_Name);
                cmd.Parameters.AddWithValue("@mobile", on.Mobile);
                cmd.Connection = con;

                con.Open();

                int result = cmd.ExecuteNonQuery();

                con.Close();

                if (result > 0)
                    onupdate = true;
            }
            catch (Onlineexception)
            {
                throw;
            }
            return onupdate;
        }

        //public bool DeleteBookDAL(int id)
        //{
        //    bool bookdelete = false;
        //    try
        //    {
        //        cmd = new SqlCommand();
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.CommandText = "udp_deletebook";
        //        cmd.Parameters.AddWithValue("@id", id);

        //        cmd.Connection = conn;

        //        conn.Open();

        //        int result = cmd.ExecuteNonQuery();

        //        conn.Close();

        //        if (result > 0)
        //            bookdelete = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new BookException(ex.Message);
        //    }
        //    return bookdelete;
        }
    }

