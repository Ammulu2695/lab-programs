﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MovieException;
using ClassLibrary1;
using MovieDAL;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Text.RegularExpressions;
namespace MovieBL
{
    public class MovieValidations
    {
        public static bool ValidateMovie(Movie mv)
        {
            bool mvValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {

                if (mv.Movietitle == String.Empty)
                {
                    mvValidated = false;
                    message.Append("movie Name should be provided\n");

                }
                //Checking - employee id should be 6 digit
                if (mv.Acting < 0 || mv.Acting > 5)
                {
                    mvValidated = false;
                    message.Append("Rating should br 0 to 5\n");
                }

                //Checking - employee id should be 6 digit
                if (mv.Music < 0 || mv.Music > 5)
                {
                    mvValidated = false;
                    message.Append("Rating should br 0 to 5\n");
                }
                //Checking - employee id should be 6 digit
                if (mv.Duration < 0 || mv.Duration > 5)
                {
                    mvValidated = false;
                    message.Append("Rating should br 0 to 5\n");
                }


                if (mv.Publisher == String.Empty)
                {
                    mvValidated = false;
                    message.Append("publisher Name should be provided\n");

                }
                if (mv.Cinematogory < 0 || mv.Cinematogory > 5)
                {
                    mvValidated = false;
                    message.Append("Rating should br 0 to 5\n");
                }

    
                if (!mvValidated)
                {
                    throw new MoviesException1(message.ToString());
                }
            }
            catch (MoviesException1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return mvValidated;
        }

        public static bool AddMovie(Movie mv)
        {
            bool mvAdded = false;

            try
            {
                if (ValidateMovie(mv))
                {
                    mvAdded= Movie1.AddMovie(mv);
                }
                else
                {
                    throw new MoviesException1("Please provide valid data for employee");
                }
            }
            catch (MoviesException1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return mvAdded;
        }
        public static bool SerializeMovie()
        {
            bool mvSerialized = false;

            try
            {
                mvSerialized = Movie1.SerializeMovie();
            }
            catch (MoviesException1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return mvSerialized;
        }

        public static List<Movie> DeserializeMovie()
        {
            List<Movie> mvDesList = null;

            try
            {
                mvDesList = Movie1.DeserializeMovie();
            }
            catch (MoviesException1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return mvDesList;
        }
    }
}

 

