﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRS
{
    public class TRSEntity
    {
        public int TicketNo { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public DateTime DateofJourny { get; set; }
        public DateTime BookingDate { get; set; }
        public  string Type { get; set; }
        public  double Price { get; set; }
        public  double NoOfTickets { get; set; }

        
    }
}
