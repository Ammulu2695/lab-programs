﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSBL;
using EMSException;
using EMSGrossentity;
namespace EMSPL
{
    class Program
    {
        public static void AddEmployee()
        {
            try
            {
                EMSentity emp = new EMSentity();
                Console.Write("Enter Employee Id: ");
                emp.EmpId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Employee Name : ");
                emp.Empname = Console.ReadLine();
                Console.Write("Enter Salary : ");
                emp.Salary = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Pf Salary : ");
                emp.Pf= Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Hra : ");
                emp.Hra = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Hda : ");
                emp.Dra = Convert.ToInt32(Console.ReadLine());






                bool empAdded = EmployeeValidations.AddEmployee(emp);

                if (empAdded)
                {
                    Console.WriteLine($"{emp.EmpId} Net Salary is {emp.NetSalary}");
                    Console.WriteLine( emp.GrossSalary);
                    Console.WriteLine("Employee added successfully");
                }
                else
                {
                    throw new EMSException1("Employee not added");
                }
            }
            catch (EMSException1 ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1. Add Employee");
        }



        static void Main(string[] args)
        {

            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddEmployee();
                        break;
                        //break;
                    case 2:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valida choice");
                        break;
                }
            } while (choice != 2);

            Console.ReadKey();
        }
    }
}
