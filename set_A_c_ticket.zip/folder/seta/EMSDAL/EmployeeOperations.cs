﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSException;
using EMSGrossentity;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
namespace EMSDAL
{
    public class EmployeeOperations
    {
        static List<EMSentity> empList = new List<EMSentity>();

        //To insert the employee record in employee list
        public static bool AddEmployee(EMSentity emp)
        {
            bool empAdded = false;

            try
            {
                emp.Pf = (10 * emp.Salary) / 100;
                emp.Hra = (20 * emp.Salary) / 100;
                emp.NetSalary = (emp.Pf + emp.Dra) / 100;
                emp.GrossSalary = (emp.NetSalary + emp.Pf) / 100;
                //Adding employee object into employee list
                empList.Add(emp);
                empAdded = true;
            }
            catch (EMSException1 ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empAdded;
        }
       
    }
}
