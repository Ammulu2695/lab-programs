﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMSGrossentity
{
    public class EMSentity
    {
        public int EmpId { get; set; }
        public string Empname { get; set; }
        public int Salary { get; set; }
        public int Pf { get; set; }
        public int Hra { get; set; }
        public int Dra { get; set; }
        public int GrossSalary { get; set; }
        public int NetSalary { get; set; }
        
    }
}
