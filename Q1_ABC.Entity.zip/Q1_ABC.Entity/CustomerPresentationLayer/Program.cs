﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Q1_ABC.BL;
using Q1_ABC.Exception;
using Q1_ABC.Entity;



namespace Customer.PL
{
    class Program
    {
        public void Saving_Account(CustomerEntity customer)
        {
            //CustomerEntity customer = new CustomerEntity();
            Console.WriteLine("Enter Saving Account Number");

            customer.Saving_AccountNumber = Convert.ToInt32(Console.ReadLine());
          
        }

        public void Current_Account(CustomerEntity customer)
        {
            //CustomerEntity customer = new CustomerEntity();
            Console.WriteLine("Enter Current Account Number");

            customer.Current_AccountNumber = Convert.ToInt32(Console.ReadLine());
            
        }



        public static void AddCustomer()
        {
            try
            {
                Program p = new Program();
                CustomerEntity customer= new CustomerEntity();
                Console.WriteLine("Enter Customer Name : ");
                customer.Customer_Name = Console.ReadLine();
                Console.WriteLine("Enter Customer AccountType : ");
               Console.WriteLine("1.SavingAccount");
                Console.WriteLine("2.CurrentAccount");
              int n = int.Parse(Console.ReadLine());
                if(n==1)
                {
                    customer.Account_Type = "Savings";
                    p.Saving_Account(customer);
                    Console.WriteLine("Enter Account Balance");
                    customer.Account_Balance = Convert.ToDouble(Console.ReadLine());
                }
                else if(n==2)
                {
                    customer.Account_Type = "Current";
                    p.Current_Account(customer);
                    Console.WriteLine("Enter Account Balance");
                    customer.Account_Balance = Convert.ToDouble(Console.ReadLine());
                }
                
                bool empAdded = CustomerValidations.AddCustomer(customer);
               
                if (empAdded)
                {
                    Console.WriteLine("Customer added successfully");
                }
                else
                {
                    throw new CustomerException("Customer not added");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //public static void CheckBalance()
        //{
        //    try
        //    {
        //        string CustomerName;
        //        Console.Write("Enter Customer Name to be Checked : ");
        //        CustomerName = Console.ReadLine();

        //        CustomerEntity cus = CustomerValidations.CheckBalance(CustomerName);

        //        if (cus != null)
        //        {
        //            Console.WriteLine($"Customer Name : {cus.Customer_Name}");
                   
        //            Console.WriteLine($"Account Type : {cus.Account_Type}");
        //            Console.WriteLine($"Account Balance : {cus.Account_Balance}");
                    
        //        }
        //        else
        //        {
        //            throw new CustomerException("Customer not found");
        //        }
        //    }
        //    catch (CustomerException ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }


            public static void CheckBalance()
            {
                try
                {
                    int AccountNumber;
                    Console.Write("Enter Customer Account Numeber to be Checked : ");
                     AccountNumber= Convert.ToInt32(Console.ReadLine());
                CustomerEntity customer = new CustomerEntity();

                //Console.WriteLine("Enter Customer AccountType : ");
                //Console.WriteLine("1.SavingAccount");
                //Console.WriteLine("2.CurrentAccount");
                //int n = int.Parse(Console.ReadLine());
                //if (n == 1)
                    CustomerEntity cus = CustomerValidations.CheckBalance(AccountNumber);

                    if (cus != null)

                    {
                    if (AccountNumber == customer.Current_AccountNumber)
                    {
                        Console.WriteLine($"Customer Name : {cus.Customer_Name}");

                        Console.WriteLine($"Account Type : {cus.Account_Type}");
                        Console.WriteLine($"Current AccoutnNumber : {cus.Current_AccountNumber}");
                        Console.WriteLine($"Account Balance : {cus.Account_Balance}");
                    }
                    else if (AccountNumber == customer.Saving_AccountNumber)
                    {
                        Console.WriteLine($"Customer Name : {cus.Customer_Name}");

                        Console.WriteLine($"Account Type : {cus.Account_Type}");
                        Console.WriteLine($"Current AccoutnNumber : {cus.Saving_AccountNumber}");
                        Console.WriteLine($"Account Balance : {cus.Account_Balance}");
                    }
                }
                    else
                    {
                        throw new CustomerException("Customer not found");
                    }
                }
                catch (CustomerException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void RetrieveCustomer()
        {
            try
            {
                List<CustomerEntity> cusList = CustomerValidations.RetrieveCustomers();

                if (cusList != null || cusList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("Customer Name  AccountType   AccountBalance");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var cus in cusList)
                    {
                        Console.WriteLine($"{cus.Customer_Name}\t\t{cus.Account_Type}\t{cus.Account_Balance}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomerException("Customer data not available");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1. Add Customer");
            Console.WriteLine("2. Display Customer");
          
            Console.WriteLine("3. Check Balance");
            //Console.WriteLine("4. Search Customer");
           
            //Console.WriteLine("6. Serialize Customer");
            //Console.WriteLine("7. Deserialize Customer");
            Console.WriteLine("4. Exit");
            Console.WriteLine("***********************");
        }
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddCustomer();
                        break;
                    case 2:
                        RetrieveCustomer();
                        break;
                    case 3:
                        CheckBalance();
                        break;

                        //try
                        //{
                        //    List<CustomerEntity> custList = CustomerValidations.RetrieveCustomers();

                        //    if (custList != null || custList.Count > 0)
                        //    {
                        //        Console.WriteLine("------------------------------------------------------------------------------------");
                        //        Console.WriteLine("Customer Name   Customer AccountType  Customer AccoutBalance");
                        //        Console.WriteLine("------------------------------------------------------------------------------------");
                        //        foreach (var cust in custList)
                        //        {
                        //            Console.WriteLine($"{cust.Customer_Name}\t\t{cust.Account_Type}\t{cust.Account_Balance}");
                        //        }
                        //        Console.WriteLine("------------------------------------------------------------------------------------");
                        //    }
                        //    else
                        //    {
                        //        throw new CustomerException("Customer data not available");
                        //    }
                        //}
                        //catch (CustomerException ex)
                        //{
                        //    Console.WriteLine(ex.Message);
                        //}
                        //catch (SystemException ex)
                        //{
                        //    Console.WriteLine(ex.Message);
                        //}
                }
            } while (choice != 4);
        }
    }
}
