﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q1_ABC.Entity; //Reference to Customer Entity
using Q1_ABC.Exception;//Reference to Exception Class Library
using Q1_ABC.DAL; //Reference to DAL

namespace Q1_ABC.DAL
{
    /// <summary>
    /// Customer ID : 174790
    /// Customer Name :PERAKAM ANANTHANADH
    /// Date of Creation : 12-Mar-2019
    /// Description :  Database operations on Customer Class
    /// </summary>
    public class CustomerOperations
    {
        static List<CustomerEntity> cusList = new List<CustomerEntity>();

        //To insert the Customer record in Customer list
        public static bool AddCustomer(CustomerEntity cus)
        {
            bool cusAdded = false;

            try
            {
                //Adding Customer object into Customer list
                cusList.Add(cus);
                cusAdded = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cusAdded;
        }



        //To retrieve all Customers
        public static List<CustomerEntity> RetrieveCustomers()
        {
            return cusList;
        }

        //To search employee based on employee ID
        //public static CustomerEntity CheckBalance(String CustomerName)
        //{
        //    CustomerEntity cus= null;

        //    try
        //    {
        //        //Searching Employee
        //        cus = cusList.Find(e => e.Customer_Name == CustomerName);
        //    }
        //    catch (CustomerException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return cus;
        //}


        public static CustomerEntity CheckBalance(int AccountNumber)
        {
            CustomerEntity cus = null;

            try
            {
                if (AccountNumber==cus.Current_AccountNumber)
                {
                    //Searching Employee
                    cus = cusList.Find(e => e.Current_AccountNumber== AccountNumber);
                }
                else
                {
                    cus = cusList.Find(e => e.Saving_AccountNumber == AccountNumber);
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cus;
        }

    }
}
