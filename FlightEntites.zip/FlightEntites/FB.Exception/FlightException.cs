﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FB.Exception
{
    public class FlightException:ApplicationException
    {
        public FlightException() { }

        public FlightException(string msg) : base(msg) { }
    }
}
