﻿using System;
using System.Collections.Generic;
using System.Text;
using GuestPhoneBook.Entities;
using GuestPhoneBook.Exception;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
namespace GuestPhoneBook.DAL
{
    public class GuestOperation
    
    {
        static List<Guest> guestlist = new List<Guest>();

        //To insert the guest records in guest list
        public static bool AddGuest(Guest newGuest)
        {
            bool guestAdded = false;
            try
            {//Adding guest object into guest list
                guestlist.Add(newGuest);
                guestAdded = true;
            }
            catch (GuestPhoneBookException ex)
            {
                throw ex;

            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestAdded;
        }
        //To modity the guest data from the list
        public static bool UpdateGuest(Guest newGuest)
        {
            bool guestUpdated = false;
            try
            {
                for (int i = 0; i < guestlist.Count; i++)
                {//search guest to update
                    if (guestlist[i].GuestID== newGuest.GuestID)
                    {
                        //modifying guest details
                        guestlist[i].GuestID= newGuest.GuestID;
                        guestlist[i].GuestName= newGuest.GuestName;
                        guestlist[i].GuestConstactNumber= newGuest.GuestConstactNumber;
                        guestlist[i].Relation = newGuest.Relation;
                        guestUpdated = true;
                    }

                }
            }
            catch (GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestUpdated;
        }
        //
        public static bool DeleteGuest(int guestID)
        {
            bool guestDeleted = false;
            try
            {
                //search employee
                Guest newGuest = guestlist.Find(e => e.GuestID== guestID);
                if (newGuest!= null)
                {
                    //Deleting Guest from guest list
                    guestlist.Remove(newGuest);
                    guestDeleted = true;
                }
                else
                {
                    throw new GuestPhoneBookException("Guest with ID" + guestID + "does not exists for delete ");
                }
            }
            catch (GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestDeleted;

        }
        //To search guest  based on guest ID
        public static Guest SearchGuest(int guestID)
        {
            Guest newGuest = null;
            try
            {
                //search guest
                newGuest = guestlist.Find(e => e.GuestID== guestID);
            }
            catch (GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            return newGuest;
        }
        //To search guest  based on guest Relation
        public static Guest SearchRelation(Enum guestRelation)
        {
            Guest newGuest = null;
            try
            {
                //search guest
                newGuest = guestlist.Find(e => e.Relation == guestRelation);
            }
            catch (GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            return newGuest;
        }

        //to retrive all guest
        public static List<Guest> RetrieveGuest()
        {
            return guestlist;
        }
        //To serialize guest list
        //public static bool SerializeGuest()
        //{
        //    bool guestSerialized = false;

        //    try
        //    {
        //        FileStream fs = new FileStream("Guest.txt", FileMode.Create, FileAccess.Write);
        //        BinaryFormatter bin = new BinaryFormatter();
        //        bin.Serialize(fs, bin);
        //        fs.Close();
        //        guestSerialized = true;

        //    }
        //    catch (GuestPhoneBookException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return guestSerialized;

        //}
        //public static List<Guest> DeSearializeGuest()
        //{
        //    List<Guest> guestDesList = null;
        //    try
        //    {
        //        FileStream fs = new FileStream("Employee.txt", FileMode.Open, FileAccess.Read);
        //        BinaryFormatter bin = new BinaryFormatter();
        //        guestlist = (List<Guest>)bin.Deserialize(fs);
        //    }
        //    catch (GuestPhoneBookException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return guestDesList;
        }

    }




