Create table FlightBooking1_174780
(
TicketId int primary key,
CustomerName varchar(30),
price float,
)

go
create proc udp_getticketbyId(@TicketId int)
as
begin
select * from FlightBooking1_174780 where TicketId=@TicketId
end
go

go
create proc udp_insertTicketId(@Customername varchar(50),
@TicketId int ,@price float)
as
begin
insert into FlightBooking1_174780(CustomerName,price) 
values(@CustomerName,@price)
end 
go

go
create proc udp_CancelTicket(@CustomerName varchar(50)
,@price float,@TicketId int)
as
begin
delete from FlightBooking1_174780 where CustomerName=@CustomerName 
--price = @price where bookid=@id
end 
--delete from books where bookid=@id

insert into FlightBooking1_174780 values(1234,'Harshitha',56987.22)
insert into FlightBooking1_174780 values(1235,'vaddineni',56432.22)
select *from FlightBooking1_174780
