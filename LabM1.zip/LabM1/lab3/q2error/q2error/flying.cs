﻿namespace q2error
{
    internal class flying
    {
    }
}