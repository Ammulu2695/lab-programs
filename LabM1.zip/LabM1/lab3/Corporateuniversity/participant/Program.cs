﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace participant
{
    class Program
    {
               static void Main(string[] args)
        {
            participant p1 = new participant();

        }
    }
}
