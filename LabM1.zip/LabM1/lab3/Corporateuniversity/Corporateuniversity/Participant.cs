﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Corporateuniversity
{
    public class Participant
    {
        private int empId, foundationMark, webbasicMark, dotnetMark, totalMark = 300, obtainedMark;
        private string name;
      private static string companyName;
        private double percentage;
        static Participant()
        {
            companyName = " Corporate university ";
        }
        public Participant()
        {
            empId = 007;
            foundationMark = 99;
            webbasicMark = 99;
            dotnetMark = 88;
            name = "jone";
        }
        public Participant(int empId, int foundationMark, int webbasicMark, int dotnetMark,)
        {
            this.empId = empId;
            this.name = name;
            this.foundationMark = foundationMark;
            this.webbasicMark = webbasicMark;
            this.dotnetMark = dotnetMark;
        }
        public int EmpId
        {
            get { return empId; }
            set { empId = value; }
        }
        public int FoundationMarks
        {
            get { return foundationMark; }
            set {
                if (value >= 0 && value <= 100) { foundationMark = value; }
                else foundationMark = 0;
                

                }
            }
        public int WebBasicMarks
        {
            get { return webbasicMark; }
            set
            {
                if (value >= 0 && value <= 100)
                { webbasicMark = value; }
                else foundationMark = 0;


            }
        }
        public int DotNetMarks
        {
            get { return dotnetMark; }
            set
            {
                if (value >= 0 && value <= 100) {dotnetMark = value; }
                else dotnetMark = 0;


            }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string CompanyName
        {
            get { return companyName; }
            set { companyName = value; }
        }
        public int CalculateObtainedMarks()
        {
            return obtainedMark = (this.foundationMark + this.webbasicMark + this.dotnetMark);
        }
        public void CalculatePercentage()
        {
            percentage = ((double)obtainedMarks / totalMark) * 100;
        }
        public double DisplayPercentage()
        {
            Console.WriteLine($"percentage obtained by {this.name} is {this.percentage}");
            return percentage;
        }
        
        
    }
    }
}
