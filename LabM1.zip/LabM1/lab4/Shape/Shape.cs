﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shape
{
    public class Shape
    {
        public virtual void WhoamI()
        {
            Console.WriteLine(" Shape");
        }
    }
    public class Triangle : Shape
    {
        public override void WhoamI()
        {
            Console.WriteLine("Triangle");
        }
    }
    public class Circle : Shape
    {
        public override void WhoamI()
        {
            Console.WriteLine(" Circle");
        }
    }
}
