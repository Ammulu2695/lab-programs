﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2usingforloop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter size foe an array");
            int size = Convert.ToInt32(Console.ReadLine());
            string[] city = new string[size];

            Console.WriteLine($"enter {size}city name:");

            for (int i = 0; i < city.Length; i++)
            {

                city[i]=Console.ReadLine();

            }
            Console.WriteLine("City name are:");
            for (int i = 0; i < city.Length; i++)
            {
                Console.WriteLine(city[i]);
            }

            Console.ReadLine();

        }
    }
}
