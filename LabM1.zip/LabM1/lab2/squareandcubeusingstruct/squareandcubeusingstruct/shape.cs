﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace squareandcubeusingstruct
{

    struct numberStruct
    {
        int a;
        public numberStruct(int i)
        {
            a = i;
        }
        public void Square()
        {
            Console.WriteLine($"Square of given number is{a * a}");
        }
        public void Cube()
        {
            Console.WriteLine($"Cube of given number is{a * a * a}");
        }

    }
    class shape
    {

        static void Main(String[] args)
        {
            numberStruct ns = new numberStruct(5);
            ns.Square();
            ns.Cube();
        }
    }
}








