﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiDimArrayl2q5
{
    class BookDemo
    {
        static void Main(string[] args)
        {
            string[] colname = new string[4]
                {"book title \t","author \t","publish \t","prices \t"};
            string[,] bookdetails = new string[2, 4];
            for (int i = 0; i < bookdetails.GetLength(0); i++)
            {
                for (int j = 0; j < bookdetails.GetLength(1); j++)
                {
                    bookdetails[i, j] = Console.ReadLine();
                }
            }
            

                for (int i = 0; i < bookdetails.GetLength(0); i++)
                {
                    for (int j = 0; j < bookdetails.GetLength(1); j++)
                    {
                        Console.Write(colname[j] + "\t");
                        Console.Write(bookdetails[i, j] + "\t");
                    }
                    Console.WriteLine();
                }
            Console.ReadKey();
            } 


        }
    }

