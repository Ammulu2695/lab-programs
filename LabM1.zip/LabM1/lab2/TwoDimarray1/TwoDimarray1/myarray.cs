﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoDimarray1
{
    class myarray
    {
        static void Main(string[] args)
        {
            int[,] a = new int[5,6];
            int i, j;

            /* output each array element's value */
            for (i = 0; i <a.GetLength(0); i++)
            {
                Console.WriteLine($"enter {i} row values:");
                for (j = 0; j <a.GetLength(1); j++)
                {

                    a[i, j] = int.Parse(Console.ReadLine());

                }
            }
            /* output each array element's value */
            for (i = 0; i <a.GetLength(0); i++)
            {

                for (j = 0; j <a.GetLength(1); j++)
                {
                    Console.Write($"{a[i, j]}" + "\t");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
    }

