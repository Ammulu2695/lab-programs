﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using GMS.Entity;
using GMS.Exceptions;

namespace GMS.Dal
{
    /// <summary>
    /// Guest ID:174779_IN
    /// Guest Name:Anvesh
    /// Date of Event:8-Mar-2019
    /// /// Description:Database operations on Guest class
    /// </summary>
    public class GuestOperation
    {
        static List<Guest> gList = new List<Guest>();
        // to insert employee record in employee list
        public static bool AddGuest(Guest g)
        {
            bool gAdded = false;
            try
            {
                // Adding employee object into employee list
                gList.Add(g);
                gAdded = true;
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return gAdded;
        }
        // to retrieve all employee
        public static List<Guest> ListAllGuest()
        {
            return gList;
        }
        //  to search guest based on guest id
        public static Guest SearchGuest(int gID)
        {
            Guest newguest= null;
            try
            {
                //searching Employee
                newguest = gList.Find(g => g.GuestID == gID);
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return newguest;
        }
        //  to search guest based on guest relatuon
        //public static Guest SearchRealation(Enum guestRelation)
        //{
        //    Guest newguest = null;
        //    try
        //    {
        //        //searching Employee
        //        newguest = gList.Find(g => g.Relation == guestRelation);
        //    }
        //    catch (GuestException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return newguest;
        //}
        // to modify the employee data from the list
        public static bool UpdateGuest(Guest g)
        {
            bool gUpdated = false;
            try
            {
                for (int i = 0; i < gList.Count; i++)
                {
                    //searching employee to update
                    if (gList[i].GuestID == g.GuestID)
                    {
                        gList[i].GuestName = g.GuestName;
                        gList[i].ContactNumber = g.ContactNumber;
                        //gList[i].Relation = g.Relation;
                        
                    }
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return gUpdated;
        }
        // to delete employee from employee list
        public static bool DeleteGuest(int gID)
        {
            bool gDeleted = false;
            try
            {
                //searching employee
                Guest go = gList.Find(g => g.GuestID == gID);
                if (go != null)
                {
                    // deleting employee from employee list
                    gList.Remove(go);
                }
                else
                {
                    throw new GuestException("Guest with ID" + gID + "does no texist for delete opertion");
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;

            }
            return gDeleted;
        }
        // to search employee based on employee id
        //public static Employee SearchEmployee(int empID)
        //{
        //    Employee emp = null;
        //    try
        //    {
        //        //searching Employee
        //        emp = empList.Find(e => e.EmployeeID == empID);
        //    }
        //    catch (EmployeeException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return emp;
        //}
      
        
        // to serialize employee list
        //public static bool SerializeEmployee()
        //{
        //    bool empSerialized = false;
        //    try
        //    {
        //        FileStream fs = new FileStream("Employee.txt", FileMode.Create, FileAccess.Write);
        //        BinaryFormatter bin = new BinaryFormatter();
        //        bin.Serialize(fs, empList);
        //        //fs.Close();
        //    }
        //    catch (EmployeeException ex) { throw ex; }
        //    catch (SystemException ex) { throw ex; }
        //    return empSerialized;
        //}
        ////to deserialize employee list
        //public static List<Employee> DeserializeEmployee()
        //{
        //    List<Employee> empDesList = null;
        //    try
        //    {
        //        FileStream fs = new FileStream("Employee.txt", FileMode.Create, FileAccess.Read);
        //        BinaryFormatter bin = new BinaryFormatter();
        //        empDesList = (List<Employee>)bin.Deserialize(fs);
        //        fs.Close();

        //    }
        //    catch (EmployeeException ex) { throw ex; }
        //    catch (SystemException ex) { throw ex; }

        //    return DeserializeEmployee();

        }
}
