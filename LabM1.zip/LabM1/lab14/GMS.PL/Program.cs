﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GMS.Entity;
using GMS.BL;
using GMS.Exceptions;


namespace GMS.PL
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("enter your choice");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddGuest();
                        break;
                    case 2:
                        UpdateGuest();
                        break;
                  
                    case 3:
                        DeleteGuest();
                        break;                  
                    
                    default:

                        break;
                }
            } while (choice != 8);

        }
        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1.Add Guest");
            Console.WriteLine("2.update Guest");
            Console.WriteLine("3.Delete Guest");
            Console.WriteLine("4.exit");
        }
        public static void AddGuest()
            {
                try
                {
                    Guest g = new Guest();
                    Console.Write("Enter Guest ID:");
                    g.GuestID = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter Guest Name:");
                    g.GuestName = (Console.ReadLine());
                    Console.Write("Enter Guest Contactnumber.:");
                    g.ContactNumber = (Console.ReadLine());
                    //Console.Write("Enter Employee DOB:");
                    //emp.DOB = Convert.ToDateTime(Console.ReadLine());
                    //Console.Write("Enter Employee DOJ:");
                    //emp.DOJ = Convert.ToDateTime(Console.ReadLine());
                    //Console.Write("Enter Employee City:");
                    //emp.City = (Console.ReadLine());

                    bool gAdded = GuestValidation.AddGuest(g);
                    if (gAdded)
                    {
                        Console.WriteLine("Guest added Successfully");
                    }
                    else
                    {
                        throw new GuestException("Guest not added");
                    }
                }
                catch (GuestException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (SystemException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            public static void UpdateGuest()
            {
                try
                {
                    Guest g = new Guest();
                    Console.Write("Enter Guest ID:");
                    g.GuestID = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter Guest Name:");
                    g.GuestName = (Console.ReadLine());
                    Console.Write("Enter Guest Contactnumber.:");
                    g.ContactNumber = (Console.ReadLine());

                    bool gUpdate = GuestValidation.UpdateGuest(g);
                    if (gUpdate)
                    {
                        Console.WriteLine("Guest updated Successfully");
                    }
                    else
                    {
                        throw new GuestException("Guest not updated");
                    }
                }
                catch (GuestException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (SystemException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            public static void DeleteGuest()
            {
                try
                {
                    int empID;
                    Console.Write("Enter employee ID to be DELETED");
                    empID = Convert.ToInt32(Console.ReadLine());
                    bool empDeleted = GuestValidation.DeleteGuest(empID);
                    if (empDeleted)
                    {
                        Console.WriteLine("Guest deleted sucessfully");
                    }
                    else
                    {
                        throw new GuestException("Guest not deleted");
                    }
                }
                catch (GuestException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (SystemException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }

