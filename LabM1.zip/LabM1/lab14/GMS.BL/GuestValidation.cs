﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GMS.Entity;
using GMS.Exceptions;
using GMS.Dal;
using System.Text.RegularExpressions;

namespace GMS.BL
{
    /// <summary>
    /// Guest ID:174779_IN
    /// Guest Name:Anvesh
    /// Date of Event:8-Mar-2019
    /// Description:Business logic class for Guest
    /// 
    /// </summary>
    public class GuestValidation
    {
        List<Guest> gList = GuestOperation.ListAllGuest();
        // to validate employee details
        public static bool ValidateGuest(Guest g)
        {
            bool gValidated = true;
            StringBuilder message = new StringBuilder();
            try
            {
                if (g.GuestID < 100000 || g.GuestID > 999999)
                {
                    gValidated = false;
                    message.Append("Guest id should be exactly 6 digital");
                }
                // checking Guest name
                if (g.GuestName == string.Empty)
                {
                    gValidated = false;
                    message.Append("Guest name should be alpha");
                }
                if (!Regex.IsMatch(g.GuestName, "[A-Z][a-z]{2,}"))
                {
                    gValidated = false;
                    message.Append("Employee name Must starts with caps and it must have 3 char..");
                }
                //checking phone number
                if (g.ContactNumber == string.Empty)
                {
                    gValidated = false;
                    message.Append("phone number should 10 numbers:");
                }
                else if (!Regex.IsMatch(g.ContactNumber, "[6-9][0-9]{9}"))
                {
                    gValidated = false;
                    message.Append("phone number must have 10 digits and it must start with 6,7,8,9");

                }

                ////checking dob
                //int age = DateTime.Today.Year - emp.DOB.Year;
                //if (age < 18 || age > 60)
                //{
                //    empValidated = false;
                //    message.Append("as per the data of birth employee age is starting 18to60");
                //}
                ////checking doj
                //if (emp.DOJ > DateTime.Now)
                //{
                //    empValidated = false;
                //    message.Append("data of joining should be less than or equal to todays date");
                //}

                // Checking city
                //        if (emp.City == string.Empty)
                //        {
                //            empValidated = false;
                //            message.Append("city should be provided");

                //        }
                //        else if (emp.City.ToLower() != "pune" &&
                //            emp.City.ToLower() != "mumbai" &&
                //              emp.City.ToLower() != "hyderabad" &&
                //              emp.City.ToLower() != "bangalore")
                //        {
                //            empValidated = false;
                //            message.Append("city should be either p,c,h,b");
                //        }
                if (gValidated == false)
                {
                    throw new GuestException(message.ToString());
                }
            }
            catch (GuestException ex)
            { throw ex; }
            catch (SystemException ex)
            { throw ex; }
            return gValidated;
        }

        public static bool AddGuest(Guest g)
                {
                    bool gAdded = false;
                    try
                    {
                        if (ValidateGuest(g))
                        {
                            gAdded = GuestOperation.AddGuest(g);
                        }
                        else
                        {
                            throw new GuestException("please provide valid detail to guest:");
                        }

                    }
                    catch (GuestException ex) { throw ex; }
                    catch (SystemException ex) { throw ex; }
                    return gAdded;
                }
                public static bool UpdateGuest(Guest g)
                {
                    bool gUpdated = false;
                    try
                    {
                        if (ValidateGuest(g))
                        {
                            gUpdated = GuestOperation.UpdateGuest(g);
                        }
                        else
                        {
                            throw new GuestException("please provide valid details to employee");
                        }
                    }
                    catch (GuestException ex) { throw ex; }
                    catch (SystemException ex) { throw ex; }
                    return gUpdated;

                }
            

        public static bool DeleteGuest(int GuestID)
        {
            bool gDeleted = false;

            try
            {
                if (DeleteGuest(GuestID))
                {
                    gDeleted = GuestOperation.DeleteGuest(GuestID);
                }
                else
                {
                    throw new GuestException("please");
                }
            }
            catch (GuestException ex) { throw ex; }
            catch (SystemException ex) { throw ex; }

            return gDeleted;
        }
        //public static Employee SearchEmployee(int empID)
        //{
        //    Employee emp = null;
        //    try
        //    {
        //        emp = EmployeeOpertions.SearchEmployee(empID);
        //    }
        //    catch (EmployeeException ex) { throw ex; }
        //    catch (SystemException ex) { throw ex; }
        //    return emp;
        //}
        public static List<Guest> ListAllGuestEmployees()
        {
            //
            return gList;
        }
        //public static bool SerializeEmployee()
        //{
        //    bool empSerialized = false;
        //    try
        //    {
        //        empSerialized = EmployeeOpertions.SerializeEmployee();
        //    }
        //    catch (EmployeeException ex) { throw ex; }
        //    catch (SystemException ex) { throw ex; }
        //    return empSerialized;
        //}
        //public static List<Employee> DeserializeEmployee()
        //{
        //    List<Employee> empDesList = null;

        //    try
        //    {
        //        empDesList = EmployeeOpertions.DeserializeEmployee();
        //    }
        //    catch (EmployeeException ex) { throw ex; }
        //    catch (SystemException ex) { throw ex; }
        //    return empDesList;





        }

    }


