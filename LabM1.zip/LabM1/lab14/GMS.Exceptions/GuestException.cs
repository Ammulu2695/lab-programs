﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GMS.Exceptions
{
    /// <summary>
    /// Guest ID:174779_IN
    /// Guest Name:Anvesh
    /// Date of Event:8-Mar-2019
    /// Description: used defined class exception to handle Exception
    /// 
    /// </summary>
    public class GuestException : ApplicationException
    {
        //Default Constructor
        public GuestException() : base()
        { }
        // Parameterized Constructor to initalize mess propery
        public GuestException(string message) : base(message)
        { }
        // Parameterized Constructor to initalize mess propery and system exception
        public GuestException(string message,SystemException innerException) : base(message)
        { }

    }
}
