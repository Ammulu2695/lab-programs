﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GMS.Entity
{ /// <summary>
/// Guest ID:174779_IN
/// Guest Name:Anvesh
/// Date of Event:8-Mar-2019
/// Description: Entity class for Guest details
/// 
/// </summary>
    [Serializable]
    public class Guest
    {
        //Get or set guest Id
        public int GuestID { get; set; }
        // Get or set Guest name
        public string GuestName { get; set; }
        //Get or set ContactNumber.
        public string ContactNumber { get; set; }
        //Get or set relationship
        public enum Relation {

            Father=0,
            Mother=1,Brother=2,Sister=3,
            Cousin=4,
            uncle=5,Aunt=6,Son=7,Daughter=8,Friend=9,
                                           }
      Relation RelationShip { get; set; }

        public Guest()
        {
            GuestID = 0;
            GuestName = string.Empty;
            ContactNumber = string.Empty;
        }
        
    }
}
