﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using _13Contact;

namespace _13._11
{
    class Program
    {
        static List<Contact> contactlist = new List<Contact>();
        private static string lab;

        static void Main(string[] args)
        {
            Contact con = new Contact();
            AddContact();
            DisplayContact();
            BinaryFormatter bf = new BinaryFormatter();
            FileStream fs = new FileStream("Contact.txt", FileMode.Create, FileAccess.Write, FileShare.Write);

            bf.Serialize(fs, con);
            try
            {
                using (fs)
                {
                    bf.Serialize(fs, con);
                }
            }
            catch
            {
                lab = "An error has occured";
            }

            // Console.WriteLine("Object Serialization is done ");
            Console.ReadLine();
        }
        static void AddContact()
        {
            Contact con = new Contact();
            Console.WriteLine("enter contact id:");
            con.ContactNo = int.Parse(Console.ReadLine());
            Console.WriteLine("enter contact name: ");
            con.ContactName = Console.ReadLine();
            Console.WriteLine("enter cell no: ");
            con.CellNo = Console.ReadLine();
                       contactlist.Add(con);
        }
        static void DisplayContact()
        {
            List<Contact> cont = contactlist;
            Console.WriteLine("no   name   cell");
            foreach (Contact c in cont)
            {
                Console.WriteLine(c.ContactNo + " " + c.ContactName + " " + c.CellNo);
            }
        }
    }
    
}
