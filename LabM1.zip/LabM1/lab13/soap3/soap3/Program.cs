﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;

namespace soap3
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee(); //{ Id = 11, Name = "ass", Salary = 300 };
               Console.WriteLine("Enter your id");
                int Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"{Id}");
            Console.WriteLine("Enter your name");
            string Name = (Console.ReadLine());
            Console.WriteLine($"{Name}");
            Console.WriteLine("Enter your salary");
            int Salary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"{Salary}");

            FileStream fs = new FileStream("Employee.soup", FileMode.Create, FileAccess.Write);
            SoapFormatter sf = new SoapFormatter();
            sf.Serialize(fs, emp);
            fs.Close();
           
            fs = new FileStream("Employee.soup", FileMode.Open, FileAccess.Read);//Deserializatiom and reading
            Employee newemp = (Employee)sf.Deserialize(fs);
            //sf.Serialize(fs, emp);

            Console.WriteLine($"Employee Id:{newemp.Id}");
            Console.WriteLine($"Employee name:{newemp.Name}");
            Console.WriteLine($"Employee salary:{newemp.Salary}");
           fs.Close();
            Console.ReadKey();
        }
    }
}
