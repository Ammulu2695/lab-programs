﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soap3
{
    [Serializable]
    class Employee
    {

        int id;
        public int Id
        {

            get { return id; }
            set { id = value; }
        }

        string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        int sal;
        public int Salary
        {
            get { return sal; }
            set { sal = value; }
        }
    }
}
