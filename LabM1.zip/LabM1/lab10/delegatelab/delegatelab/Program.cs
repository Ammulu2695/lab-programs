﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegatelab
{
        //public delegate int MathDelegateDemo(int i, int j);
        public delegate void MathDelegateDemo(int i, int j);
    class Program
    {
        public static void Main(string[] args)
        {
            //MathDelegateDemo m = new MathDelegateDemo(Math.Max);
            Console.WriteLine("enter two number:");
            int i = Convert.ToInt32(Console.ReadLine());
            int j = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"{i}{j}");
            my_delegate cal = new my_delegate();
            my_delegate.Add(i, j);
            my_delegate.Sub(i, j);
            my_delegate.Mul(i, j);
            my_delegate.Divide(i, j);
            my_delegate.MaxNum(i, j);

            //  MathDelegateDemo del = new MathDelegateDemo(Calculate.Add);
            //MathDelegateDemo del = Calculate.Add;
            //del += Calculate.Sub;
            //del += new MathDelegateDemo(Calculate.Divide);
            //del += Calculate.Add;
            //del += Calculate.Mul;
            //int result = del(14, 2);
            //del();
            //Console.WriteLine("result is:" + result);
            // Console.WriteLine();
            // Console.WriteLine("Method reffered by delegates:");
            // Delegate[] List = del.GetInvocationList();
            //for (int a = 0; a < List.Length; a++)
            // {
            //     Console.WriteLine(List[a].Method);
            // }
            // Console.WriteLine();
            //del = Calculate.Add;

            //del(12, 3);
            //del = Calculate.Sub;
            //del(12, 33);



            Console.ReadKey();


        }
    }

            }
