﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegatelab
{
    class my_delegate
    {
        public static void Add(int i, int j)
        {
            Console.WriteLine($"{i}+{j} ={(i + j)}");
        }
        public static void Sub(int i, int j)
        {
            Console.WriteLine($"{i}-{j} =>{(i - j)}");
        }
        public static void Mul(int i, int j)
        {
            Console.WriteLine($"{i}*{j} =>{(i * j)}");
        }

        public static void Divide(int i, int j)
        {
            Console.WriteLine($"{i}/{j} =>{(i / j)}");
        }
        public static void MaxNum(int i, int j)
        {
            Console.WriteLine($"Max of {i} {j} =>{Math.Max(i , j)}");
        }
    }
}
