﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace FileInfoDemo
{
    class Program
    {

   
        static void Main(string[] args)
        {
            string path;
            Console.WriteLine("enter flie name");
            path = Console.ReadLine();
            //  FileInfo file = new FileInfo(@"C:\Users\panvesh\lab\lab1\Employee Detail\Employee Detail\Class1.cs");
            FileInfo file = new FileInfo(path);
            if (file.Exists)
            {
                Console.WriteLine($"file name:{file.Name}");
                Console.WriteLine($"file name:{file.CreationTime}");
                Console.WriteLine($"Dir:{file.Directory}");
                Console.WriteLine($"file Exte:{file.Extension}");
                Console.WriteLine($"Full name:{file.FullName}");
                Console.WriteLine($"is read:{file.IsReadOnly}");
                Console.WriteLine($"Last access:{file.LastAccessTime}");
                Console.WriteLine($"Full name:{file.LastWriteTime}");
                Console.WriteLine($"Full name:{file.Length}");
                Console.WriteLine($"Full name:{file.FullName}");
            }
            else
            {
                Console.WriteLine("file does not exist");
            }
            Console.ReadKey();
        }
    }
        
    }
  
