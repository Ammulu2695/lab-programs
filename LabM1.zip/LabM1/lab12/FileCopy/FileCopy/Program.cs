﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileCopy
{
    class Program
    {
        static void Main(string[] args)
        {
            string path;
            Console.WriteLine("Source file");
            path = Console.ReadLine();
            string pathd;
            Console.WriteLine("destination file");
            pathd = Console.ReadLine();
            File.Copy(path, pathd);
            Console.WriteLine(File.ReadAllText(path));
            Console.WriteLine(File.ReadAllText(pathd));
            Console.ReadKey();



        }
    }
}