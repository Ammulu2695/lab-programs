﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    class Program
    {
        static void Main(string[] args)
        {
Console.WriteLine("enter two nums");
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("1.Add\n2.sub\n3.mul\n4.div");
            int c = Convert.ToInt32(Console.ReadLine());
            if(c==1)
            {
                int addition = a + b;
                Console.WriteLine("adding of numbers {0}",addition);

            }
            else if(c==2)
                              {
                    int sub = a - b;
                    Console.WriteLine("sub of numbers {0}",sub);

                }
            else if (c == 3)
            {
                int mul = a * b;
                Console.WriteLine("mul of numbers {0}",mul);

            }
            else if (c == 4)
            {
                int Div = a / b;
                Console.WriteLine("div of numbers {0}",Div);

            }
            else
            {
                Console.WriteLine("wrong input");
               
            }

            Console.ReadLine();

        }
    }
}
