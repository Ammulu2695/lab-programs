﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetail
{
    public class Class1
    {


        public string Eid

        { get; set; }



        public string Ename

        { get; set; }
        public double Esal

        { get; set; }


        public string Eaddress
        { get; set; }

        public string Ecity

        { get; set; }
        public string Edept

        { get; set; }

    }
}
