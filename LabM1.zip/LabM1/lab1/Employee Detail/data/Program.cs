﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDetail;
namespace data
{
    class Program
    {
        static void Main(string[] args)
        {
            int Eid;
            String Ename;
            double Esal;
            string Eaddress;
            String Ecity, Edept;


           Program c = new Program();
            Console.WriteLine("Enter id");
            Eid = Convert.ToInt32(Console.ReadLine());
            for (int i= 0; i <10;i ++)
            {
                Console.WriteLine($"Enter your id:{i}");
            }

            Console.WriteLine("Enter name");
            Ename = Console.ReadLine();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Enter your names:{i}");
            }
            Console.WriteLine("Enter sal");
            Esal = Convert.ToDouble(Console.ReadLine());
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Enter your sal:{i}");
            }
            Eaddress = Console.ReadLine();
            Console.WriteLine("Enter address");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Enter your add:{i}");
            }
            Ecity = Console.ReadLine();
            Console.WriteLine("Enter city");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Enter your city:{i}");
            }
            Edept = Console.ReadLine();
            Console.WriteLine("Enter dept");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Enter your dept:{i}");
            }

            Console.WriteLine("enter employee details");
            Console.WriteLine($"employee id is :{ Eid}");
            Console.WriteLine($"employee nama is :{ Ename}");
            Console.WriteLine($"employee salary is :{ Esal}");
            Console.WriteLine($"employee salary is :{ Eaddress}");
            Console.WriteLine($"employee salary is :{ Ecity}");
            Console.WriteLine($"employee salary is :{ Edept}");
            Console.ReadLine();
        }
    }
}
