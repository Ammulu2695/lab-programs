﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @switch.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter no. b/w 1 to 5");
            int num = Convert.ToInt32(Console.ReadLine());
            switch(num)
            {
                case 1:
                    Console.WriteLine("enter 1");
                    break;
                case 2:
                    Console.WriteLine("enter 2");
                    break;
                case 3:
                    Console.WriteLine("enter 3");
                    break;
                case 4:
                    Console.WriteLine("enter 4");
                    break;
                case 5:
                    Console.WriteLine("enter 5");
                    break;
                default:
                    Console.WriteLine("wrong");
                    break;
            }
            Console.ReadKey();
        }
    }
}
