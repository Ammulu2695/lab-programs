﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tak1Q4
{
    class SchoolDemo
    {
        int rollnumber;
        string studentname;
        byte age;
        char gender;
        DateTime datet;
        string address;
        float percentage;
        public SchoolDemo(int roll, string name, byte ages, char gen, DateTime dof, string add, float per)
        {
            this.rollnumber = roll;
            this.studentname = name;
            this.age = ages;
            this.gender = gen;
            this.datet = dof;
            this.address = add;
            this.percentage = per;
        }
        static void Main(string[] args)
        {
            SchoolDemo sd = new SchoolDemo(101, "fhfg", 55, 'k', Convert.ToDateTime(" 02-10-1996"), "nfh", 8888888);
            //SchoolDemo sd = new SchoolDemo(101, "fhfg", 55, 'k', Convert.ToDateTime(" 02-10-1996"), "nfh", 8888888);
            Console.WriteLine($"Rollnumber is:{sd.rollnumber}");
            Console.WriteLine($"Studentname is:{sd.studentname}");
            Console.WriteLine($"age is:{sd.age}");
            Console.WriteLine($"gender is:{sd.gender}");
            Console.WriteLine($"Dateofbirth is:{sd.datet}");
            Console.WriteLine($"address is:{sd.address}");
            Console.WriteLine($"percentage is:{sd.percentage}");
            Console.ReadLine();

        }

    }
}





       
