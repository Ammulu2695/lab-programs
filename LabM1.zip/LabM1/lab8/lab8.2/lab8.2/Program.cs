﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace lab8._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable hashtable = GetHashtable();
            bool key = GetHashtable().ContainsKey("Perimeter");
            if (key)
            {
                Console.WriteLine("perimeter key is present");
            }
            else
            {
                Console.WriteLine("key not present");
            }
            Console.WriteLine("the value of Area key is:" + hashtable["Area"]);
            hashtable.Remove("Mortgage");
            Console.WriteLine("mortgage is removed");
            Console.WriteLine("the value of mortgage:" + hashtable["Mortgage"]);
            Console.ReadLine();
        }


        static Hashtable GetHashtable()
        {
            // Create and return new Hashtable.
            Hashtable hashtable = new Hashtable();
            hashtable.Add("Area", 1000);
            hashtable.Add("Perimeter", 55);
            hashtable.Add("Mortgage", 540);
            return hashtable;
        }
    }
    }

