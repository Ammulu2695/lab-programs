﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    /// <summary>   
    /// Employee ID:174851_IN
    /// Employee Name : Karnati Rajashekar
    /// Date of Creation : 12-Mar-2019
    /// Description : Entity Class for Bank
    /// </summary>

    // Delegate to Call UnderBalance Method
    public delegate void UnderBalanceDel(string msg);
    class Account
    {
        public event UnderBalanceDel UnderBalance; // UnderBalance Event Declaration
        //Get or Set AccountNumber
        public int AccountNumber { get; set; }
        //Get or Set CustomerName
        public string CustomerName { get; set; }
        //Get or Set Balance
        public double Balance { get; set; }


        //UnderBalance Event Method
        public void UnderBalanceMethod(string msg)
        {
            Console.WriteLine(msg);
        }

        //Withdraw Method to Withdraw
        public void Withdraw(double amount)
        {
            //bal to store Balance amount
            double bal = Balance -amount;
            if (bal < 1000)//Checking balance anount is less than 1000
            {
                if (UnderBalance != null)
                    UnderBalance("Balance is less than 1000");//Calling UnderBalance Event
            }
            else
            {
                Balance = bal;
                Console.WriteLine("Withdrawn Successful");
            }
        }
    }
}
