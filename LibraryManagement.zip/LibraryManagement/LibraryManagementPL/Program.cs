﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryManagement;
using LibraryManagementExcetion;
using LibraryManagementBL;

namespace LibraryManagementPL
{
    class Program
    {
        public static void AddBookDetails()
        {
            try
            {
                Book B = new Book();
                Console.Write("Enter Book ID : ");
                B.BookId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Book Name : ");
                B.BookName = Console.ReadLine();
                Console.Write(" choose your language ");
                B.Language = Console.ReadLine();
                Console.Write("Enter the book price : ");
                B.Price = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter ISBN_NO : ");
                B.ISBN_NO =Console.ReadLine();
                Console.Write("Enter NumberOfPages  : ");
                B.NumberOfPages = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the iot : ");
                B.Iot = Console.ReadLine();
                Console.Write("Enter Data of summary : ");
                B.summary = Console.ReadLine();


                bool BAdded = BookValidations.AddBookDetails(B);

                if (BAdded)
                {
                    Console.WriteLine("book details  added successfully");
                }
                else
                {
                    throw new LibraryException("bookDetails are  not added");
}
            }
            catch (LibraryException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static bool SerializeBook()
        {
            bool BSerialized = false;

            try
            {
                BSerialized = BookValidations.SerializeBook();
            }
            catch (LibraryException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return BSerialized;
        }

        public static void DeserializeBook()
        {
            try
            {
                List<Book> BList = BookValidations.DeserializeBook();

                if (BList != null || BList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("BookId    BookName    Language    Price   ISBN_NO  NumberOfPages Iot  summary ");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var B in BList)
                    {
                        Console.WriteLine($"{B.BookId}\t\t{B.BookName}\t{B.Language}\t{B.Price}\t{B.ISBN_NO}\t{B.NumberOfPages}\t{B.Iot}\t{B.summary}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new LibraryException("book details data not available after deserialization");
                }
            }
            catch (LibraryException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void printMenu()
        {
            Console.WriteLine("1. Add BOOK details");
            Console.WriteLine("2.serialize BOOK details");
            Console.WriteLine("3. deserialize BOOK details");
            Console.WriteLine("4. display all BOOK details");

        }
        //public static void DisplayBookDetails()
        //{
        //    Console.WriteLine("***********************");
        //    Console.WriteLine("1. Add BookId");
        //    Console.WriteLine("2. BookName");
        //    Console.WriteLine("3.language");
        //    Console.WriteLine("4. number of pages");
        //    Console.WriteLine("5. IOT");
        //    Console.WriteLine("6. IOT");
        //    Console.WriteLine("7. Serialize Book");
        //    Console.WriteLine("8. Deserialize Book");
        //    Console.WriteLine("9.Exit ");
        //    Console.WriteLine("***********************");
        //}
        //public static void DisplayLD(int LD)
        //{
        //    LD =;
        //}
            static void Main(string[] args)
        {
            int choice;

            do
            {
                printMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddBookDetails();
                        break;
                   
                    case 2:
                        SerializeBook();
                        break;
                    case 3:
                        DeserializeBook();
                        break;
                  
                    case 4:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valida choice");
                        break;
                }
            } while (choice != 4);

            Console.ReadKey();
        }
    }
}
