﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMS;
using BMS.Exception;
using BMS.DAL;
using System.Text.RegularExpressions;

namespace BMSValidations
{
    public class BookValidations
    {
        //To validate Book details
        public static bool ValidateBook(Book bms)
        {
            bool bmsValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - Book id should be 5 digit
                if (bms.BookID < 100000 || bms.BookID > 999999)
                {
                    bmsValidated = false;
                    message.Append("Book ID should be exactly 6 digits long\n");
                }

                //Checking - Book name
                if (bms.BookName == String.Empty)
                {
                    bmsValidated = false;
                    message.Append("Book Name should be provided\n");
                }
                else if (!Regex.IsMatch(bms.BookName, "[A-Z][a-z]{2,4}"))
                {
                    bmsValidated = false;
                    message.Append("Book Name should start with capital alphabet and it should have minimum 3 alphabets\n");
                }

                //Checking AuthorName
                if (bms.AuthorName == string.Empty)
                {
                    bmsValidated = false;
                    message.Append("AuthorName should be provided\n");
                }
                else if (!Regex.IsMatch(bms.AuthorName, "[A-Z][a-z]"))
                {
                    bmsValidated = false;
                    message.Append("AuthorName should start with  capital alphabet and it should have minimum 3 alphabets\n");
                }
                //Checking IsbmNumber
                if (bms.IsbmNumber == string.Empty)
                {
                    bmsValidated = false;
                    message.Append("IsbmNumber should be provided\n");
                }
                else if (!Regex.IsMatch(bms.IsbmNumber, "[0-9]{10}"))
                {
                    bmsValidated = false;
                    message.Append("IsbmNumber should have exactly 10 digits\n");
                }
                //{
                //    bmsValidated = false;
                //    message.Append("As per the IsbmNumber Book should be having 10 digits\n");
                //}

                //Checking Pages
                if (bms.Pages <= 25)
                {
                    bmsValidated = false;
                    message.Append("Pages should be more than or equal to 25 pages ");
                }

                //Checking IOT
                if (bms.IOT == string.Empty)
                {
                    bmsValidated = false;
                    message.Append("IOT should be provided");
                }
                else if (bms.IOT.ToLower() == "JAVA" ||
                        bms.IOT.ToLower() == "DotNet" ||
                        bms.IOT.ToLower() == "Sap" ||
                        bms.IOT.ToLower() == "Sql")
                {
                    bmsValidated = false;
                    message.Append("IOT should be either Java or DotNet or Sap or Sql\n");
                }

                //language
                if (bms.Language == string.Empty)
                {
                    bmsValidated = false;
                    message.Append("IOT should be provided");
                }
                else if (bms.IOT.ToLower() == "Java" ||
                        bms.IOT.ToLower() == "DotNet" ||
                        bms.IOT.ToLower() == "Sap" ||
                        bms.IOT.ToLower() == "Sql")
                {
                    bmsValidated = false;
                    message.Append("IOT should be either Java or DotNet or Sap or Sql\n");
                }

                if (bmsValidated == false)
                {
                    throw new BMSException(message.ToString());
                            }

            }

            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return bmsValidated;
        }
    
        public static bool AddBook(Book bms)
        {
            bool bmsAdded = false;

            try
            {
                if (ValidateBook(bms))
                {
                    bmsAdded = BookOperations.AddBook(bms);
                }
                else
                {
                    throw new BMSException("Please provide valid data for Book ");
                }
            }
            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bmsAdded;
        }

        public static bool UpdateBook(Book bms)
        {
            bool bmsUpdated = false;

            try
            {
                if (ValidateBook(bms))
                {
                    bmsUpdated = BookOperations.UpdateBook(bms);
                }
                else
                {
                    throw new BMSException("Please provide valid data to update Book");
                }
            }
            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bmsUpdated;
        }

        public static bool DeleteBook(int BookID)
        {
            bool bmsDeleted = false;

            try
            {
                bmsDeleted = BookOperations.DeleteBook(BookID);
            }
            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bmsDeleted;
        }

        public static Book SearchBook(int BookID)
        {
            Book bms = null;

            try
            {
                bms = BookOperations.SearchBook(BookID);
            }
            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bms;
        }

        public static List<Book> RetrieveBooks()
        {
            List<Book> bmsList = BookOperations.RetrieveBooks();

            return bmsList;
        }

        public static bool SerializeBook()
        {
            bool bmsSerialized = false;

            try
            {
                bmsSerialized = BookOperations.SerializeBook();
            }
            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bmsSerialized;
        }

        public static List<Book> DeserializeBook()
        {
            List<Book> bmsDesList = null;

            try
            {
                bmsDesList = BookOperations.DeserializeBook();
            }
            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bmsDesList;
        }
    }
}
