﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using BMS;
using BMS.Exception;

namespace BMS.DAL
{
    public class BookOperations
    {
        static List<Book> bmsList = new List<Book>();

        //To insert the Book record in Book list
        public static bool AddBook(Book bms)
        {
            bool bmsAdded = false;

            try
            {
                //Adding Book object into Book list
                bmsList.Add(bms);
                bmsAdded = true;
            }
            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bmsAdded;
        }

        //To modify the Book data from the list
        public static bool UpdateBook(Book bms)
        {
            bool bmsUpdated = false;

            try
            {
                for (int i = 0; i < bmsList.Count; i++)
                {
                    //Searching Book to update
                    if (bmsList[i].BookID == bms.BookID)
                    {
                        //Modifying Book details
                        bmsList[i].BookName = bms.BookName;
                        bmsList[i].AuthorName = bms.AuthorName;
                        bmsList[i].IsbmNumber = bms.IsbmNumber;
                        bmsList[i].Pages = bms.Pages;
                        bmsList[i].IOT = bms.IOT;
                        bmsList[i].Language = bms.Language;

                        bmsUpdated = true;
                    }
                }
            }
            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bmsUpdated;
        }

        //To delete Book from Book list
        public static bool DeleteBook(int BookID)
        {
            bool bmsDeleted = false;

            try
            {
                //Searching Book
                Book bms = bmsList.Find(e => e.BookID == BookID);

                if (bms != null)
                {
                    //Deleting Book from Book list
                    bmsList.Remove(bms);
                    bmsDeleted = true;
                }
                else
                {
                    throw new BMSException("Book with ID " + BookID + " does not exist for Delete");
                }
            }
            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bmsDeleted;
        }

        //To search Book based on Book ID
        public static Book SearchBook(int BookID)
        {
            Book bms = null;

            try
            {
                //Searching Book
                bms = bmsList.Find(e => e.BookID == BookID);
            }
            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bms;
        }

        //To retrieve all Book
        public static List<Book> RetrieveBooks()
        {
            return bmsList;
        }

        //To Serialize Book list
        public static bool SerializeBook()
        {
            bool bmsSerialized = false;

            try
            {
                FileStream fs = new FileStream("Book.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, bmsList);
                fs.Close();
                bmsSerialized = true;
            }
            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bmsSerialized;
        }

        //To deserialize Book List
        public static List<Book> DeserializeBook()
        {
            List<Book> bmsDesList = null;

            try
            {
                FileStream fs = new FileStream("Book.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                bmsDesList = (List<Book>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (BMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bmsDesList;
        }
    }
}
