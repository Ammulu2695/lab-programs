﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMS.Exception
{
    public class BMSException : ApplicationException
    {
        //Default Constructor
        public BMSException() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public BMSException (string message) : base(message)
        { }
    }
}
