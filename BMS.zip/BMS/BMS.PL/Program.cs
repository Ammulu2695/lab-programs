﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMS;
using BMS.Exception;
using BMSValidations;

namespace BMS.PL
{
    class Program
    {
        public static void AddBook()
        {
            try
            {
                Book bms = new Book();
                Console.Write("Enter Book ID : ");
                bms.BookID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter BookName : ");
                bms.BookName = Console.ReadLine();
                Console.Write("Enter AuthorName : ");
                bms.AuthorName = Console.ReadLine();
                Console.Write("Enter IsbmNumber : ");
                bms.IsbmNumber = Console.ReadLine();
                Console.Write("Enter Pages : ");
                bms.Pages = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter IOT : ");
                bms.IOT = Console.ReadLine();
                Console.Write("Enter Language : ");
                bms.Language = Console.ReadLine();

                bool bmsAdded = BookValidations.AddBook(bms);

                if (bmsAdded)
                {
                    Console.WriteLine("Book added successfully");
                }
                else
                {
                    throw new BMSException("Book not added");
                }
            }
            catch (BMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateBook()
        {
            try
            {
                Book bms = new Book();
                Console.Write(" Enter  Update Book ID : ");
                bms.BookID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Update BookName : ");
                bms.BookName = Console.ReadLine();
                Console.Write("Enter  Update AuthorName : ");
                bms.AuthorName = Console.ReadLine();
                Console.Write("Enter Update IsbmNumber : ");
                bms.IsbmNumber = Console.ReadLine();
                Console.Write("Enter Update Pages : ");
                bms.Pages = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter IOT : ");
                bms.IOT = Console.ReadLine();
                Console.Write("Enter Language : ");
                bms.Language = Console.ReadLine();


                bool bmsUpdated = BookValidations.UpdateBook(bms);

                if (bmsUpdated)
                {
                    Console.WriteLine(" Book updated successfully");
                }
                else
                {
                    throw new BMSException(" Book not updated");
                }
            }
            catch (BMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteBook()
        {
            try
            {
                int BookID;
                Console.Write("Enter Book ID to be Deleted : ");
                BookID = Convert.ToInt32(Console.ReadLine());

                bool bmsDeleted = BookValidations.DeleteBook(BookID);

                if (bmsDeleted)
                {
                    Console.WriteLine("Book deleted successfully");
                }
                else
                {
                    throw new BMSException("Book not deleted");
                }
            }
            catch (BMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchBook()
        {
            try
            {
                int BookID;
                Console.Write("Enter Book ID to be Searched : ");
                BookID = Convert.ToInt32(Console.ReadLine());

                Book bms = BookValidations.SearchBook(BookID);

                if (bms != null)
                {
                    Console.WriteLine($"Employee ID : {bms.BookID}");
                    Console.WriteLine($"BookName : {bms.BookName}");
                    Console.WriteLine($"AuthorName : {bms.AuthorName}");
                    Console.WriteLine($"IsbmNumber : {bms.IsbmNumber}");
                    Console.WriteLine($"Date of Joining : {bms.Pages}");
                    Console.WriteLine($"IOT : {bms.IOT}");
                    Console.WriteLine($"Language : {bms.Language}");
                }
                else
                {
                    throw new BMSException("Book not found");
                }
            }
            catch (BMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void RetrieveBooks()
        {
            try
            {
                List<Book> bmsList = BookValidations.RetrieveBooks();

                if (bmsList != null || bmsList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("BookID    BookName  AuthorName   IsbmNumber  Pages   IOT  Language");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var bms in bmsList)
                    {
                        Console.WriteLine($"{bms.BookID}\t\t{bms.BookName}\t{bms.AuthorName}\t{bms.IsbmNumber}\t{bms.Pages}\t{bms.IOT}\t{bms.Language}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new BMSException("Book data not available");
                }
            }
            catch (BMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeBook()
        {
            try
            {
                bool bmsSerialized = BookValidations.SerializeBook();

                if (bmsSerialized)
                {
                    Console.WriteLine(" Book data serialized");
                }
                else
                {
                    throw new BMSException(" Book data not serialized");
                }
            }
            catch (BMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeBook()
        {
            try
            {
                List<Book> bmsList = BookValidations.DeserializeBook();

                if (bmsList != null || bmsList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("BookID    BookName  AuthorName   IsbmNumber  Pages   IOT  Language");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var bms in bmsList)
                    {
                        Console.WriteLine($"{bms.BookID}\t\t{bms.BookName}\t{bms.AuthorName}\t{bms.IsbmNumber}\t{bms.Pages}\t{bms.IOT}\t{bms.Language}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new BMSException("Book data not available after deserialization");
                }
            }
            catch (BMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1. Add Book");
            Console.WriteLine("2. Update Book");
            Console.WriteLine("3. Delete Book");
            Console.WriteLine("4. Search Book");
            Console.WriteLine("5. Display Book");
            Console.WriteLine("6. Serialize Book");
            Console.WriteLine("7. Deserialize Book");
            Console.WriteLine("8. Exit");
            Console.WriteLine("***********************");
        }

        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddBook();
                        break;
                    case 2:
                        UpdateBook();
                        break;
                    case 3:
                        DeleteBook();
                        break;
                    case 4:
                        SearchBook
                            ();
                            
                        break;
                    case 5:
                        RetrieveBooks();
                        break;
                    case 6:
                        SerializeBook();
                        break;
                    case 7:
                        DeserializeBook();
                        break;
                    case 8:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valida choice");
                        break;
                }
            } while (choice != 8);

            Console.ReadKey();
        }
    }
}
