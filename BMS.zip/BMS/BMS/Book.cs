﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMS
{
    public class Book
    {
        //Get or set BookID
        public int BookID { get; set; }

        //Get or set BookName
        public string BookName { get; set; }

        //Get or set AuthorName
        public string AuthorName { get; set; }

        //Get or set IsbmNumber
        public string IsbmNumber { get; set; }

        //Get or set No.of Pages
        public double Pages { get; set; }

        //Get or set IOT
        public string IOT { get; set; }

        //Get or set Language
        public string Language { get; set; }



    }
}
