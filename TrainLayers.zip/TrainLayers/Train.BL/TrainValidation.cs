﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Train.DAL;
using Train.Entity;
using Train.Exception;
using System.Text.RegularExpressions;

namespace Train.BL
{
    public class TrainValidation
    {
        //To validate trloyee details
        public static bool ValidateTrain(TrainEntity tr)
        {
            bool trValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - trloyee id should be 6 digit
                if (tr.PNRNumber ==string.Empty)
                {
                    trValidated = false;
                    message.Append("PNR number cannot be null\n");
                }
                else if (!Regex.IsMatch(tr.PNRNumber, "[8][0-9]{6}"))
                {
                    trValidated = false;
                    message.Append("PNRnumber should start with 8 and it should have exactly 7 digits\n");
                }

                //Checking - trloyee name


                if (tr.BookingDate != DateTime.Today)
                {
                    trValidated = false;
                    message.Append("Bookings are accepted only for today");
                }

                //Checking Date of Joining
                if (tr.JourneyDate <=DateTime.Today)
                {
                    trValidated = false;
                    message.Append("Date of Joining should be Greater than or equal to today's date");
                }

                //Checking City
                if (tr.Type == string.Empty)
                {
                    trValidated = false;
                    message.Append("TYPE should be provided");
                }
                else if (tr.Type.ToLower() != "sleeper" &&
                        tr.Type.ToLower() != "3ac" &&
                        tr.Type.ToLower() != "2ac" &&
                        tr.Type.ToLower() != "1ac")
                {
                    trValidated = false;
                    message.Append("TYpe should be either either SLEEPER 3ac 2ac or 1ac\n");
                }

                if (trValidated == false)
                {
                    throw new TrainException(message.ToString());
                }
            }
            catch (TrainException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trValidated;
        }

        public static bool AddTrainBL(TrainEntity tr)
        {
            bool trAdded = false;

            try
            {
                if (ValidateTrain(tr))
                {
                    trAdded = TrainOperations.AddTrain(tr);
                }
                else
                {
                    throw new TrainException("Please provide valid data for Train Details");
                }
            }
            catch (TrainException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trAdded;
        }

        public static bool UpdatetTrainBL(TrainEntity tr)
        {
            bool trUpdated = false;

            try
            {
                if (ValidateTrain(tr))
                {
                    trUpdated = TrainOperations.UpdateTrainEntity(tr);
                }
                else
                {
                    throw new TrainException("Please provide valid data to update train details");
                }
            }
            catch (TrainException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trUpdated;
        }

        public static bool DeletetTRainBL(string trID)
        {
            bool trDeleted = false;

            try
            {
                trDeleted = TrainOperations.DeleteTrainEntity(trID);
            }
            catch (TrainException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trDeleted;
        }

        public static TrainEntity SearchtTrainBL(string trID)
        {
            TrainEntity tr = null;

            try
            {
                tr = TrainOperations.SearchTrainEntity(trID);
            }
            catch (TrainException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return tr;
        }

        public static List<TrainEntity> RetrievetTrainBL()
        {
            List<TrainEntity> trList = TrainOperations.RetrieveTrain();

            return trList;
        }

        public static bool SerializeTrainBL()
        {
            bool trSerialized = false;

            try
            {
                trSerialized = TrainOperations.SerializeTrain();
            }
            catch (TrainException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trSerialized;
        }

        public static List<TrainEntity> DeserializeTrainBL()
        {
            List<TrainEntity> trDesList = null;

            try
            {
                trDesList = TrainOperations.DeserializeTrain();
            }
            catch (TrainException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return trDesList;
        }
    }
}
