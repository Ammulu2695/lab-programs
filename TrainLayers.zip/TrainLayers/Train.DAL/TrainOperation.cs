﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Train.Entity;
using Train.Exception;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Train.DAL
{

        public class TrainOperations
        {
            static List<TrainEntity> trList = new List<TrainEntity>();

            //To insert the TrainEntity record in TrainEntity list
            public static bool AddTrain(TrainEntity tr)
            {
            

                   
                bool trAdded = false;

                try
                {
                    //Adding TrainEntity object into TrainEntity list
                    trList.Add(tr);
                    trAdded = true;
                }
                catch (TrainException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return trAdded;
            }

            //To modify the TrainEntity data from the list
            public static bool UpdateTrainEntity(TrainEntity tr)
            {
                bool trUpdated = false;

                try
                {
                    for (int i = 0; i < trList.Count; i++)
                    {
                        //Searching TrainEntity to update
                        if (trList[i].PNRNumber == tr.PNRNumber)
                        {
                            //Modifying Train details
                            trList[i].Type = tr.Type;
                            trList[i].BookingDate = tr.BookingDate;
                           
                            trList[i].JourneyDate = tr.JourneyDate;
                            

                            trUpdated = true;
                        }
                    }
                }
                catch (TrainException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return trUpdated;
            }

            //To delete TrainEntity from TrainEntity list
            public static bool DeleteTrainEntity(string trID)
            {
                bool trDeleted = false;

                try
                {
                    //Searching TrainEntity
                    TrainEntity tr = trList.Find(e => e.PNRNumber == trID);

                    if (tr != null)
                    {
                        //Deleting TrainEntity from TrainEntity list
                        trList.Remove(tr);
                        trDeleted = true;
                    }
                    else
                    {
                        throw new TrainException("Train with ID " + trID + " does not exist for Delete");
                    }
                }
                catch (TrainException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return trDeleted;
            }

            //To search TrainEntity based on TrainEntity ID
            public static TrainEntity SearchTrainEntity(string trID)
            {
                TrainEntity tr = null;

                try
                {
                    //Searching TrainEntity
                    tr = trList.Find(e => e.PNRNumber == trID);
                }
                catch (TrainException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return tr;
            }

            //To retrieve all TrainEntitys
            public static List<TrainEntity> RetrieveTrain()
            {
                return trList;
            }

            //To Serialize TrainEntity list
            public static bool SerializeTrain()
            {
                bool trSerialized = false;

                try
                {
                    FileStream fs = new FileStream("TrainEntity.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(fs, trList);
                    fs.Close();
                    trSerialized = true;
                }
                catch (TrainException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return trSerialized;
            }

            //To deserialize TrainEntity List
            public static List<TrainEntity> DeserializeTrain()
            {
                List<TrainEntity> trDesList = null;

                try
                {
                    FileStream fs = new FileStream("TrainEntity.txt", FileMode.Open, FileAccess.Read);
                    BinaryFormatter bin = new BinaryFormatter();
                    trDesList = (List<TrainEntity>)bin.Deserialize(fs);
                    fs.Close();
                }
                catch (TrainException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return trDesList;
            }
        }
    }

