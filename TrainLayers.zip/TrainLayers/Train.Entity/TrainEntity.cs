﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Train.Entity
{[Serializable]
    public class TrainEntity
    {

        public string PNRNumber { get; set; }
        public string Type { get; set; }
        public DateTime BookingDate{ get; set; }
        public DateTime JourneyDate{ get; set; }
        public double Price { get; set; }
    }
}
