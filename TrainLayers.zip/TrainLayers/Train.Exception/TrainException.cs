﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Train.Exception
{
    public class TrainException:ApplicationException
    {
        //Default Constructor
        public TrainException() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public TrainException(string message) : base(message)
        { }
    }
}
