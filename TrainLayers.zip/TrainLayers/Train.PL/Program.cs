﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Train.BL;
using Train.Entity;
using Train.Exception;

namespace Train.PL
{
    class Program
    {
        public static void AddTrainPL()
        {
            try
            {
                TrainEntity tr = new TrainEntity();
                Console.Write("Enter PNRNumber : ");
                tr.PNRNumber = Console.ReadLine();
                Console.Write("Enter Type : ");
                tr.Type = Console.ReadLine();
                Console.Write("Enter Booking Date : ");
                tr.BookingDate =Convert.ToDateTime( Console.ReadLine());
                Console.Write("Enter date of journey : ");
                tr.JourneyDate = Convert.ToDateTime(Console.ReadLine());

                switch (tr.Type.ToLower())
                {
                    case "sleeper":
                    default:
                        tr.Price = 500;
                        break;
                    case "3ac":
                        tr.Price = 950;
                        break;
                    case "2ac":
                        tr.Price = 1175;
                        break;
                    case "1ac":
                        tr.Price = 1500;
                        break;
                }
                bool trAdded = TrainValidation.AddTrainBL(tr);

                if (trAdded)
                {
                    Console.WriteLine($"Traindetails added successfully with ticket cost {tr.Price}");
                }
                else
                {
                    throw new TrainException("TrainDetails not added");
                }
            }
            catch (TrainException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateTrainPL()
        {
            try
            {
                TrainEntity tr = new TrainEntity();
                Console.Write("Enter PNRNumber : ");
                tr.PNRNumber = Console.ReadLine();
                Console.Write("Enter Type : ");
                tr.Type = Console.ReadLine();
                Console.Write("Enter Booking Date : ");
                tr.BookingDate = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter date of journey : ");
                tr.JourneyDate = Convert.ToDateTime(Console.ReadLine());

                bool trUpdated = TrainValidation.UpdatetTrainBL(tr);

                if (trUpdated)
                {
                    Console.WriteLine("TrainDetails updated successfully");
                }
                else
                {
                    throw new TrainException("trloyee not updated");
                }
            }
            catch (TrainException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeletetTrainPL()
        {
            try
            {
                string trID;
                Console.Write("Enter PNRNUMBER to be Deleted : ");
                trID = Console.ReadLine();

                bool trDeleted = TrainValidation.DeletetTRainBL(trID);

                if (trDeleted)
                {
                    Console.WriteLine("train deleted successfully");
                }
                else
                {
                    throw new TrainException("train not deleted");
                }
            }
            catch (TrainException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchTrainPL()
        {
            try
            {
                string trID;
                Console.Write("Enter PNRNumber to be Searched : ");
                trID =Console.ReadLine();

                TrainEntity tr = TrainValidation.SearchtTrainBL(trID);

                if (tr != null)
                {
                    Console.WriteLine($"trloyee ID : {tr.PNRNumber}");
                    Console.WriteLine($"Type : {tr.Type}");
                    Console.WriteLine($"Booking date : {tr. BookingDate}");
                    Console.WriteLine($"Date of journey : {tr.JourneyDate}");
                  
                }
                else
                {
                    throw new TrainException("train not found");
                }
            }
            catch (TrainException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void RetrieveTrainPL()
        {
            try
            {
                List<TrainEntity> trList = TrainValidation.RetrievetTrainBL();

                if (trList != null || trList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("PNRNumber    Type  DateofBOOKING   dateofJourney  price");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var tr in trList)
                    {
                        Console.WriteLine($"{tr.PNRNumber}\t\t{tr.Type}\t{tr.BookingDate}\t{tr.JourneyDate}\t\t{tr.Price}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new TrainException("Train data not available");
                }
            }
            catch (TrainException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeTrainPL()
        {
            try
            {
                bool trSerialized = TrainValidation.SerializeTrainBL();

                if (trSerialized)
                {
                    Console.WriteLine("Train Details data serialized");
                }
                else
                {
                    throw new TrainException("Train data not serialized");
                }
            }
            catch (TrainException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeTrainPL()
        {
            try
            {
                List<TrainEntity> trList = TrainValidation.DeserializeTrainBL();

                if (trList != null || trList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("PNRNumber    Type  DateofBOOKING   dateofJourney  ");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (var tr in trList)
                    {
                        Console.WriteLine($"{tr.PNRNumber}\t\t{tr.Type}\t{tr.BookingDate}\t{tr.JourneyDate}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new TrainException("train data not available after deserialization");
                }
            }
            catch (TrainException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1. Add JourneyDetails");
            Console.WriteLine("2. Update JourneyDetails");
            Console.WriteLine("3. Delete JourneyDetails");
            Console.WriteLine("4. Search JourneyDetails");
            Console.WriteLine("5. Display JourneyDetails");
            Console.WriteLine("6. Serialize JourneyDetails");
            Console.WriteLine("7. Deserialize JourneyDetails");
            Console.WriteLine("8. Exit");
            Console.WriteLine("***********************");
        }

        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddTrainPL();
                        break;
                    case 2:
                        UpdateTrainPL();
                        break;
                    case 3:
                        DeletetTrainPL();
                        break;
                    case 4:
                        SerializeTrainPL();
                        break;
                    case 5:
                        RetrieveTrainPL();
                        break;
                    case 6:
                        SerializeTrainPL();
                        break;
                    case 7:
                        DeserializeTrainPL();
                        break;
                    case 8:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valida choice");
                        break;
                }
            } while (choice != 8);

            Console.ReadKey();
        }
        
    }
}
