create table OnlineBanking_174797
(
	accno bigint,
	customername varchar(50),
	balance money check(balance>1000),
	mobile bigint
)

drop table OnlineBanking_174797
drop proc addAccDetails_174797

create proc addAccDetails_174797
@accno bigint,
@customername varchar(50),
@balance money,
@mobile bigint
as
begin
insert into  OnlineBanking_174797 values(@accno, @customername, @balance, @mobile)
end


create proc updatedetails_174797
@accno bigint,
@customername varchar(50),
@mobile bigint
as
begin
	update OnlineBanking_174797 set customername=@customername, mobile=@mobile where accno=@accno
end


create proc getAccDetails_174797
@accno bigint
as
begin
	select * from OnlineBanking_174797 where accno=@accno
end

