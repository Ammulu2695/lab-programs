﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInheritanceDemo1
{
    class Manager : Employee
    {
        public Manager() : base()
        {
            Console.WriteLine("Manager Default Constructor");
        }

        public Manager(int id, string name, double ince) : base(id, name)
        {
            Console.WriteLine("Manager Parameterized Constructor");
        }
    }
}
