﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssymmetricAccessorPropDemo
{
    class Employee
    {
        int id;
        public int EmpID
        {
            private get { return id; }
            set { id = value; }
        }

        string name;
        public string EmpName
        {
            get { return name; }
            set { name = value; }
        }

        double sal;
        public double Salary
        {
            get { return sal; }
            private set { sal = value; }
        }
    }
}
