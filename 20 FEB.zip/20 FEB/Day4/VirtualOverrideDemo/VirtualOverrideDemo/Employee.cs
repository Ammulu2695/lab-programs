﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualOverrideDemo
{
    class Employee
    {
        public double Salary { get; private set; }

        public Employee(double sal)
        {
            Salary = sal;
        }

        public virtual double CalculateSalary(int bonus)
        {
            return Salary + bonus;
        }
    }
}
