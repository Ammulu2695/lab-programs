﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualOverrideDemo
{
    class SalesPerson : Employee
    {
        int salesCount;

        public SalesPerson(double sal, int count) : base(sal)
        {
            salesCount = count;
        }

        public override double CalculateSalary(int amount)
        {
            int salesBonus = 0;
            if (salesCount > 0 && salesCount <= 100)
                salesBonus = 10;
            else if (salesCount >= 101 && salesCount <= 300)
                salesBonus = 15;
            else
                salesBonus = 20;

            return base.CalculateSalary(amount * salesBonus);
        }
    }
}
