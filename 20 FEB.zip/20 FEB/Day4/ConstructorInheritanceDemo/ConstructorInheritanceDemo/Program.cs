﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInheritanceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            Console.WriteLine();
            Employee emp1 = new Employee(101, "Robert");
            Console.WriteLine();

            Manager mgr = new Manager();
            Console.WriteLine();
            Manager mgr1 = new Manager(101, "Robert", 5665);

            Console.ReadKey();
        }
    }
}
