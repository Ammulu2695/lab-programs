﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInheritanceDemo2
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager mgr = new Manager(101, "Robert", 34767, 8986);

            Console.WriteLine($"Employee ID : {mgr.ID}");
            Console.WriteLine($"Employee Name : {mgr.Name}");
            Console.WriteLine($"Employee Salary : {mgr.Salary}");
            Console.WriteLine($"Employee Incentives : {mgr.Incentives}");

            Console.ReadKey();
        }
    }
}
