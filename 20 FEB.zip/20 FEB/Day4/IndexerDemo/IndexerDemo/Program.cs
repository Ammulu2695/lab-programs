﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculate cal = new Calculate(10);

            cal[0] = 23;
            cal[3] = 67;
            cal[7] = 89;
            cal[9] = 34;

            Console.WriteLine("Array elements : ");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(cal[i]);
            }

            Console.ReadKey();
        }
    }
}
