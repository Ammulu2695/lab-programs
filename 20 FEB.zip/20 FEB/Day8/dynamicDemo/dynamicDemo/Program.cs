﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dynamicDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = ".NET Batch";

            str.ToUpper();

            object obj = str;
            //obj.ToUpper();

            dynamic dyn = str;
            //Console.WriteLine(dyn.ToUpperCase());
            Console.WriteLine(dyn.ToUpper());

            Console.ReadKey();
        }
    }
}
