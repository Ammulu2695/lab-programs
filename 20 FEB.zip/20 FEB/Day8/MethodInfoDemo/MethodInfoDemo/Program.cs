﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace MethodInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");

            Type calculate = myAssembly.GetType("ReflectionLibrary.Calculate");

            MethodInfo[] methods = calculate.GetMethods();

            Console.WriteLine("Number of Methods : " + methods.Length);
            foreach (MethodInfo m in methods)
            {
                Console.WriteLine("Method Name : " + m.Name);
                Console.WriteLine("Is Abstract : " + m.IsAbstract);
                Console.WriteLine("Is Constructor : " + m.IsConstructor);
                Console.WriteLine("Is Final : " + m.IsFinal);
                Console.WriteLine("Is Generic Method : " + m.IsGenericMethod);
                Console.WriteLine("Is Private : " + m.IsPrivate);
                Console.WriteLine("Is Public : " + m.IsPublic);
                Console.WriteLine("Is Static : " + m.IsStatic);
                Console.WriteLine("Is Virtual : " + m.IsVirtual);
                Console.WriteLine("Return Type : " + m.ReturnType.Name);

                ParameterInfo[] param = m.GetParameters();
                Console.WriteLine("Number of Parameters : " + param.Length);
                foreach (var p in param)
                {
                    Console.WriteLine("\tParameter Name : " + p.Name);
                    Console.WriteLine("\tParameter Type : " + p.ParameterType);
                }
            }

            object calobj = myAssembly.CreateInstance("ReflectionLibrary.Calculate");
            MethodInfo add = calculate.GetMethod("Add");
            int sum = (int)add.Invoke(calobj, new object[] { 23, 78 });
            Console.WriteLine(sum);

            MethodInfo sub = calculate.GetMethod("Subtract");
            int subtraction = (int)sub.Invoke(null, new object[] { 75, 50 });
            Console.WriteLine(subtraction);

            Console.ReadKey();
        }
    }
}
