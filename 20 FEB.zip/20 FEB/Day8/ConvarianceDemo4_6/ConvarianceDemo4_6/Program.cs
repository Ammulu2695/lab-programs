﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConvarianceDemo4_6
{
    class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public Employee(int id, string name)
        {
            ID = id;
            Name = name;
        }
    }

    class Manager : Employee
    {
        public double Incentives { get; set; }

        public Manager(int id, string name, double inc) : base(id, name)
        {
            Incentives = inc;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Manager> mgrList = new List<Manager>();
            mgrList.Add(new Manager(101, "Robert", 7878));
            mgrList.Add(new Manager(102, "John", 7878));
            mgrList.Add(new Manager(103, "Maria", 7878));
            mgrList.Add(new Manager(104, "Sofia", 7878));
            mgrList.Add(new Manager(105, "Mary", 7878));

            IEnumerable<Employee> empList = mgrList;

            foreach (var e in empList)
            {
                Console.WriteLine(e.ID + "\t" + e.Name);
            }

            Console.ReadKey();
        }
    }
}
