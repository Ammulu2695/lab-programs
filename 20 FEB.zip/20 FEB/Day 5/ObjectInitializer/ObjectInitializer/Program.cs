﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectInitializer
{
    class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Employee emp = new Employee();
            //emp.ID = 101;
            //emp.Name = "Robert";
            //emp.Salary = 35655;

            Employee emp = new Employee() { ID = 101, Name="Robert", Salary=23234 };
            Console.WriteLine($"Employee ID : {emp.ID}");
            Console.WriteLine($"Employee Name : {emp.Name}");
            Console.WriteLine($"Salary : {emp.Salary}");
            Console.WriteLine();

            Employee emp1 = new Employee { ID = 102, Name = "John", Salary = 45767 };
            Console.WriteLine($"Employee ID : {emp1.ID}");
            Console.WriteLine($"Employee Name : {emp1.Name}");
            Console.WriteLine($"Salary : {emp1.Salary}");

            Console.ReadKey();
        }
    }
}
