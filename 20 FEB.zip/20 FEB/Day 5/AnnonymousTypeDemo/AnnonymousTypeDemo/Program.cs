﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnnonymousTypeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var person = new { Name = "Robert", Age = 30 };
            var person1 = new { Name = "Julia", Age = 25 };
            var person2 = new { Age = 28, Name = "John" };

            Console.ReadKey();
        }
    }
}
