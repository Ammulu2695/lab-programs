﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Employee emp = new Employee();
            //emp.Display();
            //emp.Print();
            //emp.Show();
            //Console.WriteLine();

            IPrintable print = new Employee();
            print.Print();
            print.Show();
            Console.WriteLine();

            IDisplay disp = new Employee();
            disp.Display();
            disp.Show();

            Console.ReadKey();
        }
    }
}
