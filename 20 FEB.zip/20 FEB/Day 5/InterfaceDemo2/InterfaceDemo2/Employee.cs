﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo2
{
    class Employee : IPrintable, IDisplay
    {
        void IDisplay.Display()
        {
            Console.WriteLine("IDisplay Display Method implemented in Employee");
        }

        void IPrintable.Print()
        {
            Console.WriteLine("IPrintable Print Method implemented in Employee");
        }

        void IPrintable.Show()
        {
            Console.WriteLine("IPrintable Show Method implemented in Employee");
        }

        void IDisplay.Show()
        {
            Console.WriteLine("IDisplay Show Method implemented in Employee");
        }
    }
}
