﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CostructorsDemo
{
    public class Employee
    {
        public Employee()
        {
            Console.WriteLine("Employee Default Constructor");
        }

        public Employee(int id)
        {
            Console.WriteLine("Employee Parameterized Constructor with 1 parameter");
        }

        public Employee(int id, string name)
        {
            Console.WriteLine("Employee Parameterized Constructor with 2 parameters");
        }

        static Employee()
        {
            Console.WriteLine("Employee Static Constructor");
        }
    }
}
