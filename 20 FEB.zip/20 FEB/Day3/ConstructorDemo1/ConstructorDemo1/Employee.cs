﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo1
{
    public class Employee
    {
        int id;
        string name;
        double salary;

        public Employee()
        {
            id = 101;
            name = "ABC";
            salary = 10000;
        }

        public Employee(int id, string name, double salary)
        {
            this.id = id;
            this.name = name;
            this.salary = salary;
        }

        public void Display()
        {
            Console.WriteLine($"Employee ID : {id}");
            Console.WriteLine($"Employee Name : {name}");
            Console.WriteLine($"Employee Salary : {salary}");
        }
    }
}
