﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverloadingDemo
{
    class Program
    {
        public void Addition(int num1, int num2)
        {
            Console.WriteLine($"{num1} + {num2} => {(num1 + num2)}");
        }

        //public int Addition(int num1, int num2)
        //{
        //    return num1 + num2;
        //}

        public void Addition(int num1, int num2, int num3)
        {
            Console.WriteLine($"{num1} + {num2} + {num3} => {(num1 + num2 + num3)}");
        }

        public void Addition(double num1, double num2)
        {
            Console.WriteLine($"{num1} + {num2} => {(num1 + num2)}");
        }

        public void Addition(int num1, double num2)
        {
            Console.WriteLine($"{num1} + {num2} => {(num1 + num2)}");
        }

        public void Addition(double num1, int num2)
        {
            Console.WriteLine($"{num1} + {num2} => {(num1 + num2)}");
        }
        static void Main(string[] args)
        {
            Program p = new Program();

            p.Addition(10, 20);
            p.Addition(10.45, 78.45);
            p.Addition(56.34, 89);
            p.Addition(12, 45, 87);
            p.Addition(78, 89.45);

            Console.ReadKey();
        }
    }
}
