﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace IteratorDemo
{
    public class DaysofWeek : IEnumerable
    {
        string[] week = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };

        //public string DisplayWeek()
        //{
        //    for (int i = 0; i < week.Length; i++)
        //    {
        //        return week[i];
        //    }

        //    return "";
        //}

        public IEnumerator GetEnumerator()
        {
            for (int i = 0; i < week.Length; i++)
            {
                yield return week[i];
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            DaysofWeek days = new DaysofWeek();

            //for (int i = 0; i < 7; i++)
            //{
            //    Console.WriteLine(days.DisplayWeek());
            //}

            foreach (var week in days)
            {
                Console.WriteLine(week);
            }

            Console.ReadKey();
        }
    }
}
