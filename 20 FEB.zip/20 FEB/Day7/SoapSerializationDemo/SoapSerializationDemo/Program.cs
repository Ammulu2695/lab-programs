﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;

namespace SoapSerializationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee() { ID = 101, Name = "Robert", Salary = 36777 };
            FileStream fs = new FileStream("Employee.soap", FileMode.Create, FileAccess.Write);
            SoapFormatter sf = new SoapFormatter();
            sf.Serialize(fs, emp);
            fs.Close();

            fs = new FileStream("Employee.soap", FileMode.Open, FileAccess.Read);
            Employee newEmp = (Employee)sf.Deserialize(fs);
            fs.Close();

            Console.WriteLine($"Employee ID : {newEmp.ID}");
            Console.WriteLine($"Employee Name : {newEmp.Name}");
            Console.WriteLine($"Employee Salary : {newEmp.Salary}");

            Console.ReadKey();
        }
    }
}
