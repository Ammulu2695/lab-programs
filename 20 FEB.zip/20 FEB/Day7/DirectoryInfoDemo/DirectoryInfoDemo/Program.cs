﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DirectoryInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Directory Name with Full Path : ");
            string path = Console.ReadLine();
            DirectoryInfo dir = new DirectoryInfo(path);

            if (dir.Exists)
            {
                Console.WriteLine($"Directory Name : {dir.Name}");
                Console.WriteLine($"Creation Time : {dir.CreationTime}");
                Console.WriteLine($"Full Name : {dir.FullName}");
                Console.WriteLine($"Last Access Time : {dir.LastAccessTime}");
                Console.WriteLine($"Last Write Time : {dir.LastWriteTime}");
                Console.WriteLine($"Parent : {dir.Parent}");
                Console.WriteLine($"Root : {dir.Root}");

                DirectoryInfo[] childDir = dir.GetDirectories();
                Console.WriteLine($"\nNumber of Directories : {childDir.Length}");

                FileInfo[] childFiles = dir.GetFiles();
                Console.WriteLine($"\nNumber of Files : {childFiles.Length}");
            }
            else
            {
                Console.WriteLine("Directory does not exists");
            }

            Console.ReadKey();
        }
    }
}
