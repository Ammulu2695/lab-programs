﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleCastDelegateDemo
{
    public delegate double MathDelegate(double num);
    class Program
    {
        static void Main(string[] args)
        {
            MathDelegate del = new MathDelegate(Math.Sin);
            //double result = del(1.0);
            double result = del.Invoke(1.0);
            Console.WriteLine("Sin : " + result);
            Console.WriteLine();

            del = new MathDelegate(Math.Round);
            double num = del(34.67);
            Console.WriteLine("Round : " + num);

            Console.ReadKey();
        }
    }
}
