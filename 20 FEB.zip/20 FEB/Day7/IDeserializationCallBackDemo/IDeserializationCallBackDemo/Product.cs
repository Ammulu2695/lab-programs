﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace IDeserializationCallBackDemo
{
    [Serializable]
    class Product : IDeserializationCallback
    {
        int id;
        public int ProductID {
            get { return id; }
            set { id = value; }
        }

        string name;
        public string ProductName
        {
            get { return name; }
            set { name = value; }
        }

        int qty;
        public int Quantity
        {
            get { return qty; }
            set { qty = value; }
        }

        int price;
        public int Price
        {
            get { return price; }
            set { price = value; }
        }

        [NonSerialized]
        int total;
        public int Total
        {
            get { return total; }
        }

        public Product(int id, string nm, int qty, int price)
        {
            ProductID = id;
            ProductName = nm;
            Quantity = qty;
            Price = price;
            total = Quantity * Price;
        }

        //public void CalculateTotal()
        //{
        //    total = Quantity * Price;
        //}

        public void OnDeserialization(object sender)
        {
            total = Quantity * Price;
        }
    }
}
