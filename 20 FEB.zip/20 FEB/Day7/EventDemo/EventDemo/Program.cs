﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            EventClass evt = new EventClass();

            //Subscriber shows interest in event
            evt.MyClickEvent += MyClass.ReactonEvent;

            //Send the notification to subscriber
            evt.NotifySubscriber("Sending Notification to Subscriber");

            Console.ReadKey();
        }
    }
}
