﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
    //Subscriber Class
    class MyClass
    {
        //Event Handler Method
        public static void ReactonEvent(string msg)
        {
            Console.WriteLine(msg);
            Console.WriteLine("Event has occured");
        }
    }
}
