﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExprDemo
{
    public delegate void LambdaDel();
    public delegate void LambdaDelwithParam(int num1, int num2);
    public delegate int LambdaDelReturn(int num1, int num2);
    class Program
    {
        static void Main(string[] args)
        {
            LambdaDel ld = () => Console.WriteLine("Hello from Lambda Expression");
            ld();

            LambdaDelwithParam ldp = (num1, num2) => Console.WriteLine($"{num1}+{num2}=>{(num1+num2)}");
            ldp(78, 90);

            LambdaDelReturn ldr = (num1, num2) => { return num1 + num2; };
            Console.WriteLine(ldr(45, 23));

            Console.ReadKey();
        }
    }
}
