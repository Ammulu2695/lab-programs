﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethodDemo
{
    public delegate void AnnDelegate();
    public delegate void AnDelegatewithParam(int num1, int num2);
    class Program
    {
        public static void Show()
        {
            Console.WriteLine("Hello from Show Method");
        }
        static void Main(string[] args)
        {
            AnnDelegate del = new AnnDelegate(Show);
            del();

            //Anonymous Method
            AnnDelegate an = delegate 
            {
                Console.WriteLine("Hello from anonymous method");
            };
            an();

            AnDelegatewithParam ap = delegate (int num1, int num2)
            {
                Console.WriteLine($"{num1} + {num2} => {(num1 + num2)}");
            };
            ap(45,89);
            Console.ReadKey();
        }
    }
}
