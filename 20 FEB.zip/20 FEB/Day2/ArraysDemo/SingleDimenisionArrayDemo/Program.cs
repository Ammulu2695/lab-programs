﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleDimenisionArrayDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //string[] cities = new string[10];
            //int[] digits = new int[10];

            //string[] cities = new string[] { "Pune", "Mumbai", "Bangalore", "Hyderabad", "Chennai", "Kolkatta", "Noida", "Gandhi Nagar" };

            string[] cities = { "Pune", "Mumbai", "Bangalore", "Hyderabad", "Chennai", "Kolkatta", "Noida", "Gandhi Nagar" };

            Console.WriteLine("Cities Details are : ");
            for (int i = 0; i < cities.Length; i++)
            {
                Console.Write(cities[i] + "\t");
            }

            Array.Sort(cities);
            Console.WriteLine("\n\nSorted Cities Details are : ");
            for (int i = 0; i < cities.Length; i++)
            {
                Console.Write(cities[i] + "\t");
            }

            Array.Reverse(cities);
            Console.WriteLine("\n\nReversed Cities Details are : ");
            for (int i = 0; i < cities.Length; i++)
            {
                Console.Write(cities[i] + "\t");
            }

            Console.ReadKey();
        }
    }
}
