﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArrayDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            char[][] names = new char[5][];

            Console.WriteLine("Enter the elements for Jaggaed Array : ");
            for (int i = 0; i < names.GetLength(0); i++)
            {
                int size;
                //Console.Write("Enter the number of character from name {0}", i);
                Console.Write($"Enter the number of character from name {i} : ");
                size = Convert.ToInt32(Console.ReadLine());
                names[i] = new char[size];
                Console.WriteLine($"Enter Name {i}");
                for (int j = 0; j < names[i].Length; j++)
                {
                    names[i][j] =Convert.ToChar(Console.ReadLine());
                }
            }

            Console.WriteLine("Names are : ");
            for (int i = 0; i < names.GetLength(0); i++)
            {
                for (int j = 0; j < names[i].Length; j++)
                {
                    Console.Write(names[i][j]);
                }
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
