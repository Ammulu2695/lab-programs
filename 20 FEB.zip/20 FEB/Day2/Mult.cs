namespace UtilityMethods
{
	public class MultiplyClass
	{
		public static int Multiply(int num1, int num2)
		{
			return num1 * num2;
		}
	}
}