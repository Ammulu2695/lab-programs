﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NullableTypesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //int num = null;     //Error : Null value cannot be converted into int. It is non-nullable type

            //Nullable<int> num = null;
            //int? num = null;
            int? num;
            num = 230;

            if (num.HasValue == true)
            {
                Console.WriteLine("Number is : " + num.Value);
            }
            else
            {
                Console.WriteLine("Number is NULL");
            }

            Console.ReadKey();
        }
    }
}
