﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariablesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 100;

            Console.WriteLine("Type of num is : " + num.GetType());

            float f = 56.78f;

            Console.WriteLine("Type of 1234 : " + (1234).GetType());
            Console.WriteLine("Type of .NET : " + (".NET").GetType());
            Console.WriteLine("Type of C : " + ('C').GetType());
            Console.WriteLine("Type of false : " + (false).GetType());
            Console.WriteLine("Type of 67.89 : " + (67.89).GetType());
            Console.WriteLine("Type of 67.89f : " + (67.89f).GetType());

            Console.WriteLine();

            Console.WriteLine("Size of int : " + sizeof(int));
            Console.WriteLine("Min Value of int : " + int.MinValue);
            Console.WriteLine("Max Value of int : " + int.MaxValue);
            Console.WriteLine("Size of bool : " + sizeof(bool));

            Console.ReadKey();
        }
    }
}
