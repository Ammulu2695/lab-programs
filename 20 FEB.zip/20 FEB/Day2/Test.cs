using System;
using UtilityMethods;

public class TestCode
{
	public static void Main(string[] args)
	{
		if(args.Length != 2)
		{
			Console.WriteLine("Usage : Test <num1> <num2>");	
		}
		else
		{
			int num1 = int.Parse(args[0]);
			int num2 = int.Parse(args[1]);
			
			int sum = AddClass.Add(num1, num2);
			int mult = MultiplyClass.Multiply(num1, num2);

			Console.WriteLine("Addition of " + num1 + " and " + num2 + " is : " + sum);
			Console.WriteLine("Multiplication of {0} and {1} is : {2}", num1, num2, mult);
		}		
	}
}




