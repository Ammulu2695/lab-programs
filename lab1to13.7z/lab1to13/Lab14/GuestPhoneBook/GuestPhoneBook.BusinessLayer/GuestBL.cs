﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GuestPhoneBook.Entities;
using GuestPhoneBook.Exceptions;
using GuestPhoneBook.DataAccessLayer;

namespace GuestPhoneBook.BusinessLayer
{
    public class GuestBL
    {
        private static bool ValidateGuest(Guest guest)
        {
            StringBuilder sb = new StringBuilder();
            bool validGuest = true;
            if(guest.GuestId <= 0)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Invalid GuestId");
            }
            if(guest.GuestName == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Guest Name is Required");
            }
            if(guest.GuestContactNumber.Length < 10)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Required 10 digit Cintact Number");
            }
            if(validGuest == false)
            {
                throw new GuestPhoneBookException(sb.ToString());                
            }
            return validGuest;
        }

        public static bool AddGuestBL(Guest newGuest)
        {
            bool guestAdded = false;
            try
            {
                if (ValidateGuest(newGuest))
                {
                    GuestDAL guestDAL = new GuestDAL();
                    guestAdded = guestDAL.AddGuestDAL(newGuest);
                }
            }
            catch(GuestPhoneBookException)
            {
                throw;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return guestAdded;
        }

        public static List<Guest> GetAllGuestBL()
        {
            List<Guest> guestList = null;
            try
            {
                GuestDAL guestDAL = new GuestDAL();
                guestList = guestDAL.GetAllGuestDAL();
            }
            catch(GuestPhoneBookException ex)
            {
                throw ex;
            }
            return guestList;
        }

        public static Guest SearchGuestBL(int searchGuestId)
        {
            Guest searchGuest = null;
            try
            {
                GuestDAL guestDAL = new GuestDAL();
                searchGuest = guestDAL.SearchGuestDAL(searchGuestId);
            }
            catch(GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchGuest;
        }

        public static bool UpdateGuestBL(Guest updateGuest)
        {
            bool guestUpdated = false;
            try
            {
                if (ValidateGuest(updateGuest))
                {
                    GuestDAL guestDAL = new GuestDAL();
                    guestUpdated = guestDAL.UpdateGuestDAL(updateGuest);
                }
            }
            catch (GuestPhoneBookException)
            {
                throw;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return guestUpdated;
        }

        public static bool DeleteGuestBL(int deleteGuestId)
        {
            bool guestDeleted = false;
            try
            {
                if(deleteGuestId > 0)
                {
                    GuestDAL guestDAL = new GuestDAL();
                    guestDeleted = guestDAL.DeleteGuestDAL(deleteGuestId);
                }
                else
                {
                    throw new GuestPhoneBookException("Invalid GuestId");
                }
            }
            catch (GuestPhoneBookException)
            {
                throw;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return guestDeleted;
        }
        

    }
}
