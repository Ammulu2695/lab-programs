﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bird;

namespace Lab3._2Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Bird.Bird b = new Bird.Bird("Eagle", 200);
            b.fly();
            b.fly(300);
            Console.ReadLine();
        }
    }
}
