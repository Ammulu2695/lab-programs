﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.Runtime.Serialization;
using System.IO;
using Soapclass;

namespace _13._3Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Contact contact = new Contact();
            contact.ContactName = "cghv";
            contact.CellNo = "1234466788";

            FileStream fs = new FileStream("contact.txt", FileMode.Create);

            SoapFormatter sf = new SoapFormatter();

            sf.Serialize(fs, contact);

            fs.Close();
            Console.ReadLine();
        }
    }
}
