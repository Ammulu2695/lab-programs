﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeseriabaleClass;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace _13._2Console
{
    class Program
    {
        static List<Contact> contactList = new List<Contact>();      
        static void Main(string[] args)
        {                           
              FileStream fileStream = new FileStream("Contact.txt", FileMode.Open,FileAccess.Read);

              BinaryFormatter bf = new BinaryFormatter();
              bf.Deserialize(fileStream);
              try
              {
                  Contact con = bf.Deserialize(fileStream) as Contact;
                  Console.WriteLine($"{con.ContactNo} and {con.ContactName}");
                  Console.WriteLine("Deserialized");
              }
              catch
              {
                  string label6 = "An error has occured";
                  Console.WriteLine(label6);
              }
              fileStream.Close();           
            Console.ReadLine();  
        }                                                  
        
    }
}
