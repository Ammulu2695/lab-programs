﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiDimensional
{
    class Program
    {
        static void Main(string[] args)
        {
            MultiDimensionalArray();
            Console.ReadLine();
        }
        static void MultiDimensionalArray()
        {
            int[,] marks = new int[5, 6];
            Console.WriteLine("Enter the Numbers");
            for (int i = 0; i < marks.GetLength(0); i++)
            {
                for (int j = 0; j < marks.GetLength(1); j++)
                {
                    marks[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.Write("data from the array");
            for (int i = 0; i < marks.GetLength(0); i++)
            {
                for (int j = 0; j < marks.GetLength(1); j++)
                {
                    Console.WriteLine(marks[i, j]);
                }
            }
        }
    }
}
