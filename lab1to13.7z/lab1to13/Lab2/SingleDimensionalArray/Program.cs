﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleDimensionalArray
{
    class Program
    {
        static void Main(string[] args)
        {
            SingleArrayDemo();
            Console.ReadLine();
        }
        static void SingleArrayDemo()
        {
            Console.WriteLine("Enter the size od array to store name countries");
            int length = Convert.ToInt32(Console.ReadLine());
            string[] strCountries = new string[length];
            Console.WriteLine("Enter Name of " + length + " Countries");
            for (int i = 0; i < length; i++)
            {
                strCountries[i] = Console.ReadLine();
            }
            Console.WriteLine("List of Countries");
            foreach (string strCountry in strCountries)
            {
                Console.WriteLine(strCountry);
            }

        }
    }
}
