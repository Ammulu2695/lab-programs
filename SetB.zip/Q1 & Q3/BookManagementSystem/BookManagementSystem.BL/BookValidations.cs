﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookManagementSystem.Entity;   //Reference to book entity
using BookManagementSystem.Exception;    // Reference to book exception
using BookManagementSystem.DAL;  // Reference to book DAL

namespace BookManagementSystem.BL
{
    /// <summary>
    /// Employee ID : 174826
    /// Employee Name : Himaja Yarlagadda
    /// Date of Creation : 12-Mar-2019
    /// Description : Business logic class of Book
    /// </summary>
    public class BookValidations
    {
        // To validate book details
        public static bool ValidateBooks(Books book)
        {
            bool booksValidated = true;
            StringBuilder message = new StringBuilder();
            try
            {
                // Checking Book id and Book name is not blank
                if (book.BookID == 0 && book.BookName == string.Empty)
                {
                    booksValidated = false;
                    message.Append("Book ID and Name should be provided\n");
                }
                // Checking Book id should be 5 digit 
                if (book.BookID < 10000 || book.BookID > 99999)
                {
                    booksValidated = false;
                    message.Append("Book ID should be exactly 5 digit long\n");
                }
                // Checking LoT
                if (book.LoT == string.Empty)
                {
                    booksValidated = false;
                    message.Append("LoT should be provided");
                }
                else if (book.LoT.ToString() != ".NET" && book.LoT.ToLower() != "Java"
                    && book.LoT.ToLower() != "IMS" && book.LoT.ToLower() != "V&V"
                    && book.LoT.ToLower()!="BI" && book.LoT.ToLower()!="RDBMS")
                {
                    booksValidated = false;
                    message.Append("LoT should be either .NET or Java or IMS or V&V or BI or RDBMS");
                }
                if (booksValidated == false)
                {
                    throw new BookException(message.ToString());
                }
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return booksValidated;
        }
        public static bool AddBook(Books book)
        {
            bool bookAdded = false;
            try
            {
                if (ValidateBooks(book))
                {
                    bookAdded = BookOperations.AddBook(book);
                }
                else
                {
                    throw new BookException("Please provide valid data of Book");
                }
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return bookAdded;
        }
        public static List<Books> DisplayAllBooks()
        {
            List<Books> bookList = BookOperations.DisplayAllBooks();
            return bookList;
        }
        public static bool DeleteBook(int bookID)
        {
            bool bookDeleted = false;
            try
            {
                bookDeleted = BookOperations.DeleteBook(bookID);
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return bookDeleted;
        }
        public static bool SerializeBook()
        {
            bool bookSerialize = false;
            try
            {
                bookSerialize = BookOperations.SerializeBook();
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return bookSerialize;
        }
        public static List<Books> DeserializeBook()
        {
            List<Books> bookDesList = null;
            try
            {
                bookDesList = BookOperations.DeserializeBook();
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return bookDesList;
        }
    }
}
