﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using BookManagementSystem.Entity;  //Reference to Entity Class Library
using BookManagementSystem.Exception;   //Reference to Exception Class Library

namespace BookManagementSystem.DAL
{
    /// <summary>
    /// Employee ID : 174826
    /// Employee Name : Himaja Yarlagadda
    /// Date of Creation : 12-Mar-2019
    /// Description : Database operations on Book Class
    /// </summary>
    public class BookOperations
    {
        static List<Books> bookList = new List<Books>();
        // To insert the book record in book list
        public static bool AddBook(Books book)
        {
            bool bookAdded = false;
            try
            {
                // Adding book object into book list
                bookList.Add(book);
                bookAdded = true;
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return bookAdded;
        }
        // To display all Books
        public static List<Books> DisplayAllBooks()
        {
            return bookList;
        }
        // To delete the book based on Book Id
        public static bool DeleteBook(int bookID)
        {
            bool bookDeleted = false;
            try
            {
                // Searching book
                Books bk = bookList.Find(b => b.BookID==bookID);
                if (bk != null)
                {
                    // Deleting book from book list
                    bookList.Remove(bk);
                    bookDeleted = true;
                }
                else
                {
                    throw new BookException("Book with ID " + bookID + " does not exists for Delete");
                }
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return bookDeleted;
        }
        // To Serialize book list
        public static bool SerializeBook()
        {
            bool bookSerialized = false;
            try
            {
                FileStream fs = new FileStream("Books.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, bookList);
                fs.Close();
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return bookSerialized;
        }
        // To Deserialize book list
        public static List<Books> DeserializeBook()
        {
            List<Books> bookDesList = null;
            try
            {
                FileStream fs = new FileStream("Books.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                bookDesList = (List<Books>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return bookDesList;
        }
    }
}
