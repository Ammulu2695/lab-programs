﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManagementSystem.Exception
{
    /// <summary>
    /// Employee ID : 174826
    /// Employee Name : Himaja Yarlagadda
    /// Date of Creation : 12-Mar-2019
    /// Description : Exception class to handle exception of Book
    /// </summary>
    public class BookException : ApplicationException
    {
        //Default Constructor
        public BookException() : base()
        { }
        //Parameterised Constructor
        public BookException(string message) : base(message)
        { }
    }
}
