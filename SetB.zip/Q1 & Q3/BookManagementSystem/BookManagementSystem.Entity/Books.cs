﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManagementSystem.Entity
{
    /// <summary>
    /// Employee ID : 174826
    /// Employee Name : Himaja Yarlagadda
    /// Date of Creation : 12-Mar-2019
    /// Description : Entity class for Book
    /// </summary>
    [Serializable]
    public class Books
    {
        //Get or Set Book ID
        public int BookID { get; set; }
        //Get or Set Book Name
        public string BookName { get; set; }
        //Get or Set ISBN Number
        public string ISBNNo { get; set; }
        //Get or Set Price
        public double Price { get; set; }
        //Get or Set Publisher
        public string Publisher { get; set; }
        //Get or Set Number of pages
        public int NumberOfPages { get; set; }
        //Get or Set Language
        public string Language { get; set; }
        //Get or Set LoT
        public string LoT { get; set; }
        //Get or Set Summary
        public string Summary { get; set; }
    }
}
