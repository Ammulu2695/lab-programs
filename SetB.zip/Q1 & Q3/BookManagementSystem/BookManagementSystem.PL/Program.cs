﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookManagementSystem.Entity;  //Reference to book entity
using BookManagementSystem.Exception;   // Reference to book exception
using BookManagementSystem.BL;  // Reference to book business operations

namespace BookManagementSystem.PL
{
    /// <summary>
    /// Employee ID : 174826
    /// Employee Name : Himaja Yarlagadda
    /// Date of Creation : 12-Mar-2019
    /// Description : Console application of Book
    /// </summary>
    class Program
    {
        public static void AddBook()
        {
            try
            {
                Books book = new Books();
                Console.WriteLine("Enter Book ID : ");
                book.BookID = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Enter Book Name : ");
                book.BookName= Console.ReadLine();
                Console.WriteLine("Enter ISBN Number : ");
                book.ISBNNo = Console.ReadLine();
                Console.WriteLine("Enter Price : ");
                book.Price = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter Publisher : ");
                book.Publisher = Console.ReadLine();
                Console.WriteLine("Enter Number of Pages : ");
                book.NumberOfPages = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Enter Language : ");
                book.Language = Console.ReadLine();
                Console.WriteLine("Enter LoT : ");
                book.LoT = Console.ReadLine();
                Console.WriteLine("Enter Summary : ");
                book.Summary = Console.ReadLine();
                bool bookAdded = BookValidations.AddBook(book);
                if (bookAdded)
                {
                    Console.WriteLine("Book added successfully");
                }
                else
                {
                    throw new BookException("Book is not added");
                }
            }
            catch (BookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DisplayAllBooks()
        {
            try
            {
                List<Books> bookList = BookValidations.DisplayAllBooks();
                if (bookList != null || bookList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------");
                    Console.WriteLine("Book ID  Book Name   ISBN Number    Price    Publisher   Number of Pages Language    LoT Summary");
                    Console.WriteLine("------------------------------------------------------------------------");
                    foreach (var book in bookList)
                    {
                        Console.WriteLine($"{book.BookID}\t{book.BookName}\t{book.ISBNNo}\t{book.Price}\t{book.Publisher}\t{book.NumberOfPages}\t{book.Language}\t{book.LoT}\t{book.Summary}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------");
                }
                else
                {
                    throw new BookException("Book data not found");
                }
            }
            catch (BookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeleteBook()
        {
            try
            {
                int bookID;
                Console.WriteLine("Enter Book ID to be deleted : ");
                bookID = Int32.Parse(Console.ReadLine());
                bool bookDeleted = BookValidations.DeleteBook(bookID);
                if (bookDeleted)
                {
                    Console.WriteLine("Book deleted successfully");
                }
                else
                {
                    throw new BookException("Book is not deleted");
                }
            }
            catch (BookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SerializeBook()
        {
            try
            {
                bool bookSerialize = BookValidations.SerializeBook();
                if (bookSerialize)
                {
                    Console.WriteLine("Book data is serialized");
                }
                else
                {
                    throw new BookException("Book data is not serialized");
                }
            }
            catch (BookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeserializeBook()
        {
            try
            {
                List<Books> bookList = BookValidations.DeserializeBook();
                if (bookList != null || bookList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------");
                    Console.WriteLine("Book ID  Book Name   ISBN Number    Price   Publisher    Number of Pages Language    LoT Summary");
                    Console.WriteLine("------------------------------------------------------------------------");
                    foreach (var book in bookList)
                    {
                        Console.WriteLine($"{book.BookID}\t{book.BookName}\t{book.ISBNNo}\t{book.Price}\t{book.Publisher}\t{book.NumberOfPages}\t{book.Language}\t{book.LoT}\t{book.Summary}");
                    }
                    Console.WriteLine("------------------------------------------------------------------------");
                }
                else
                {
                    throw new BookException("Book data not available after deserialization");
                }
            }
            catch (BookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine("***********************************");
            Console.WriteLine("1.Add Book");
            Console.WriteLine("2.Display Book Details");
            Console.WriteLine("3.Delete Book");
            Console.WriteLine("4.Serialize Book");
            Console.WriteLine("5.Deserialize Book");
            Console.WriteLine("6.Exit");
        }
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your choice : ");
                choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddBook();
                        break;
                    case 2:
                        DisplayAllBooks();
                        break;
                    case 3:
                        DeleteBook();
                        break;
                    case 4:
                        SerializeBook();
                        break;
                    case 5:
                        DeserializeBook();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valid choice");
                        break;
                }

            } while (choice != 6);
        }
    }
}
