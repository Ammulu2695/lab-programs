﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication
{
    /// <summary>
    /// Employee ID : 174826
    /// Employee Name : Himaja Yarlagadda
    /// Date of Creation : 12-Mar-2019
    /// Description : Class of Employee with properties
    /// </summary>
    class Employee : IPrintable // Employee class implements IPrintable interface
    {
        // Get and Set Properties 
        public int EmployeeID
        {
            get;
            set;
        }
        public string EmployeeName
        {
            get;
            set;
        }
        public string Gender
        {
            get;
            set;
        }
        public DateTime DateOfBirth
        {
            get;
            set;
        }
        // Implementation of Method present in interface 
        public void Print()
        {
            Console.WriteLine("Enter Employee Details : ");
        }
    }
}
