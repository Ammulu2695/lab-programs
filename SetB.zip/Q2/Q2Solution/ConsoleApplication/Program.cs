﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication
{
    /// <summary>
    /// Employee ID : 174826
    /// Employee Name : Himaja Yarlagadda
    /// Date of Creation : 12-Mar-2019
    /// Description : Console application of Employee
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // Creating object for Employee class 
            Employee emp = new Employee();
            // Calling the Method using Object
            emp.Print();
            // Accepting the values from the user
            Console.WriteLine("Enter Employee ID : ");
            emp.EmployeeID = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Enter Employee Name : ");
            emp.EmployeeName = Console.ReadLine();
            Console.WriteLine("Enter Gender : ");
            emp.Gender = Console.ReadLine();
            Console.WriteLine("Enter Date of Birth : ");
            emp.DateOfBirth = DateTime.Parse(Console.ReadLine());
            //Printing the details
            Console.WriteLine("Employee Details are : ");
            Console.WriteLine(emp.EmployeeID);
            Console.WriteLine(emp.EmployeeName);
            Console.WriteLine(emp.Gender);
            Console.WriteLine(emp.DateOfBirth);
            Console.ReadKey();
        }
    }
}
