CREATE TABLE EMP_174780
(
EmployeeID int primary key,
FistName varchar(20),
LastName varchar(30),
Title varchar(20),
DOB date
)