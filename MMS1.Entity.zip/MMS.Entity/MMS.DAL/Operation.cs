﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MMS.Entity;       //Reference to movie Entity
using MMS.Exception; //Reference to movie Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace MMS.DAL
{
    /// <summary>
    /// Employee ID :174779
    /// Employee Name : anvesh
    /// Date of Creation : 12-Mar-2019
    /// Description : Database operations on movie Class
    /// </summary>
    public class Operation
    {
        //private static object mList;

        public static List<Movie> MList = new List<Movie>();

        public static bool AddMovie(Movie T)
        {
            bool TAdded = false;

            try
            {
                //Adding movietitle object into movie list
                MList.Add(T);
                TAdded = true;
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TAdded;
        }
        //public static bool AddMovieReleased(Movie R)
        //{
        //    bool RAdded = false;

        //    try
        //    {
        //        //Adding movietitle object into movie list
        //        MList.Add(R);
        //        RAdded = true;
        //    }
        //    catch (MovieException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return RAdded;
        //}
        //public static bool AddPublisher(Movie R)
        //{
        //    bool PAdded = false;

        //    try
        //    {
        //        //Adding movietitle object into movie list
        //        MList.Add(R);
        //        PAdded = true;
        //    }
        //    catch (MovieException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return PAdded;
        //}
        //public static bool AddLength(Movie R)
        //{
        //    bool LAdded = false;

        //    try
        //    {
        //        //Adding movietitle object into movie list
        //        MList.Add(R);
        //        LAdded = true;
        //    }
        //    catch (MovieException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return LAdded;
        //}
        //public static bool AddActing(Movie R)
        //{
        //    bool AAdded = false;

        //    try
        //    {
        //        //Adding movietitle object into movie list
        //        MList.Add(R);
        //        AAdded = true;
        //    }
        //    catch (MovieException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return AAdded;
        //}
        //public static bool AddMusic(Movie R)
        //{
        //    bool MAdded = false;

        //    try
        //    {
        //        //Adding movietitle object into movie list
        //        MList.Add(R);
        //        MAdded = true;
        //    }
        //    catch (MovieException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return MAdded;
        //}
        //public static bool AddCinematograohy(Movie R)
        //{
        //    bool CAdded = false;

        //    try
        //    {
        //        //Adding movietitle object into movie list
        //        MList.Add(R);
        //        CAdded = true;
        //    }
        //    catch (MovieException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return CAdded;
        //}
        //public static bool AddDuration(Movie R)
        //{
        //    bool DAdded = false;

        //    try
        //    {
        //        //Adding movietitle object into movie list
        //        MList.Add(R);
        //        DAdded = true;
        //    }
        //    catch (MovieException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return DAdded;
        //}
        //To Serialize employee list
        public static bool SerializeMovie()
        {
            bool mSerialized = false;

            try
            {
                FileStream fs = new FileStream("Movie.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, MList);
                fs.Close();
                mSerialized = true;
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return mSerialized;
        }

        //To deserialize employee List
        public static List<Movie> DeserializeMovie()
        {
            List<Movie> mDesList = null;

            try
            {
                FileStream fs = new FileStream("Movie.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                mDesList = (List<Movie>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return mDesList;
        }
        public static List<Movie> DisplayMovie()
        {
            return MList;
        }
    }
}
