﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NewMovieEntity;//using reference of newMovieEntity
using NewMovieException;//using reference of newMovieEntity
using System.IO;
using NewMovieDAL;//using refernce of NewmovieDAL
using System.Text.RegularExpressions;

namespace NewmovieBL
{
    public class MovieValidation
    {


        public static bool ValidateMovie(Movie T)
        {
            bool TValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - Movie name
                if (T.MovieTitle == String.Empty)
                {
                    TValidated = false;
                    message.Append("Movie title should be provided\n");
                }
                else if (!Regex.IsMatch(T.MovieTitle, "[A-Z][a-z]{2,}"))
                {
                    TValidated = false;
                    message.Append("movie name starts with capital letter followed by small alphabets");
                } //checking publisher
                if (T.Publisher == String.Empty)
                {
                    TValidated = false;
                    message.Append("Publisher should be provided\n");
                }
               else if (!Regex.IsMatch(T.Publisher, "[A-Z][a-z]{2,}"))
                {
                    TValidated = false;
                    message.Append("movie Publisher starts with capital letter followed by small alphabets");
                }
                //checking movie Release
                int MovieRelease = DateTime.Today.Year - T.MovieReleased.Year;
                if (MovieRelease < 13 / 03 / 2019)
                {
                    TValidated = false;
                    message.Append("movie is released date must be before present day ");
                }

                if (T.Acting >0 || T.Acting <5 )
                {
                    TValidated = false;
                    message.Append("rating b/w 0-5:");
                }
                if (T.Cinematography > 0 || T.Cinematography < 5)
                {
                    TValidated = false;
                    message.Append("rating b/w 0-5:");
                }
                if (T.Music >0 || T.Music<5)
                {
                    TValidated = false;
                    message.Append("rating b/w 0-5:");
                }
                if (TValidated ==false)
                {
                    throw new MovieException(message.ToString());
                }

            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TValidated;
            
            }

        public static bool AddMovie(Movie T)
        {
            bool TAdded = false;

            try
            {
                if (ValidateMovie(T))
                {
                    TAdded = NewMovieOperations.AddMovietitle(T);
                }
                else
                {
                    throw new MovieException("Please provide valid data for employee");
                }
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TAdded;
        }
        public static List<Movie> DisplayMovie()
        {
            List<Movie> TList = MovieValidation.DisplayMovie();

            return TList;
        }



        public static bool SerializeMovie()
            {
                bool TSerialized = false;

                try
                {
                    TSerialized = MovieValidation.SerializeMovie();
                }
                catch (MovieException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return TSerialized;
            }

            public static List<Movie> DeserializeMovie()
            {
                List<Movie> TDesList = null;

                try
                {
                    TDesList = MovieValidation.DeserializeMovie();
                }
                catch (MovieException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return TDesList;
            }
        }
    }
            

