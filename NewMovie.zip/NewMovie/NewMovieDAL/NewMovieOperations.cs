﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NewMovieEntity;//using reference of newMovieEntity
using NewMovieException;//using reference of newMovieEntity
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace NewMovieDAL
{
    public class NewMovieOperations
    {
        static List<Movie> MTList = new List<Movie>();
        //private static readonly object MovieList;

        //To insert the movie tite in movie list
        public static bool AddMovietitle(Movie T)
        {
            bool TAdded = false;

            try
            {
                //Adding movietitle object into movie list
                MTList.Add(T);
                TAdded = true;
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return TAdded;
        }
        //To insert the movie Released in movie list
        public static bool AddMovieReleased(Movie R)
        {
            bool RAdded = false;

            try
            {
                //Adding movieReleased object into movie list
                MTList.Add(R);
                RAdded = true;
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return RAdded;
        }

        //To insert the movie Released in movie list
        public static bool AddPublisher(Movie P)
        {
            bool PAdded = false;

            try
            {
                //Adding movieReleased object into movie list
                MTList.Add(P);
                PAdded = true;
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return PAdded;
        }
        //To insert the movie Length in movie list
        public static bool AddLength(Movie L)
        {
            bool LAdded = false;

            try
            {
                //Adding movielength object into movie list
                MTList.Add(L);
                LAdded = true;
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return LAdded;
        }

        public static bool AddActing(Movie aa)
        {
            bool aaAdded = false;

            try
            {
                //Adding Acting object into movie list
                MTList.Add(aa);
                aaAdded = true;
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return aaAdded;
        }
        public static bool AddMusic(Movie m)
        {
            bool mAdded = false;

            try
            {
                //Adding music object into movie list
                MTList.Add(m);
                mAdded = true;
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return mAdded;
        }
        public static bool Addcinematograohy(Movie c)
        {
            bool cAdded = false;

            try
            {
                //Adding Cinematography object into movie list
                MTList.Add(c);
                cAdded = true;
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cAdded;
        }
        public static bool Duration(Movie d)
        {
            bool dAdded = false;

            try
            {
                //Adding duration object into movie list
                MTList.Add(d);
                dAdded = true;
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dAdded;
        }
         //to serialize the movielist
        public static bool SerializeMovie()
        {
            bool MovieSerialized = false;

            try
            {
                FileStream fs = new FileStream("Movie.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, MTList);
                fs.Close();
                MovieSerialized = true;
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return MovieSerialized;
        }
        //To deserialize employee List
        public static List<Movie> DeserializeMovie()
        {
            List<Movie> MovieDesList = null;

            try
            {
                FileStream fs = new FileStream("Movie.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                MovieDesList = (List<Movie>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (MovieException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return MovieDesList;
        }

    }
}

        