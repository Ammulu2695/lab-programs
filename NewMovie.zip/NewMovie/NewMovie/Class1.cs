﻿using System;

namespace NewMovie
{
    public class Class1
    {
    }
}
