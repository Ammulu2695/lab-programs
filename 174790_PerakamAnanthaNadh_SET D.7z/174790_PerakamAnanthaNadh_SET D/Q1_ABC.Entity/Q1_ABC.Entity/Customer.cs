﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1_ABC.Entity
{

     /// <summary>
    /// Employee ID : 174790
    /// Employee Name :PERAKAM ANANTHANADH
    /// Date of Creation : 12-Mar-2019
    /// Description : Entity class for Customer
    /// </summary>
    public class CustomerEntity
    {
        
        //Get or set Customer_Name
        public string Customer_Name { get; set; }

        //Get or set Account_Type
        public string Account_Type{ get; set; }
        
        //Get or set Account_Balance
        public double Account_Balance { get; set; }

        //Get or set Current_AccountNumber
        public int Current_AccountNumber { get; set; }

        //Get or set Saving_AccountNumber
        public int Saving_AccountNumber { get; set; }


    }
}
