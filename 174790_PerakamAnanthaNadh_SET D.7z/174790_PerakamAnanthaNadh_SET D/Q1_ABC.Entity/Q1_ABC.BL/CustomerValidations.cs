﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q1_ABC.Entity;
using Q1_ABC.DAL;
using Q1_ABC.Exception;

namespace Q1_ABC.BL
{
    // <summary>
    /// Customer ID : 174790
    /// Customer Name :PERAKAM ANANTHANADH
    /// Date of Creation : 12-Mar-2019
    /// Description : Business logic class for Customer
    /// </summary>
    public class CustomerValidations
    {


        private static bool ValidCustomer(CustomerEntity customer)
        {
            bool Customervalied = true;
            StringBuilder sb = new StringBuilder();
            try
            {                
                if (customer.Customer_Name == string.Empty)
                {
                    Customervalied = false;
                    sb.Append(Environment.NewLine + "Customer Name Required");

                }
                if (customer.Account_Type == string.Empty)
                {
                    Customervalied = false;
                    sb.Append(Environment.NewLine + "Account_Type is  Required");

                }
                ////else if (customer.Account_Type== "Saving Account" && customer.Account_Type=="Current Account")
                ////{
                ////        Customervalied = false;
                ////    sb.Append("Accoutn_Type should be either Saving Account or Current Account\n");
                ////}
                //if(customer.Account_Type==Convert.ToInt32(customer.Account_Type))
                if (customer.Account_Type.ToLower() == "current")
                {
                    if (customer.Current_AccountNumber< 100000 || customer.Current_AccountNumber > 999999)
                    {
                        Customervalied = false;
                        sb.Append("Current_AccountNumber should be exactly 6 digits long\n");
                    }
                }
                else if (customer.Account_Type.ToLower() == "Savings")
                {
                    if (customer.Saving_AccountNumber < 100000 || customer.Saving_AccountNumber > 999999)
                    {
                        Customervalied = false;
                        sb.Append("Saving_AccountNumber should be exactly 6 digits long\n");
                    }
                }

                if (customer.Account_Balance < 500)
                {
                    Customervalied = false;
                    sb.Append(Environment.NewLine + "Maintain Account Balance Mininum 500");

                }
                if (Customervalied == false)
                {
                    throw new CustomerException(sb.ToString());
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return Customervalied;
        }
        public static bool AddCustomer(CustomerEntity customer)
        {
            bool customerAdded = false;

            try
            {
                if (ValidCustomer(customer))
                {                   
                    customerAdded = CustomerOperations.AddCustomer(customer);
                }
                else
                {
                    
                    throw new CustomerException("Please provide valid data for Customer");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerAdded;
        }

        public static List<CustomerEntity> RetrieveCustomers()
        {
            List<CustomerEntity> cusList = CustomerOperations.RetrieveCustomers();

            return cusList;
        }

        //public static CustomerEntity CheckBalance(String CustomerName)
        //{
        //    CustomerEntity cus = null;

        //    try
        //    {
        //        cus = CustomerOperations.CheckBalance(CustomerName);
        //    }
        //    catch (CustomerException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return cus;
        //}


        public static CustomerEntity CheckBalance(int AccountNumber)
        {
            CustomerEntity cus =null;
            //CustomerEntity cus = new CustomerEntity();

            try
            {
                if (AccountNumber == cus.Current_AccountNumber)
                {
                    cus = CustomerOperations.CheckBalance(cus.Current_AccountNumber);
                }
                else 
                    {

                    cus = CustomerOperations.CheckBalance(cus.Saving_AccountNumber);
                }

                }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cus;
        }

    }
}
