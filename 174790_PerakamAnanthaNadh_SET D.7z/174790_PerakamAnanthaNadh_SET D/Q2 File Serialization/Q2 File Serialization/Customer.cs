﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2_File_Serialization_Deserilization
{
    [Serializable]
    class Customer
    {

        
        string Customer_Name;
        public string Name { get { return Customer_Name; } set { Customer_Name = value; } }

        string Account_Type;
        public string Type{ get { return Account_Type; } set { Account_Type = value; } }

        double Account_Balance;
        public double Balance{ get { return Account_Balance; } set { Account_Balance = value; } }



    }
}
