﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1_Anonymous_Mehtod
{
    /// <summary>
    /// Employee ID : 174790
    /// Employee Name :PERAKAM ANANTHANADH
    /// Date of Creation : 12-Mar-2019
    /// Description : USING  ANONYMOUS METHODS
    /// </summary>

    public delegate void AnDelegatewithParam(int num1, int num2);
    class Program
    {
        static void Main(string[] args)
        {
            //Using Anonymous Method by Divsion
            AnDelegatewithParam Divison = delegate (int num1, int num2)
            {
                Console.WriteLine($"{num1} / {num2} => {(num1 / num2)}");
            };
            Divison(20, 10);


            //Using Anonymous Method by Modulus

            AnDelegatewithParam Modulus = delegate (int num1, int num2)
            {
                Console.WriteLine($"{num1}%{num2} => {(num1 % num2)}");
            };
           Modulus(25, 4);
            Console.ReadKey();
        }
    }
}
