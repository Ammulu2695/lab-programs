﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1Calculator
{

    /// <summary>
    /// Employee ID : 174790
    /// Employee Name :PERAKAM ANANTHANADH
    /// Date of Creation : 12-Mar-2019
    /// Description : MULTICAST DELEGATE
    /// </summary>



    public delegate void MathDelgate(int num1, int num2);//Declaration of Delgate

    class Program
    {
        
        static void Main(string[] args)
        {
            Calculate cal = new Calculate();

            // Object intializing for delgate
            MathDelgate del = new MathDelgate(cal.Division);//Using Delegate by Division operation

            del += new MathDelgate(cal.Modulus);// using Delgate by Modulus operation
            del(10, 2);
            Console.ReadKey();

        }
    }
}
